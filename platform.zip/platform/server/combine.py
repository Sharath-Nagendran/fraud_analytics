from pathlib import Path


SOURCE_FOLDER = r"C:/Sharath/Projects/platform"
OUTPUT_FILE = r"C:/Sharath/Projects/platform/complete_codebase.txt"


INCLUDE_EXTENSIONS = {
    ".py",
    ".yaml",
    ".yml",
    ".json",
    ".txt",
    ".md",
    ".ini",
    ".cfg",
    ".properties",
    ".xml",
    ".html",
    ".css",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".sql",
    ".sh",
    ".bat",
    ".ps1",
    ".dockerfile",
}


EXCLUDE_DIRS = {
    "__pycache__",
    ".pytest_cache",
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "dist",
    "build",
    ".idea",
    ".vscode",
    "target",
}


EXCLUDE_FILES = {
    "complete_codebase.txt",
    "package-lock.json",
}


def should_skip(path: Path) -> bool:
    return any(
        part.lower() in EXCLUDE_DIRS
        for part in path.parts
    )


root = Path(SOURCE_FOLDER)
output_path = Path(OUTPUT_FILE)


with output_path.open(
    "w",
    encoding="utf-8",
) as outfile:
    for file in sorted(root.rglob("*")):
        if not file.is_file():
            continue

        relative_path = file.relative_to(root)

        if should_skip(relative_path):
            continue

        if file.name.lower() in EXCLUDE_FILES:
            continue

        if file.suffix.lower() not in INCLUDE_EXTENSIONS:
            continue

        outfile.write("\n")
        outfile.write("=" * 80 + "\n")
        outfile.write(f"FILE: {relative_path}\n")
        outfile.write("=" * 80 + "\n\n")

        try:
            content = file.read_text(
                encoding="utf-8",
                errors="ignore",
            )

            outfile.write(content)

        except Exception as exc:
            outfile.write(
                f"\nERROR READING FILE: {exc}\n"
            )

        outfile.write("\n\n")


print(f"Output written to: {output_path}")