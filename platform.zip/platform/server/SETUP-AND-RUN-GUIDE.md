# Running This Project — Full Setup Guide (Python/FastAPI version)

This replaces the earlier NestJS/TypeScript version entirely. If you'd
already started on that one, you can discard it — nothing here depends on
it. Two genuine simplifications versus the Node version, worth knowing
upfront: there's no separate "compile" step at all (not even the
dev-mode-only kind Node has), and no special app configuration was needed
to access the raw request body for webhook signature verification —
FastAPI gives you that directly.

## Step 1 — Install Python

You need Python 3.11 or later.

```bash
python3 --version
```

If that's below 3.11 or missing, install via [pyenv](https://github.com/pyenv/pyenv)
(the Python-world equivalent of nvm — lets you manage multiple Python
versions cleanly) or your OS's package manager (`brew install python@3.12`
on macOS, for example).

## Step 2 — Create a virtual environment

A virtual environment is Python's way of isolating this project's
dependencies from your system Python and from other projects — there's no
exact Java equivalent, but think of it as similar in spirit to how a
Maven project's dependencies don't leak into other projects, except in
Python it requires an explicit "activate" step each time you work on the
project.

```bash
mkdir music-platform-api && cd music-platform-api
python3 -m venv venv
source venv/bin/activate       # macOS/Linux
# venv\Scripts\activate        # Windows
```

You'll know it worked because your terminal prompt now shows `(venv)` at
the start. **Run this `source venv/bin/activate` command again every time
you open a new terminal to work on this project** — it doesn't persist
automatically, which trips up almost everyone coming from Java/Maven at
first.

## Step 3 — Copy the project files in

Place the `app/`, `tests/`, `requirements.txt`, `pytest.ini`, and
`.env.example` from what I gave you into this `music-platform-api/`
folder, preserving the folder structure exactly:

```
music-platform-api/
├── requirements.txt
├── pytest.ini
├── .env.example
├── app/
│   ├── main.py
│   ├── core/
│   │   └── config.py
│   ├── db/
│   │   └── base.py
│   ├── models/
│   │   └── live_event.py
│   ├── schemas/
│   │   └── live_event.py
│   ├── services/
│   │   ├── mux_service.py
│   │   └── live_service.py
│   ├── api/
│   │   ├── deps.py
│   │   ├── live_router.py
│   │   └── mux_webhook_router.py
│   └── utils/
│       └── mux_webhook_verify.py
└── tests/
    └── test_live_service.py
```

(The empty `__init__.py` files in each folder are important — they're what
makes Python treat these as importable packages. Make sure they came
across; an empty file is easy to lose track of when copying folders.)

## Step 4 — Install dependencies

With your virtual environment still active (Step 2):

```bash
pip install -r requirements.txt
```

This is the direct equivalent of `pip install` for individual packages,
just reading the whole list from a file — the same role `requirements.txt`
plays in any Python project you've likely already used.

## Step 5 — Set up a free Postgres database (Neon)

1. Go to [neon.tech](https://neon.tech), sign up, create a new project.
2. Copy the connection string it gives you (starts with `postgresql://`).
3. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
4. Open `.env` and paste in your connection string, **changing the prefix
   from `postgresql://` to `postgresql+asyncpg://`** — this tells
   SQLAlchemy to use the async Postgres driver we installed in step 4. This
   is the single most common mistake at this step — Neon's dashboard
   always shows you the plain `postgresql://` form.

## Step 6 — Set up Alembic (database migrations)

Alembic is the standard Python migration tool — think of it as playing the
same role Flyway or Liquibase plays if you've used either with Java, or
Django's migration system if you've touched Django.

```bash
alembic init alembic
```

This creates an `alembic/` folder and `alembic.ini`. Two edits needed:

1. In `alembic.ini`, delete the `sqlalchemy.url = ...` line entirely (we'll
   set it from our own settings instead, so it isn't duplicated/out of
   sync with `.env`).

2. Open `alembic/env.py` and make two changes near the top:

   ```python
   # Add these imports
   from app.db.base import Base
   from app.core.config import settings
   from app.models import live_event  # noqa: F401 — import so Alembic sees the model

   # Find the line that sets config.set_main_option or similar for the URL,
   # and add this instead, right after `config = context.config`:
   config.set_main_option("sqlalchemy.url", settings.database_url.replace("+asyncpg", ""))

   # Find `target_metadata = None` and change it to:
   target_metadata = Base.metadata
   ```

   (Alembic's autogenerate runs synchronously, which is why the URL above
   strips `+asyncpg` back out — this is a one-line quirk of mixing async
   SQLAlchemy with Alembic, not something you need to think about beyond
   this.)

3. Generate and run the actual migration:

   ```bash
   alembic revision --autogenerate -m "add live events"
   alembic upgrade head
   ```

   The first command inspects your models and writes a migration file;
   the second actually creates the table in your Neon database.

## Step 7 — Set the remaining environment variables

In `.env`, fill in:

```
MUX_TOKEN_ID=
MUX_TOKEN_SECRET=
```

from [Mux Dashboard → Settings → Access Tokens](https://dashboard.mux.com/settings/access-tokens)
(free Mux account is enough for this). Leave `MUX_WEBHOOK_SECRET` blank for
now — you'll get it during webhook testing, and the app runs fine without
it until you actually hit the webhook endpoint.

## Step 8 — Run it

```bash
uvicorn app.main:app --reload
```

`uvicorn` is the ASGI server that actually runs a FastAPI app — the rough
equivalent of how Tomcat runs a Spring Boot app under the hood, except
here you invoke it directly rather than it being bundled invisibly inside
a single runnable jar. `--reload` watches your files and restarts
automatically on changes — this is your "there's no separate compile step"
dev loop; there's nothing further to run after saving a file.

Open **http://localhost:8000/docs** in a browser — FastAPI auto-generates
an interactive Swagger UI for every endpoint. This is genuinely the
easiest way to test the API without curl or Postman: expand an endpoint,
click "Try it out," fill in the fields, click Execute.

## Step 9 — Test it

Either through the `/docs` page above, or with curl:

```bash
curl -X POST http://localhost:8000/live-events \
  -H "x-test-artist-id: test-artist-1" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Show",
    "scheduled_start": "2026-12-01T19:00:00Z",
    "ticket_price_cents": 500
  }'
```

You should get back JSON including `rtmp_ingest_url` and `stream_key`.
Copy the event `id`, then:

```bash
curl http://localhost:8000/live-events/<event-id>
```

Confirm `stream_key` is **not** present in this response — only the
creation response should ever include it.

## Step 10 — Run the tests

```bash
pytest
```

You should see 4 passing tests. These mock the database and Mux entirely
— no real network calls, same role `@Mock`/Mockito objects play in a
JUnit test if that's a more familiar comparison.

## Step 11 — Test the real broadcast flow with OBS (optional but recommended)

Same process as before, independent of language: configure OBS with the
`rtmp_ingest_url`/`stream_key` from a test event, start streaming, confirm
the event's status flips to `LIVE`. This requires registering a webhook
endpoint with Mux pointing at your server (via `ngrok` for local testing)
and setting `MUX_WEBHOOK_SECRET` — see
[Mux Dashboard → Settings → Webhooks](https://dashboard.mux.com/settings/webhooks).

---

## What's deliberately NOT in this code yet

Same caveats as the original version, unchanged by the language switch:

- **No DRM is configured** — only `playback_policy=SIGNED`, which is a
  prerequisite, not DRM itself. That's C-group.
- **No one checks tickets or subscriptions before granting playback** —
  there's no playback-token endpoint yet. That's D-group.
- **The idle-timeout timer uses `asyncio.create_task`**, which has the
  exact same single-instance limitation `setTimeout` had in the Node
  version — fine for local testing, unsafe once autoscaled. Replace with
  Celery + Redis (or APScheduler) before production, flagged in a code
  comment in `live_service.py`.

---

## Troubleshooting

| Error | Likely cause |
|---|---|
| `ModuleNotFoundError: No module named 'app'` | You're not running `uvicorn` from inside the `music-platform-api/` root folder, or a folder is missing an `__init__.py` |
| `sqlalchemy.exc.InvalidRequestError` about a driver | `.env`'s `DATABASE_URL` still says `postgresql://` instead of `postgresql+asyncpg://` (Step 5) |
| `pydantic_settings...ValidationError` on startup | A required value in `.env` is missing or the file wasn't found — confirm `.env` is in the project root, not inside `app/` |
| `401` on a curl/docs request | Missing the `x-test-artist-id` header (expected — the stub auth dependency working correctly) |
| Webhook returns `Invalid Mux webhook signature` | `MUX_WEBHOOK_SECRET` not set yet, or you're testing the webhook before registering it with Mux |
| `alembic revision --autogenerate` produces an empty migration | `target_metadata = Base.metadata` wasn't set in `alembic/env.py`, or the model import is missing (Step 6) |
