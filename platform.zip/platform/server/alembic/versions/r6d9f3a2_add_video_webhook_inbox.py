"""add provider-neutral video webhook inbox

Revision ID: r6d9f3a2
Revises: q5c8e2f1
"""

from alembic import op
import sqlalchemy as sa


revision = "r6d9f3a2"
down_revision = "q5c8e2f1"
branch_labels = None
depends_on = None


def upgrade():

    op.create_table(
        "video_webhook_events",
        sa.Column(
            "id",
            sa.UUID(),
            nullable=False,
        ),
        sa.Column(
            "provider",
            sa.String(length=30),
            nullable=False,
        ),
        sa.Column(
            "provider_event_id",
            sa.String(length=255),
            nullable=False,
        ),
        sa.Column(
            "event_type",
            sa.String(length=255),
            nullable=False,
        ),
        sa.Column(
            "provider_stream_id",
            sa.String(length=255),
            nullable=True,
        ),
        sa.Column(
            "raw_payload",
            sa.Text(),
            nullable=False,
        ),
        sa.Column(
            "status",
            sa.String(length=30),
            nullable=False,
        ),
        sa.Column(
            "attempts",
            sa.Integer(),
            nullable=False,
        ),
        sa.Column(
            "last_error",
            sa.Text(),
            nullable=True,
        ),
        sa.Column(
            "received_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),
        sa.Column(
            "processed_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "provider",
            "provider_event_id",
            name="uq_video_webhook_provider_event",
        ),
    )

    op.create_index(
        "ix_video_webhook_events_provider",
        "video_webhook_events",
        ["provider"],
    )

    op.create_index(
        "ix_video_webhook_events_event_type",
        "video_webhook_events",
        ["event_type"],
    )

    op.create_index(
        "ix_video_webhook_events_stream",
        "video_webhook_events",
        ["provider", "provider_stream_id"],
    )

    op.create_index(
        "ix_video_webhook_events_status",
        "video_webhook_events",
        ["status"],
    )


def downgrade():
    op.drop_index(
        "ix_video_webhook_events_status",
        table_name="video_webhook_events",
    )

    op.drop_index(
        "ix_video_webhook_events_stream",
        table_name="video_webhook_events",
    )

    op.drop_index(
        "ix_video_webhook_events_event_type",
        table_name="video_webhook_events",
    )

    op.drop_index(
        "ix_video_webhook_events_provider",
        table_name="video_webhook_events",
    )

    op.drop_table("video_webhook_events")

    op.execute(
        "DROP TYPE IF EXISTS webhookprocessingstatus"
    )