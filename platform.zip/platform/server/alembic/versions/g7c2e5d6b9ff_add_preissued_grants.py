"""add durable preissued playback grants
Revision ID: g7c2e5d6b9ff
Revises: f6b1d4c5a8ee
"""
from alembic import op
import sqlalchemy as sa
revision="g7c2e5d6b9ff";down_revision="f6b1d4c5a8ee";branch_labels=None;depends_on=None

def upgrade():
    status=sa.Enum("READY","CONSUMED","EXPIRED","REVOKED",name="preissuedgrantstatus")
    op.create_table("preissued_playback_grants",
        sa.Column("id",sa.UUID(),primary_key=True),
        sa.Column("event_id",sa.UUID(),sa.ForeignKey("live_events.id"),nullable=False),
        sa.Column("entitlement_id",sa.UUID(),sa.ForeignKey("entitlements.id"),nullable=False),
        sa.Column("fan_id",sa.String(),nullable=False),sa.Column("session_id",sa.String(),nullable=False),
        sa.Column("playback_id",sa.String(),nullable=False),sa.Column("token",sa.String(),nullable=False),
        sa.Column("expires_at",sa.DateTime(timezone=True),nullable=False),sa.Column("status",status,nullable=False),
        sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.Column("consumed_at",sa.DateTime(timezone=True)),
        sa.UniqueConstraint("event_id","entitlement_id",name="uq_preissued_event_entitlement"))
    op.create_index("ix_preissued_event_fan_status","preissued_playback_grants",["event_id","fan_id","status"])
    op.create_index("ix_preissued_expires_at","preissued_playback_grants",["expires_at"])

def downgrade():
    op.drop_index("ix_preissued_expires_at",table_name="preissued_playback_grants")
    op.drop_index("ix_preissued_event_fan_status",table_name="preissued_playback_grants")
    op.drop_table("preissued_playback_grants")
    op.execute("DROP TYPE IF EXISTS preissuedgrantstatus")
