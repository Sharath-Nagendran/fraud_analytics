"""add G3 outage compensation workflow
Revision ID: j0f5b8a9e2cc
Revises: i9e4a7f8d1bb
"""
from alembic import op
import sqlalchemy as sa
revision="j0f5b8a9e2cc";down_revision="i9e4a7f8d1bb";branch_labels=None;depends_on=None


def upgrade():
    compensation_type=sa.Enum("REFUND",name="compensationtype")
    compensation_status=sa.Enum("QUEUED","PROCESSING","COMPLETED","FAILED","MANUAL_REVIEW",name="compensationstatus")
    op.create_table(
        "compensation_cases",
        sa.Column("id",sa.UUID(),primary_key=True),
        sa.Column("incident_id",sa.UUID(),sa.ForeignKey("stream_incidents.id"),nullable=False),
        sa.Column("candidate_id",sa.UUID(),sa.ForeignKey("refund_candidates.id"),nullable=False),
        sa.Column("ticket_id",sa.UUID(),sa.ForeignKey("ticket_purchases.id"),nullable=False),
        sa.Column("event_id",sa.UUID(),sa.ForeignKey("live_events.id"),nullable=False),
        sa.Column("fan_id",sa.String(),nullable=False),
        sa.Column("compensation_type",compensation_type,nullable=False),
        sa.Column("amount_cents",sa.Integer(),nullable=False),
        sa.Column("currency",sa.String(3),nullable=False),
        sa.Column("idempotency_key",sa.String(250),nullable=False,unique=True),
        sa.Column("status",compensation_status,nullable=False),
        sa.Column("provider_reference",sa.String()),
        sa.Column("failure_reason",sa.Text()),
        sa.Column("approved_by",sa.String(),nullable=False),
        sa.Column("approved_at",sa.DateTime(timezone=True),nullable=False),
        sa.Column("completed_at",sa.DateTime(timezone=True)),
        sa.Column("reconciliation_attempts",sa.Integer(),nullable=False),
        sa.UniqueConstraint("candidate_id",name="uq_compensation_case_candidate"),
    )
    op.create_index("ix_compensation_cases_incident_id","compensation_cases",["incident_id"])
    op.create_index("ix_compensation_cases_event_id","compensation_cases",["event_id"])
    op.create_index("ix_compensation_cases_status_approved","compensation_cases",["status","approved_at"])
    op.create_table(
        "compensation_audit",
        sa.Column("id",sa.UUID(),primary_key=True),
        sa.Column("compensation_case_id",sa.UUID(),sa.ForeignKey("compensation_cases.id"),nullable=False),
        sa.Column("action",sa.String(80),nullable=False),
        sa.Column("actor",sa.String(),nullable=False),
        sa.Column("details",sa.Text()),
        sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),
    )
    op.create_index("ix_compensation_audit_compensation_case_id","compensation_audit",["compensation_case_id"])


def downgrade():
    op.drop_table("compensation_audit")
    op.drop_table("compensation_cases")
    op.execute("DROP TYPE IF EXISTS compensationstatus")
    op.execute("DROP TYPE IF EXISTS compensationtype")
