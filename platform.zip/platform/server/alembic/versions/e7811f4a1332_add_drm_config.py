"""add drm config

Revision ID: e7811f4a1332
Revises: fdfbe15dac47
Create Date: 2026-10-04 20:59:57.609776

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'e7811f4a1332'
down_revision: Union[str, None] = 'fdfbe15dac47'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "drm_config",

        sa.Column(
            "id",
            sa.UUID(),
            primary_key=True
        ),

        sa.Column(
            "enabled",
            sa.Boolean(),
            nullable=False
        ),

        sa.Column(
            "provider",
            sa.String(),
            nullable=False
        ),

        sa.Column(
            "watermark_enabled",
            sa.Boolean(),
            nullable=False
        ),

        sa.Column(
            "widevine_url",
            sa.String()
        ),

        sa.Column(
            "fairplay_url",
            sa.String()
        ),

        sa.Column(
            "playready_url",
            sa.String()
        ),

        sa.Column(
            "updated_at",
            sa.DateTime(
                timezone=True
            )
        )
    )


def downgrade() -> None:
    op.drop_table(
        "drm_config"
    )
