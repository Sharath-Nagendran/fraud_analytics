"""add provider idle timestamp

Revision ID: s7e1c4b8
Revises: r6d9f3a2
"""

from alembic import op
import sqlalchemy as sa


revision = "s7e1c4b8"
down_revision = "r6d9f3a2"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "live_events",
        sa.Column(
            "provider_idle_since",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
    )

    op.create_index(
        "ix_live_events_provider_idle_since",
        "live_events",
        ["provider_idle_since"],
        unique=False,
    )


def downgrade():
    op.drop_index(
        "ix_live_events_provider_idle_since",
        table_name="live_events",
    )

    op.drop_column(
        "live_events",
        "provider_idle_since",
    )
