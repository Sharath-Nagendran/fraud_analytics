"""add durable replay jobs

Revision ID: y3k7f6h8
Revises: x2j6e5g7
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "y3k7f6h8"
down_revision = "x2j6e5g7"
branch_labels = None
depends_on = None


def upgrade() -> None:
    status = postgresql.ENUM(
        "PENDING", "PROCESSING", "RETRY", "COMPLETED", "FAILED",
        name="replayjobstatus", create_type=False,
    )
    status.create(op.get_bind(), checkfirst=True)

    op.create_table(
        "replay_jobs",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("live_event_id", sa.UUID(), nullable=False),
        sa.Column("live_recording_id", sa.UUID(), nullable=False),
        sa.Column("status", status, nullable=False),
        sa.Column("attempts", sa.Integer(), nullable=False),
        sa.Column("max_attempts", sa.Integer(), nullable=False),
        sa.Column("next_attempt_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("locked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("locked_by", sa.String(200), nullable=True),
        sa.Column("last_error", sa.Text(), nullable=True),
        sa.Column("video_asset_id", sa.UUID(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["live_event_id"], ["live_events.id"]),
        sa.ForeignKeyConstraint(["live_recording_id"], ["live_recordings.id"]),
        sa.ForeignKeyConstraint(["video_asset_id"], ["video_assets.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("live_event_id", name="uq_replay_jobs_live_event"),
    )
    op.create_index(
        "ix_replay_jobs_dispatch", "replay_jobs", ["status", "next_attempt_at"]
    )


def downgrade() -> None:
    op.drop_index("ix_replay_jobs_dispatch", table_name="replay_jobs")
    op.drop_table("replay_jobs")
    op.execute("DROP TYPE IF EXISTS replayjobstatus")
