"""add operational alerts
Revision ID: i9e4a7f8d1bb
Revises: h8d3f6e7c0aa
"""
from alembic import op
import sqlalchemy as sa
revision="i9e4a7f8d1bb";down_revision="h8d3f6e7c0aa";branch_labels=None;depends_on=None

def upgrade():
    severity=sa.Enum("WARNING","CRITICAL",name="alertseverity")
    status=sa.Enum("FIRING","ACKNOWLEDGED","RESOLVED",name="alertstatus")
    delivery=sa.Enum("PENDING","SENT","FAILED",name="alertdeliverystatus")
    op.create_table("operational_alerts",
        sa.Column("id",sa.UUID(),primary_key=True),sa.Column("event_id",sa.UUID(),sa.ForeignKey("live_events.id"),nullable=False),
        sa.Column("alert_type",sa.String(80),nullable=False),sa.Column("fingerprint",sa.String(200),nullable=False,unique=True),
        sa.Column("severity",severity,nullable=False),sa.Column("status",status,nullable=False),sa.Column("summary",sa.String(300),nullable=False),
        sa.Column("details",sa.Text()),sa.Column("occurrence_count",sa.Integer(),nullable=False),
        sa.Column("first_seen_at",sa.DateTime(timezone=True),nullable=False),sa.Column("last_seen_at",sa.DateTime(timezone=True),nullable=False),
        sa.Column("acknowledged_at",sa.DateTime(timezone=True)),sa.Column("acknowledged_by",sa.String()),
        sa.Column("resolved_at",sa.DateTime(timezone=True)),sa.Column("resolution_note",sa.Text()))
    op.create_index("ix_operational_alerts_event_id","operational_alerts",["event_id"])
    op.create_index("ix_operational_alerts_event_status","operational_alerts",["event_id","status"])
    op.create_index("ix_operational_alerts_status_last_seen","operational_alerts",["status","last_seen_at"])
    op.create_table("alert_deliveries",sa.Column("id",sa.UUID(),primary_key=True),sa.Column("alert_id",sa.UUID(),sa.ForeignKey("operational_alerts.id"),nullable=False),sa.Column("channel",sa.String(40),nullable=False),sa.Column("status",delivery,nullable=False),sa.Column("attempt_count",sa.Integer(),nullable=False),sa.Column("last_error",sa.Text()),sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.Column("sent_at",sa.DateTime(timezone=True)))
    op.create_index("ix_alert_deliveries_alert_id","alert_deliveries",["alert_id"])
    op.create_index("ix_alert_deliveries_status_created","alert_deliveries",["status","created_at"])

def downgrade():
    op.drop_table("alert_deliveries");op.drop_table("operational_alerts")
    op.execute("DROP TYPE IF EXISTS alertdeliverystatus");op.execute("DROP TYPE IF EXISTS alertstatus");op.execute("DROP TYPE IF EXISTS alertseverity")
