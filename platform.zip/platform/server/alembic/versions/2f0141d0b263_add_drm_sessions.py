"""add drm sessions

Revision ID: 2f0141d0b263
Revises: p4d9f2a6
Create Date: 2026-10-04 13:24:06.576932

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '2f0141d0b263'
down_revision: Union[str, None] = 'p4d9f2a6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "drm_sessions",

        sa.Column(
            "id",
            sa.UUID(),
            primary_key=True
        ),

        sa.Column(
            "event_id",
            sa.UUID(),
            nullable=False
        ),

        sa.Column(
            "fan_id",
            sa.String(),
            nullable=False
        ),

        sa.Column(
            "entitlement_id",
            sa.UUID(),
            nullable=False
        ),

        sa.Column(
            "playback_session_id",
            sa.String(),
            nullable=False
        ),

        sa.Column(
            "drm_mode",
            sa.String(),
            nullable=False
        ),

        sa.Column(
            "watermark_id",
            sa.String(),
            nullable=False
        ),

        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False
        ),
    )


def downgrade():
    op.drop_table(
        "drm_sessions"
    )