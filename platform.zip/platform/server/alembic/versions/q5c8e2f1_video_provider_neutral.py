"""provider-neutral video fields

Revision ID: q5c8e2f1
Revises: e7811f4a1332
"""
from alembic import op
import sqlalchemy as sa

revision = "q5c8e2f1"
down_revision = "e7811f4a1332"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("live_events", sa.Column("video_provider", sa.String(30), nullable=True))
    op.add_column("live_events", sa.Column("video_stream_id", sa.String(), nullable=True))
    op.add_column("live_events", sa.Column("video_stream_key", sa.String(), nullable=True))
    op.add_column("live_events", sa.Column("video_playback_id", sa.String(), nullable=True))
    op.add_column("live_events", sa.Column("video_ingest_url", sa.String(), nullable=True))
    op.add_column("live_events", sa.Column("video_playback_url", sa.String(), nullable=True))
    op.add_column("live_events", sa.Column("video_asset_id", sa.String(), nullable=True))
    op.add_column("live_events", sa.Column("video_vod_playback_id", sa.String(), nullable=True))
    op.create_index("ix_live_events_video_provider", "live_events", ["video_provider"])
    op.create_unique_constraint("uq_live_events_video_stream_id", "live_events", ["video_stream_id"])
    op.create_unique_constraint("uq_live_events_video_vod_playback_id", "live_events", ["video_vod_playback_id"])
    op.execute("""
        UPDATE live_events
           SET video_provider = CASE
                 WHEN mux_live_stream_id LIKE 'fake-%' THEN 'mock'
                 ELSE 'mux'
               END,
               video_stream_id = mux_live_stream_id,
               video_stream_key = mux_stream_key,
               video_playback_id = mux_playback_id,
               video_asset_id = mux_asset_id,
               video_vod_playback_id = mux_vod_playback_id
         WHERE mux_live_stream_id IS NOT NULL
    """)


def downgrade():
    op.drop_constraint("uq_live_events_video_vod_playback_id", "live_events", type_="unique")
    op.drop_constraint("uq_live_events_video_stream_id", "live_events", type_="unique")
    op.drop_index("ix_live_events_video_provider", table_name="live_events")
    for name in ["video_vod_playback_id", "video_asset_id", "video_playback_url", "video_ingest_url", "video_playback_id", "video_stream_key", "video_stream_id", "video_provider"]:
        op.drop_column("live_events", name)
