"""ticket ownership and transfer
Revision ID: k1a6c9b0f3dd
Revises: j0f5b8a9e2cc
"""
from alembic import op
import sqlalchemy as sa
revision="k1a6c9b0f3dd"; down_revision="j0f5b8a9e2cc"; branch_labels=None; depends_on=None
def upgrade():
    os=sa.Enum("ACTIVE","TRANSFER_PENDING","REVOKED",name="ticketownershipstatus")
    ts=sa.Enum("PENDING","ACCEPTED","CANCELLED","DECLINED","EXPIRED",name="tickettransferstatus")
    op.create_table("ticket_ownerships",sa.Column("id",sa.UUID(),primary_key=True),sa.Column("ticket_id",sa.UUID(),sa.ForeignKey("ticket_purchases.id"),nullable=False),sa.Column("owner_fan_id",sa.String(),nullable=False),sa.Column("status",os,nullable=False),sa.Column("ownership_version",sa.Integer(),nullable=False),sa.Column("acquired_at",sa.DateTime(timezone=True),nullable=False),sa.Column("transferred_at",sa.DateTime(timezone=True)),sa.UniqueConstraint("ticket_id",name="uq_ticket_ownership_ticket"))
    op.create_index("ix_ticket_ownership_owner_status","ticket_ownerships",["owner_fan_id","status"])
    op.create_table("ticket_transfers",sa.Column("id",sa.UUID(),primary_key=True),sa.Column("ticket_id",sa.UUID(),sa.ForeignKey("ticket_purchases.id"),nullable=False),sa.Column("from_fan_id",sa.String(),nullable=False),sa.Column("to_fan_id",sa.String(),nullable=False),sa.Column("idempotency_key",sa.String(250),nullable=False,unique=True),sa.Column("status",ts,nullable=False),sa.Column("message",sa.Text()),sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.Column("expires_at",sa.DateTime(timezone=True),nullable=False),sa.Column("accepted_at",sa.DateTime(timezone=True)),sa.Column("cancelled_at",sa.DateTime(timezone=True)))
    op.create_index("ix_ticket_transfers_ticket_id","ticket_transfers",["ticket_id"]); op.create_index("ix_ticket_transfers_recipient_status","ticket_transfers",["to_fan_id","status"])
    op.create_table("ticket_ownership_audit",sa.Column("id",sa.UUID(),primary_key=True),sa.Column("ticket_id",sa.UUID(),sa.ForeignKey("ticket_purchases.id"),nullable=False),sa.Column("transfer_id",sa.UUID(),sa.ForeignKey("ticket_transfers.id")),sa.Column("action",sa.String(80),nullable=False),sa.Column("actor_fan_id",sa.String(),nullable=False),sa.Column("from_fan_id",sa.String()),sa.Column("to_fan_id",sa.String()),sa.Column("created_at",sa.DateTime(timezone=True),nullable=False))
    op.create_index("ix_ticket_ownership_audit_ticket_id","ticket_ownership_audit",["ticket_id"])
    op.execute("""INSERT INTO ticket_ownerships (id,ticket_id,owner_fan_id,status,ownership_version,acquired_at) SELECT (substr(md5(id::text),1,8)||'-'||substr(md5(id::text),9,4)||'-4'||substr(md5(id::text),14,3)||'-a'||substr(md5(id::text),18,3)||'-'||substr(md5(id::text),21,12))::uuid,id,fan_id,'ACTIVE',1,COALESCE(created_at,now()) FROM ticket_purchases ON CONFLICT (ticket_id) DO NOTHING""")
def downgrade():
    op.drop_table("ticket_ownership_audit"); op.drop_table("ticket_transfers"); op.drop_table("ticket_ownerships"); op.execute("DROP TYPE IF EXISTS tickettransferstatus"); op.execute("DROP TYPE IF EXISTS ticketownershipstatus")
