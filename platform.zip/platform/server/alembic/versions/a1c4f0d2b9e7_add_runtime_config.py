"""add runtime config tables (currencies, app_settings, config_audit_log)

Schema only. Initial values are loaded by `python -m app.db.seed` from
app/db/seed_data.json, so no configuration values live in this migration.

Revision ID: a1c4f0d2b9e7
Revises: 8ceef3d1ed05
Create Date: 2026-10-03 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "a1c4f0d2b9e7"
down_revision: Union[str, None] = "8ceef3d1ed05"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "currencies",
        sa.Column("code", sa.String(length=3), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("minor_unit", sa.SmallInteger(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        sa.Column("is_default", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("code = upper(code)", name="ck_currencies_code_upper"),
        sa.CheckConstraint("minor_unit >= 0 AND minor_unit <= 4", name="ck_currencies_minor_unit"),
        sa.CheckConstraint("NOT is_default OR is_active", name="ck_currencies_default_is_active"),
        sa.PrimaryKeyConstraint("code"),
    )
    op.create_index(
        "uq_currencies_single_default",
        "currencies",
        ["is_default"],
        unique=True,
        postgresql_where=sa.text("is_default"),
    )

    op.create_table(
        "app_settings",
        sa.Column("key", sa.String(), nullable=False),
        sa.Column("value", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_by", sa.String(), nullable=True),
        sa.PrimaryKeyConstraint("key"),
    )

    op.create_table(
        "config_audit_log",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("entity", sa.String(), nullable=False),
        sa.Column("entity_key", sa.String(), nullable=False),
        sa.Column("action", sa.String(), nullable=False),
        sa.Column("old_value", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("new_value", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("changed_by", sa.String(), nullable=False),
        sa.Column("changed_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_config_audit_entity", "config_audit_log", ["entity", "entity_key"])


def downgrade() -> None:
    op.drop_index("ix_config_audit_entity", table_name="config_audit_log")
    op.drop_table("config_audit_log")
    op.drop_table("app_settings")
    op.drop_index("uq_currencies_single_default", table_name="currencies")
    op.drop_table("currencies")
