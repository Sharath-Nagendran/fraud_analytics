from alembic import op

revision = "a4d1e0b3"
down_revision = "n3c8e1d2"
branch_labels = None
depends_on = None

def upgrade():
    op.drop_constraint(
        "uq_entitlement_fan_event",
        "entitlements",
        type_="unique"
    )

def downgrade():
    op.create_unique_constraint(
        "uq_entitlement_fan_event",
        "entitlements",
        ["fan_id", "event_id"]
    )