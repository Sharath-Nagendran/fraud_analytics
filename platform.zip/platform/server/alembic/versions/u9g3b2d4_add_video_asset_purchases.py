"""
add video asset purchases and entitlements

Revision ID: u9g3b2d4
Revises: t8f2a1c3
"""

from alembic import op
import sqlalchemy as sa

from sqlalchemy.dialects import postgresql


revision = "u9g3b2d4"
down_revision = "t8f2a1c3"
branch_labels = None
depends_on = None


def upgrade() -> None:

    entitlement_status = postgresql.ENUM(
        "ACTIVE",
        "REVOKED",
        "EXPIRED",
        name="videoassetentitlementstatus",
        create_type=False,
    )

    purchase_status = postgresql.ENUM(
        "PAID",
        "REFUNDED",
        "FAILED",
        name="videoassetpurchasestatus",
        create_type=False,
    )

    entitlement_status.create(
        op.get_bind(),
        checkfirst=True,
    )

    purchase_status.create(
        op.get_bind(),
        checkfirst=True,
    )

    op.create_table(
        "video_asset_entitlements",
        sa.Column(
            "id",
            sa.UUID(),
            nullable=False,
        ),
        sa.Column(
            "video_asset_id",
            sa.UUID(),
            nullable=False,
        ),
        sa.Column(
            "fan_id",
            sa.String(),
            nullable=False,
        ),
        sa.Column(
            "source",
            sa.String(100),
            nullable=False,
        ),
        sa.Column(
            "status",
            entitlement_status,
            nullable=False,
        ),
        sa.Column(
            "valid_from",
            sa.DateTime(timezone=True),
            nullable=False,
        ),
        sa.Column(
            "valid_until",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ["video_asset_id"],
            ["video_assets.id"],
        ),
        sa.PrimaryKeyConstraint(
            "id"
        ),
        sa.UniqueConstraint(
            "video_asset_id",
            "fan_id",
            name=(
                "uq_video_asset_entitlement_"
                "asset_fan"
            ),
        ),
    )

    op.create_index(
        "ix_video_asset_entitlements_video_asset_id",
        "video_asset_entitlements",
        ["video_asset_id"],
    )

    op.create_index(
        "ix_video_asset_entitlements_fan_id",
        "video_asset_entitlements",
        ["fan_id"],
    )

    op.create_index(
        "ix_video_asset_entitlements_fan_status",
        "video_asset_entitlements",
        ["fan_id", "status"],
    )

    op.create_index(
        "ix_video_asset_entitlements_asset_status",
        "video_asset_entitlements",
        ["video_asset_id", "status"],
    )

    op.create_table(
        "video_asset_purchases",
        sa.Column(
            "id",
            sa.UUID(),
            nullable=False,
        ),
        sa.Column(
            "video_asset_id",
            sa.UUID(),
            nullable=False,
        ),
        sa.Column(
            "fan_id",
            sa.String(),
            nullable=False,
        ),
        sa.Column(
            "entitlement_id",
            sa.UUID(),
            nullable=False,
        ),
        sa.Column(
            "provider",
            sa.String(30),
            nullable=False,
        ),
        sa.Column(
            "provider_payment_id",
            sa.String(255),
            nullable=False,
        ),
        sa.Column(
            "idempotency_key",
            sa.String(255),
            nullable=False,
        ),
        sa.Column(
            "amount_cents",
            sa.Integer(),
            nullable=False,
        ),
        sa.Column(
            "currency",
            sa.String(3),
            nullable=False,
        ),
        sa.Column(
            "status",
            purchase_status,
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),
        sa.Column(
            "refunded_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.ForeignKeyConstraint(
            ["video_asset_id"],
            ["video_assets.id"],
        ),
        sa.ForeignKeyConstraint(
            ["entitlement_id"],
            ["video_asset_entitlements.id"],
        ),
        sa.PrimaryKeyConstraint(
            "id"
        ),
        sa.UniqueConstraint(
            "provider_payment_id",
        ),
        sa.UniqueConstraint(
            "idempotency_key",
        ),
        sa.UniqueConstraint(
            "video_asset_id",
            "fan_id",
            name=(
                "uq_video_asset_purchase_"
                "asset_fan"
            ),
        ),
    )

    op.create_index(
        "ix_video_asset_purchases_video_asset_id",
        "video_asset_purchases",
        ["video_asset_id"],
    )

    op.create_index(
        "ix_video_asset_purchases_fan_id",
        "video_asset_purchases",
        ["fan_id"],
    )

    op.create_index(
        "ix_video_asset_purchases_fan_created",
        "video_asset_purchases",
        ["fan_id", "created_at"],
    )


def downgrade() -> None:

    op.drop_index(
        "ix_video_asset_purchases_fan_created",
        table_name="video_asset_purchases",
    )

    op.drop_index(
        "ix_video_asset_purchases_fan_id",
        table_name="video_asset_purchases",
    )

    op.drop_index(
        "ix_video_asset_purchases_video_asset_id",
        table_name="video_asset_purchases",
    )

    op.drop_table(
        "video_asset_purchases"
    )

    op.drop_index(
        "ix_video_asset_entitlements_asset_status",
        table_name="video_asset_entitlements",
    )

    op.drop_index(
        "ix_video_asset_entitlements_fan_status",
        table_name="video_asset_entitlements",
    )

    op.drop_index(
        "ix_video_asset_entitlements_fan_id",
        table_name="video_asset_entitlements",
    )

    op.drop_index(
        "ix_video_asset_entitlements_video_asset_id",
        table_name="video_asset_entitlements",
    )

    op.drop_table(
        "video_asset_entitlements"
    )

    op.execute(
        "DROP TYPE IF EXISTS "
        "videoassetpurchasestatus"
    )

    op.execute(
        "DROP TYPE IF EXISTS "
        "videoassetentitlementstatus"
    )