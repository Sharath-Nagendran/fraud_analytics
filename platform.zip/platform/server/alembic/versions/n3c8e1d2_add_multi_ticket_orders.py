"""add one-payment multi-ticket orders

Revision ID: n3c8e1d2
Revises: m2b7d0c1
"""
from alembic import op
import sqlalchemy as sa

revision = "n3c8e1d2"
down_revision = "m2b7d0c1"
branch_labels = None
depends_on = None


def upgrade():
    op.drop_constraint(
        "uq_ticket_event_fan",
        "ticket_purchases",
        type_="unique"
    )
    order_status = sa.Enum("PAID", "PARTIALLY_REFUNDED", "REFUNDED", name="ticketorderstatus")
    op.create_table(
        "ticket_orders",
        sa.Column("id", sa.UUID(), primary_key=True),
        sa.Column("event_id", sa.UUID(), sa.ForeignKey("live_events.id"), nullable=False),
        sa.Column("buyer_fan_id", sa.String(), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False),
        sa.Column("unit_amount_cents", sa.Integer(), nullable=False),
        sa.Column("total_amount_cents", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False),
        sa.Column("provider", sa.String(), nullable=False),
        sa.Column("provider_payment_id", sa.String(), nullable=False, unique=True),
        sa.Column("idempotency_key", sa.String(255), nullable=False, unique=True),
        sa.Column("status", order_status, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("quantity > 0", name="ck_ticket_orders_quantity_positive"),
        sa.CheckConstraint("total_amount_cents = unit_amount_cents * quantity", name="ck_ticket_orders_total"),
    )
    op.create_index("ix_ticket_orders_event_id", "ticket_orders", ["event_id"])
    op.create_index("ix_ticket_orders_buyer_fan_id", "ticket_orders", ["buyer_fan_id"])
    op.create_index("ix_ticket_orders_buyer_created", "ticket_orders", ["buyer_fan_id", "created_at"])
    op.create_table(
        "ticket_order_items",
        sa.Column("id", sa.UUID(), primary_key=True),
        sa.Column("order_id", sa.UUID(), sa.ForeignKey("ticket_orders.id"), nullable=False),
        sa.Column("ticket_id", sa.UUID(), sa.ForeignKey("ticket_purchases.id"), nullable=False, unique=True),
        sa.Column("line_number", sa.Integer(), nullable=False),
        sa.UniqueConstraint("order_id", "line_number", name="uq_ticket_order_line"),
    )
    op.create_index("ix_ticket_order_items_order_id", "ticket_order_items", ["order_id"])


def downgrade():
    op.drop_table("ticket_order_items")
    op.drop_table("ticket_orders")
    op.create_unique_constraint(
        "uq_ticket_event_fan",
        "ticket_purchases",
        ["event_id", "fan_id"]
    )
    op.execute("DROP TYPE IF EXISTS ticketorderstatus")
