"""add chat and moderation domain

Revision ID: z4l8g7i9
Revises: y3k7f6h8
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "z4l8g7i9"
down_revision = "y3k7f6h8"
branch_labels = None
depends_on = None

ENUMS = {
    "chatroomtype": ["LIVE_EVENT", "VIDEO_ASSET", "DIRECT"],
    "chatroomstatus": ["OPEN", "CLOSED", "ARCHIVED"],
    "chatparticipanttype": ["ARTIST", "FAN", "MODERATOR", "SYSTEM"],
    "chatparticipantstatus": ["ACTIVE", "MUTED", "SUSPENDED", "REMOVED"],
    "chatmessagetype": ["TEXT", "SYSTEM", "MODERATION_NOTICE"],
    "chatmessagestatus": ["PENDING", "VISIBLE", "BLOCKED", "DELETED"],
    "moderationdecisiontype": ["ALLOW", "WARN", "BLOCK", "ESCALATE"],
    "moderationincidenttype": ["ABUSE", "HARASSMENT", "THREAT", "SPAM", "OTHER"],
    "moderationaction": [
        "NONE", "WARNING", "MESSAGE_BLOCKED", "TEMPORARY_MUTE",
        "CHAT_REMOVAL", "HUMAN_REVIEW",
    ],
    "moderationincidentstatus": ["OPEN", "RESOLVED", "APPEALED"],
}


def _enum(name: str):
    return postgresql.ENUM(*ENUMS[name], name=name, create_type=False)


def upgrade() -> None:
    bind = op.get_bind()
    for name in ENUMS:
        _enum(name).create(bind, checkfirst=True)

    op.create_table(
        "chat_rooms",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("room_type", _enum("chatroomtype"), nullable=False),
        sa.Column("live_event_id", sa.UUID(), nullable=True),
        sa.Column("video_asset_id", sa.UUID(), nullable=True),
        sa.Column("artist_id", sa.String(255), nullable=False),
        sa.Column("status", _enum("chatroomstatus"), nullable=False),
        sa.Column("moderation_enabled", sa.Boolean(), nullable=False),
        sa.Column("moderation_policy_version", sa.String(100), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("closed_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["live_event_id"], ["live_events.id"]),
        sa.ForeignKeyConstraint(["video_asset_id"], ["video_assets.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("live_event_id", name="uq_chat_rooms_live_event"),
        sa.UniqueConstraint("video_asset_id", name="uq_chat_rooms_video_asset"),
        sa.CheckConstraint(
            "(room_type = 'LIVE_EVENT' AND live_event_id IS NOT NULL AND video_asset_id IS NULL) OR "
            "(room_type = 'VIDEO_ASSET' AND video_asset_id IS NOT NULL AND live_event_id IS NULL) OR "
            "(room_type = 'DIRECT' AND live_event_id IS NULL AND video_asset_id IS NULL)",
            name="ck_chat_rooms_scope",
        ),
    )
    op.create_index("ix_chat_rooms_artist_status", "chat_rooms", ["artist_id", "status"])

    op.create_table(
        "chat_participants",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("chat_room_id", sa.UUID(), nullable=False),
        sa.Column("participant_type", _enum("chatparticipanttype"), nullable=False),
        sa.Column("participant_id", sa.String(255), nullable=False),
        sa.Column("status", _enum("chatparticipantstatus"), nullable=False),
        sa.Column("warning_count", sa.Integer(), nullable=False),
        sa.Column("muted_until", sa.DateTime(timezone=True), nullable=True),
        sa.Column("joined_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("last_seen_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("removed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("removal_reason", sa.Text(), nullable=True),
        sa.ForeignKeyConstraint(["chat_room_id"], ["chat_rooms.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "chat_room_id", "participant_type", "participant_id",
            name="uq_chat_participants_room_identity",
        ),
    )
    op.create_index(
        "ix_chat_participants_room_status", "chat_participants", ["chat_room_id", "status"]
    )
    op.create_index(
        "ix_chat_participants_identity", "chat_participants", ["participant_type", "participant_id"]
    )

    op.create_table(
        "chat_messages",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("chat_room_id", sa.UUID(), nullable=False),
        sa.Column("sender_participant_id", sa.UUID(), nullable=False),
        sa.Column("sequence_number", sa.BigInteger(), nullable=True),
        sa.Column("message_type", _enum("chatmessagetype"), nullable=False),
        sa.Column("body", sa.Text(), nullable=False),
        sa.Column("status", _enum("chatmessagestatus"), nullable=False),
        sa.Column("client_message_id", sa.String(255), nullable=False),
        sa.Column("moderation_required", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("edited_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["chat_room_id"], ["chat_rooms.id"]),
        sa.ForeignKeyConstraint(["sender_participant_id"], ["chat_participants.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "chat_room_id", "client_message_id", name="uq_chat_messages_room_client_id"
        ),
        sa.UniqueConstraint(
            "chat_room_id", "sequence_number", name="uq_chat_messages_room_sequence"
        ),
    )
    op.create_index(
        "ix_chat_messages_room_created", "chat_messages", ["chat_room_id", "created_at"]
    )
    op.create_index(
        "ix_chat_messages_sender_created", "chat_messages", ["sender_participant_id", "created_at"]
    )
    op.create_index(
        "ix_chat_messages_room_status", "chat_messages", ["chat_room_id", "status"]
    )

    op.create_table(
        "moderation_decisions",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("chat_message_id", sa.UUID(), nullable=False),
        sa.Column("moderation_provider", sa.String(100), nullable=False),
        sa.Column("moderation_model_version", sa.String(200), nullable=True),
        sa.Column("policy_version", sa.String(100), nullable=False),
        sa.Column("decision", _enum("moderationdecisiontype"), nullable=False),
        sa.Column("categories", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("severity", sa.Integer(), nullable=True),
        sa.Column("confidence", sa.Float(), nullable=True),
        sa.Column("reason_code", sa.String(100), nullable=True),
        sa.Column("policy_rule", sa.String(200), nullable=True),
        sa.Column("provider_request_id", sa.String(255), nullable=True),
        sa.Column("provider_payload", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("processing_milliseconds", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["chat_message_id"], ["chat_messages.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("chat_message_id"),
    )
    op.create_index(
        "ix_moderation_decisions_decision_created",
        "moderation_decisions", ["decision", "created_at"]
    )

    op.create_table(
        "moderation_incidents",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("chat_room_id", sa.UUID(), nullable=False),
        sa.Column("participant_id", sa.UUID(), nullable=False),
        sa.Column("chat_message_id", sa.UUID(), nullable=True),
        sa.Column("moderation_decision_id", sa.UUID(), nullable=True),
        sa.Column("incident_type", _enum("moderationincidenttype"), nullable=False),
        sa.Column("action", _enum("moderationaction"), nullable=False),
        sa.Column("warning_number", sa.Integer(), nullable=True),
        sa.Column("action_expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("status", _enum("moderationincidentstatus"), nullable=False),
        sa.Column("evidence_snapshot", sa.Text(), nullable=True),
        sa.Column("reason_code", sa.String(100), nullable=True),
        sa.Column("requested_by_type", _enum("chatparticipanttype"), nullable=True),
        sa.Column("requested_by_id", sa.String(255), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("resolved_by", sa.String(255), nullable=True),
        sa.Column("resolution_notes", sa.Text(), nullable=True),
        sa.ForeignKeyConstraint(["chat_room_id"], ["chat_rooms.id"]),
        sa.ForeignKeyConstraint(["participant_id"], ["chat_participants.id"]),
        sa.ForeignKeyConstraint(["chat_message_id"], ["chat_messages.id"]),
        sa.ForeignKeyConstraint(["moderation_decision_id"], ["moderation_decisions.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_moderation_incidents_room_created",
        "moderation_incidents", ["chat_room_id", "created_at"]
    )
    op.create_index(
        "ix_moderation_incidents_participant_status",
        "moderation_incidents", ["participant_id", "status"]
    )
    op.create_index(
        "ix_moderation_incidents_status_created",
        "moderation_incidents", ["status", "created_at"]
    )


def downgrade() -> None:
    op.drop_index("ix_moderation_incidents_status_created", table_name="moderation_incidents")
    op.drop_index("ix_moderation_incidents_participant_status", table_name="moderation_incidents")
    op.drop_index("ix_moderation_incidents_room_created", table_name="moderation_incidents")
    op.drop_table("moderation_incidents")

    op.drop_index("ix_moderation_decisions_decision_created", table_name="moderation_decisions")
    op.drop_table("moderation_decisions")

    op.drop_index("ix_chat_messages_room_status", table_name="chat_messages")
    op.drop_index("ix_chat_messages_sender_created", table_name="chat_messages")
    op.drop_index("ix_chat_messages_room_created", table_name="chat_messages")
    op.drop_table("chat_messages")

    op.drop_index("ix_chat_participants_identity", table_name="chat_participants")
    op.drop_index("ix_chat_participants_room_status", table_name="chat_participants")
    op.drop_table("chat_participants")

    op.drop_index("ix_chat_rooms_artist_status", table_name="chat_rooms")
    op.drop_table("chat_rooms")

    for name in reversed(list(ENUMS)):
        op.execute(f"DROP TYPE IF EXISTS {name}")
