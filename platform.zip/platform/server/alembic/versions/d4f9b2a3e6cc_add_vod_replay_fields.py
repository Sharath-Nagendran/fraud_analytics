"""add VOD replay fields
Revision ID: d4f9b2a3e6cc
Revises: c3e8a192d5bb
"""
from alembic import op
import sqlalchemy as sa
revision="d4f9b2a3e6cc"; down_revision="c3e8a192d5bb"; branch_labels=None; depends_on=None
def upgrade():
    op.add_column("live_events", sa.Column("mux_vod_playback_id", sa.String(), nullable=True))
    op.add_column("live_events", sa.Column("archived_at", sa.DateTime(timezone=True), nullable=True))
    op.create_index("ix_live_events_mux_vod_playback_id", "live_events", ["mux_vod_playback_id"], unique=True)
def downgrade():
    op.drop_index("ix_live_events_mux_vod_playback_id", table_name="live_events")
    op.drop_column("live_events", "archived_at")
    op.drop_column("live_events", "mux_vod_playback_id")
