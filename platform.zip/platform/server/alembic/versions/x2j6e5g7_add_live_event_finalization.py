"""
add live event finalization

Revision ID: x2j6e5g7
Revises: w1i5d4f6
"""

from alembic import op
import sqlalchemy as sa


revision = "x2j6e5g7"
down_revision = "w1i5d4f6"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "live_events",
        sa.Column(
            "finalized_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
    )

    op.create_index(
        "ix_live_events_finalized_at",
        "live_events",
        ["finalized_at"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        "ix_live_events_finalized_at",
        table_name="live_events",
    )

    op.drop_column(
        "live_events",
        "finalized_at",
    )