"""add ticket tiers
Revision ID: f6b1d4c5a8ee
Revises: e5a0c3b4f7dd
"""
from alembic import op
import sqlalchemy as sa
revision="f6b1d4c5a8ee"; down_revision="e5a0c3b4f7dd"; branch_labels=None; depends_on=None

def upgrade():
    op.create_table(
        "ticket_tiers",
        sa.Column("id", sa.UUID(), primary_key=True),
        sa.Column("event_id", sa.UUID(), sa.ForeignKey("live_events.id"), nullable=False),
        sa.Column("code", sa.String(40), nullable=False),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("description", sa.Text()),
        sa.Column("price_cents", sa.Integer(), nullable=False),
        sa.Column("capacity", sa.Integer()),
        sa.Column("sold_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("early_access_seconds", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("content_access", sa.Text(), nullable=False, server_default="LIVE,REPLAY"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("event_id", "code", name="uq_ticket_tier_event_code"),
    )
    op.create_index("ix_ticket_tiers_event_id", "ticket_tiers", ["event_id"])
    op.add_column("ticket_purchases", sa.Column("tier_id", sa.UUID(), nullable=True))
    op.create_foreign_key("fk_ticket_purchases_tier_id", "ticket_purchases", "ticket_tiers", ["tier_id"], ["id"])

def downgrade():
    op.drop_constraint("fk_ticket_purchases_tier_id", "ticket_purchases", type_="foreignkey")
    op.drop_column("ticket_purchases", "tier_id")
    op.drop_index("ix_ticket_tiers_event_id", table_name="ticket_tiers")
    op.drop_table("ticket_tiers")
