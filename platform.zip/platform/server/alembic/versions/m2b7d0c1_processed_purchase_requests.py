"""add processed purchase requests

Revision ID: m2b7d0c1
Revises: k1a6c9b0f3dd
"""

from alembic import op
import sqlalchemy as sa

revision = "m2b7d0c1"
down_revision = "k1a6c9b0f3dd"
branch_labels = None
depends_on = None


def upgrade():

    op.create_table(
        "processed_purchase_requests",

        sa.Column(
            "idempotency_key",
            sa.String(255),
            primary_key=True
        ),

        sa.Column(
            "ticket_id",
            sa.UUID(),
            nullable=False
        ),

        sa.Column(
            "event_id",
            sa.UUID(),
            nullable=False
        ),

        sa.Column(
            "fan_id",
            sa.String(),
            nullable=False
        ),

        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False
        )
    )


def downgrade():

    op.drop_table(
        "processed_purchase_requests"
    )