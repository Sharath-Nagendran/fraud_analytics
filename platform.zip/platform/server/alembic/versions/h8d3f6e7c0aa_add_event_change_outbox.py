"""add event change notifications and refund jobs
Revision ID: h8d3f6e7c0aa
Revises: g7c2e5d6b9ff
"""
from alembic import op
import sqlalchemy as sa
revision="h8d3f6e7c0aa";down_revision="g7c2e5d6b9ff";branch_labels=None;depends_on=None
def upgrade():
    delivery=sa.Enum("PENDING","SENT","FAILED",name="deliverystatus");refund=sa.Enum("PENDING","COMPLETED","FAILED",name="refundjobstatus")
    op.create_table("event_notifications",sa.Column("id",sa.UUID(),primary_key=True),sa.Column("event_id",sa.UUID(),sa.ForeignKey("live_events.id"),nullable=False),sa.Column("fan_id",sa.String(),nullable=False),sa.Column("kind",sa.String(),nullable=False),sa.Column("payload",sa.Text(),nullable=False),sa.Column("status",delivery,nullable=False),sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.Column("sent_at",sa.DateTime(timezone=True)))
    op.create_index("ix_event_notifications_event_id","event_notifications",["event_id"]);op.create_index("ix_event_notifications_status_created","event_notifications",["status","created_at"])
    op.create_table("event_refund_jobs",sa.Column("id",sa.UUID(),primary_key=True),sa.Column("event_id",sa.UUID(),sa.ForeignKey("live_events.id"),nullable=False),sa.Column("ticket_id",sa.UUID(),sa.ForeignKey("ticket_purchases.id"),nullable=False),sa.Column("provider_payment_id",sa.String(),nullable=False),sa.Column("idempotency_key",sa.String(),nullable=False,unique=True),sa.Column("status",refund,nullable=False),sa.Column("error",sa.Text()),sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.Column("completed_at",sa.DateTime(timezone=True)),sa.UniqueConstraint("event_id","ticket_id",name="uq_event_refund_job_ticket"))
    op.create_index("ix_event_refund_jobs_event_id","event_refund_jobs",["event_id"]);op.create_index("ix_event_refund_jobs_status_created","event_refund_jobs",["status","created_at"])
def downgrade():
    op.drop_table("event_refund_jobs");op.drop_table("event_notifications");op.execute("DROP TYPE IF EXISTS refundjobstatus");op.execute("DROP TYPE IF EXISTS deliverystatus")
