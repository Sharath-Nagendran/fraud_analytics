"""add entitlements
Revision ID: b2d7f081c4aa
Revises: a1c4f0d2b9e7
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa
revision: str = "b2d7f081c4aa"
down_revision: Union[str, None] = "a1c4f0d2b9e7"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    op.create_table("entitlements",
        sa.Column("id", sa.UUID(), nullable=False),
        sa.Column("fan_id", sa.String(), nullable=False),
        sa.Column("event_id", sa.UUID(), nullable=False),
        sa.Column("source", sa.String(), nullable=False),
        sa.Column("status", sa.Enum("ACTIVE", "REVOKED", "EXPIRED", name="entitlementstatus"), nullable=False),
        sa.Column("valid_from", sa.DateTime(timezone=True), nullable=False),
        sa.Column("valid_until", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("fan_id", "event_id", name="uq_entitlement_fan_event"),
    )
    op.create_index("ix_entitlements_event_status", "entitlements", ["event_id", "status"])

def downgrade() -> None:
    op.drop_index("ix_entitlements_event_status", table_name="entitlements")
    op.drop_table("entitlements")
    op.execute("DROP TYPE IF EXISTS entitlementstatus")
