"""add ticket payments
Revision ID: c3e8a192d5bb
Revises: b2d7f081c4aa
"""
from alembic import op
import sqlalchemy as sa
revision="c3e8a192d5bb"; down_revision="b2d7f081c4aa"; branch_labels=None; depends_on=None
def upgrade():
    status=sa.Enum("PAID","REFUNDED","FAILED",name="ticketstatus")
    op.create_table("processed_payment_events",sa.Column("event_id",sa.String(),primary_key=True),sa.Column("event_type",sa.String(),nullable=False),sa.Column("processed_at",sa.DateTime(timezone=True),nullable=False))
    op.create_table("ticket_purchases",sa.Column("id",sa.UUID(),primary_key=True),sa.Column("event_id",sa.UUID(),sa.ForeignKey("live_events.id"),nullable=False),sa.Column("fan_id",sa.String(),nullable=False),sa.Column("entitlement_id",sa.UUID(),sa.ForeignKey("entitlements.id"),nullable=True),sa.Column("provider",sa.String(),nullable=False),sa.Column("provider_payment_id",sa.String(),nullable=False,unique=True),sa.Column("amount_cents",sa.Integer(),nullable=False),sa.Column("currency",sa.String(3),nullable=False),sa.Column("status",status,nullable=False),sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.Column("refunded_at",sa.DateTime(timezone=True)),sa.UniqueConstraint("event_id","fan_id",name="uq_ticket_event_fan"))
    op.create_index("ix_ticket_purchases_event_id","ticket_purchases",["event_id"]); op.create_index("ix_ticket_purchases_fan_id","ticket_purchases",["fan_id"])
def downgrade():
    op.drop_index("ix_ticket_purchases_fan_id",table_name="ticket_purchases"); op.drop_index("ix_ticket_purchases_event_id",table_name="ticket_purchases"); op.drop_table("ticket_purchases"); op.drop_table("processed_payment_events"); op.execute("DROP TYPE IF EXISTS ticketstatus")
