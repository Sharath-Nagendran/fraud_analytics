"""
add video asset storage identity

Revision ID: w1i5d4f6
Revises: v0h4c3e5
"""

from alembic import op
import sqlalchemy as sa


revision = "w1i5d4f6"
down_revision = "v0h4c3e5"
branch_labels = None
depends_on = None


def upgrade() -> None:

    op.add_column(
        "video_assets",
        sa.Column(
            "storage_provider",
            sa.String(50),
            nullable=True,
        ),
    )

    op.add_column(
        "video_assets",
        sa.Column(
            "storage_object_key",
            sa.String(1000),
            nullable=True,
        ),
    )

    op.create_index(
        "ix_video_assets_storage_identity",
        "video_assets",
        [
            "storage_provider",
            "storage_object_key",
        ],
        unique=False,
    )


def downgrade() -> None:

    op.drop_index(
        "ix_video_assets_storage_identity",
        table_name="video_assets",
    )

    op.drop_column(
        "video_assets",
        "storage_object_key",
    )

    op.drop_column(
        "video_assets",
        "storage_provider",
    )