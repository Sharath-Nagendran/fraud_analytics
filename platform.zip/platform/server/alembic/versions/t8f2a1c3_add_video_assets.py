"""
add video assets

Revision ID: t8f2a1c3
Revises: s7e1c4b8
"""

from alembic import op
import sqlalchemy as sa

revision = "t8f2a1c3"
down_revision = "s7e1c4b8"
branch_labels = None
depends_on = None


def upgrade():
    asset_type = sa.Enum(
        "UPLOAD",
        "LIVE_RECORDING",
        name="videoassettype",
        create_type=False,
    )

    visibility = sa.Enum(
        "PRIVATE",
        "PPV",
        "SUBSCRIPTION",
        "PUBLIC",
        name="videoassetvisibility",
        create_type=False,
    )

    status = sa.Enum(
        "PROCESSING",
        "READY",
        "FAILED",
        "ARCHIVED",
        name="videoassetstatus",
        create_type=False,
    )

    op.create_table(
        "video_assets",

        sa.Column(
            "id",
            sa.UUID(),
            primary_key=True,
        ),

        sa.Column(
            "artist_id",
            sa.String(),
            nullable=False,
        ),

        sa.Column(
            "source_live_event_id",
            sa.UUID(),
            sa.ForeignKey(
                "live_events.id"
            ),
            nullable=True,
        ),

        sa.Column(
            "title",
            sa.String(300),
            nullable=False,
        ),

        sa.Column(
            "description",
            sa.Text(),
            nullable=True,
        ),

        sa.Column(
            "asset_type",
            asset_type,
            nullable=False,
        ),

        sa.Column(
            "video_provider",
            sa.String(30),
            nullable=False,
        ),

        sa.Column(
            "video_asset_provider_id",
            sa.String(),
            nullable=True,
        ),

        sa.Column(
            "storage_url",
            sa.String(),
            nullable=True,
        ),

        sa.Column(
            "thumbnail_url",
            sa.String(),
            nullable=True,
        ),

        sa.Column(
            "duration_seconds",
            sa.Integer(),
            nullable=True,
        ),

        sa.Column(
            "visibility",
            visibility,
            nullable=False,
        ),

        sa.Column(
            "price_cents",
            sa.Integer(),
            nullable=True,
        ),

        sa.Column(
            "currency",
            sa.String(3),
            nullable=False,
        ),

        sa.Column(
            "status",
            status,
            nullable=False,
        ),

        sa.Column(
            "published_at",
            sa.DateTime(
                timezone=True
            ),
            nullable=True,
        ),

        sa.Column(
            "created_at",
            sa.DateTime(
                timezone=True
            ),
            nullable=False,
        ),

        sa.Column(
            "updated_at",
            sa.DateTime(
                timezone=True
            ),
            nullable=False,
        ),
    )

    op.create_index(
        "ix_video_assets_artist_id",
        "video_assets",
        ["artist_id"],
    )

    op.create_index(
        "ix_video_assets_source_live_event_id",
        "video_assets",
        ["source_live_event_id"],
    )

    op.create_index(
        "ix_video_assets_asset_type",
        "video_assets",
        ["asset_type"],
    )

    op.create_index(
        "ix_video_assets_visibility",
        "video_assets",
        ["visibility"],
    )

    op.create_index(
        "ix_video_assets_status",
        "video_assets",
        ["status"],
    )

    op.create_index(
        "ix_video_assets_provider",
        "video_assets",
        ["video_provider"],
    )


def downgrade():

    op.drop_index(
        "ix_video_assets_provider",
        table_name="video_assets",
    )

    op.drop_index(
        "ix_video_assets_status",
        table_name="video_assets",
    )

    op.drop_index(
        "ix_video_assets_visibility",
        table_name="video_assets",
    )

    op.drop_index(
        "ix_video_assets_asset_type",
        table_name="video_assets",
    )

    op.drop_index(
        "ix_video_assets_source_live_event_id",
        table_name="video_assets",
    )

    op.drop_index(
        "ix_video_assets_artist_id",
        table_name="video_assets",
    )

    op.drop_table(
        "video_assets"
    )

    op.execute(
        "DROP TYPE IF EXISTS videoassetstatus"
    )

    op.execute(
        "DROP TYPE IF EXISTS videoassetvisibility"
    )

    op.execute(
        "DROP TYPE IF EXISTS videoassettype"
    )