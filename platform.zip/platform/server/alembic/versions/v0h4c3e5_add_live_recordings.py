"""
add live recording lifecycle

Revision ID: v0h4c3e5
Revises: u9g3b2d4
"""

from alembic import op
import sqlalchemy as sa

from sqlalchemy.dialects import postgresql


revision = "v0h4c3e5"
down_revision = "u9g3b2d4"
branch_labels = None
depends_on = None


def upgrade() -> None:

    recording_status = postgresql.ENUM(
        "COLLECTING",
        "FINALIZING",
        "READY",
        "FAILED",
        name="liverecordingstatus",
        create_type=False,
    )

    span_status = postgresql.ENUM(
        "DISCOVERED",
        "DOWNLOADING",
        "DOWNLOADED",
        "MERGED",
        "FAILED",
        name="liverecordingspanstatus",
        create_type=False,
    )

    recording_status.create(
        op.get_bind(),
        checkfirst=True,
    )

    span_status.create(
        op.get_bind(),
        checkfirst=True,
    )

    op.create_table(
        "live_recordings",
        sa.Column(
            "id",
            sa.UUID(),
            nullable=False,
        ),
        sa.Column(
            "live_event_id",
            sa.UUID(),
            nullable=False,
        ),
        sa.Column(
            "stream_path",
            sa.String(255),
            nullable=False,
        ),
        sa.Column(
            "status",
            recording_status,
            nullable=False,
        ),
        sa.Column(
            "video_asset_id",
            sa.UUID(),
            nullable=True,
        ),
        sa.Column(
            "storage_provider",
            sa.String(50),
            nullable=True,
        ),
        sa.Column(
            "storage_object_key",
            sa.String(1000),
            nullable=True,
        ),
        sa.Column(
            "failure_reason",
            sa.Text(),
            nullable=True,
        ),
        sa.Column(
            "finalized_at",
            sa.DateTime(timezone=True),
            nullable=True,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ["live_event_id"],
            ["live_events.id"],
        ),
        sa.ForeignKeyConstraint(
            ["video_asset_id"],
            ["video_assets.id"],
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "live_event_id",
            name="uq_live_recordings_live_event",
        ),
        sa.UniqueConstraint(
            "video_asset_id",
            name="uq_live_recordings_video_asset",
        ),
    )

    op.create_index(
        "ix_live_recordings_live_event_id",
        "live_recordings",
        ["live_event_id"],
        unique=True,
    )

    op.create_table(
        "live_recording_spans",
        sa.Column(
            "id",
            sa.UUID(),
            nullable=False,
        ),
        sa.Column(
            "live_recording_id",
            sa.UUID(),
            nullable=False,
        ),
        sa.Column(
            "source_url",
            sa.Text(),
            nullable=False,
        ),
        sa.Column(
            "started_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),
        sa.Column(
            "duration_milliseconds",
            sa.Integer(),
            nullable=False,
        ),
        sa.Column(
            "status",
            span_status,
            nullable=False,
        ),
        sa.Column(
            "local_path",
            sa.Text(),
            nullable=True,
        ),
        sa.Column(
            "failure_reason",
            sa.Text(),
            nullable=True,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ["live_recording_id"],
            ["live_recordings.id"],
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "live_recording_id",
            "started_at",
            name="uq_live_recording_span_start",
        ),
    )

    op.create_index(
        "ix_live_recording_spans_live_recording_id",
        "live_recording_spans",
        ["live_recording_id"],
    )

    op.create_index(
        "ix_live_recording_spans_recording_status",
        "live_recording_spans",
        ["live_recording_id", "status"],
    )


def downgrade() -> None:

    op.drop_index(
        "ix_live_recording_spans_recording_status",
        table_name="live_recording_spans",
    )

    op.drop_index(
        "ix_live_recording_spans_live_recording_id",
        table_name="live_recording_spans",
    )

    op.drop_table(
        "live_recording_spans"
    )

    op.drop_index(
        "ix_live_recordings_live_event_id",
        table_name="live_recordings",
    )

    op.drop_table(
        "live_recordings"
    )

    op.execute(
        "DROP TYPE IF EXISTS "
        "liverecordingspanstatus"
    )

    op.execute(
        "DROP TYPE IF EXISTS "
        "liverecordingstatus"
    )