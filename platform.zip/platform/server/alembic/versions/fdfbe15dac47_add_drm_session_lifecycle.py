"""add drm session lifecycle

Revision ID: fdfbe15dac47
Revises: 2f0141d0b263
Create Date: 2026-10-04 16:04:20.552013

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'fdfbe15dac47'
down_revision: Union[str, None] = '2f0141d0b263'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    status = sa.Enum(
        "ACTIVE",
        "REVOKED",
        "EXPIRED",
        name="drmsessionstatus"
    )

    status.create(
        op.get_bind(),
        checkfirst=True
    )

    op.add_column(
        "drm_sessions",

        sa.Column(
            "status",
            status,
            nullable=True
        )
    )

    op.add_column(
        "drm_sessions",

        sa.Column(
            "expires_at",
            sa.DateTime(
                timezone=True
            ),
            nullable=True
        )
    )

    op.execute(
        """
        UPDATE drm_sessions
           SET status='ACTIVE'
        """
    )

    op.alter_column(
        "drm_sessions",
        "status",
        nullable=False
    )


def downgrade() -> None:
    pass
