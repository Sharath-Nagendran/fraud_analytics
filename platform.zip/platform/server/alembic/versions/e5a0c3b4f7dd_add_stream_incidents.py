"""add stream incidents and refund candidates
Revision ID: e5a0c3b4f7dd
Revises: d4f9b2a3e6cc
"""
from alembic import op
import sqlalchemy as sa
revision="e5a0c3b4f7dd";down_revision="d4f9b2a3e6cc";branch_labels=None;depends_on=None
def upgrade():
    incidentstatus=sa.Enum("OPEN","RECOVERED","REVIEW_REQUIRED","CLOSED",name="incidentstatus")
    candidatestatus=sa.Enum("PENDING_REVIEW","APPROVED","REJECTED","REFUNDED",name="refundcandidatestatus")
    op.create_table("stream_incidents",sa.Column("id",sa.UUID(),primary_key=True),sa.Column("event_id",sa.UUID(),sa.ForeignKey("live_events.id"),nullable=False),sa.Column("kind",sa.String(),nullable=False),sa.Column("status",incidentstatus,nullable=False),sa.Column("started_at",sa.DateTime(timezone=True),nullable=False),sa.Column("recovered_at",sa.DateTime(timezone=True)),sa.Column("duration_seconds",sa.Integer()),sa.Column("details",sa.Text()))
    op.create_index("ix_stream_incidents_event_id","stream_incidents",["event_id"])
    op.create_table("refund_candidates",sa.Column("id",sa.UUID(),primary_key=True),sa.Column("incident_id",sa.UUID(),sa.ForeignKey("stream_incidents.id"),nullable=False),sa.Column("ticket_id",sa.UUID(),sa.ForeignKey("ticket_purchases.id"),nullable=False),sa.Column("status",candidatestatus,nullable=False),sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.UniqueConstraint("incident_id","ticket_id",name="uq_refund_candidate_incident_ticket"))
    op.create_index("ix_refund_candidates_incident_id","refund_candidates",["incident_id"])
def downgrade():
    op.drop_index("ix_refund_candidates_incident_id",table_name="refund_candidates");op.drop_table("refund_candidates");op.drop_index("ix_stream_incidents_event_id",table_name="stream_incidents");op.drop_table("stream_incidents");op.execute("DROP TYPE IF EXISTS refundcandidatestatus");op.execute("DROP TYPE IF EXISTS incidentstatus")
