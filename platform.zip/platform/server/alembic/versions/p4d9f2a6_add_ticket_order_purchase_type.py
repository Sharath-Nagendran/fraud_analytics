"""add ticket order purchase type

Revision ID: p4d9f2a6
Revises: a4d1e0b3
"""
from alembic import op
import sqlalchemy as sa

revision = "p4d9f2a6"
down_revision = "a4d1e0b3"
branch_labels = None
depends_on = None


def upgrade():
    purchase_type = sa.Enum("LIVE_EVENT", "REPLAY", name="ticketordertype")
    purchase_type.create(op.get_bind(), checkfirst=True)
    op.add_column(
        "ticket_orders",
        sa.Column("purchase_type", purchase_type, nullable=False, server_default="LIVE_EVENT"),
    )
    op.create_index(
        "ix_ticket_orders_event_purchase_type",
        "ticket_orders",
        ["event_id", "purchase_type"],
        unique=False,
    )


def downgrade():
    op.drop_index("ix_ticket_orders_event_purchase_type", table_name="ticket_orders")
    op.drop_column("ticket_orders", "purchase_type")
    sa.Enum(name="ticketordertype").drop(op.get_bind(), checkfirst=True)
