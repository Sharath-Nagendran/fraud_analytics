﻿from logging.config import fileConfig

from sqlalchemy import engine_from_config
from sqlalchemy import pool

from alembic import context

from app.db.base import Base
from app.core.config import settings

# Import models so Alembic sees them
from app.models import live_event  # noqa: F401
from app.models import ticket  # noqa: F401
from app.models import entitlement  # noqa: F401
from app.models import ticket_tier  # noqa: F401
from app.models import ticket_ownership  # noqa: F401
from app.models import ticket_order  # noqa: F401

from app.models import compensation  # noqa: F401
from app.models import incident  # noqa: F401
from app.models import operational_alert  # noqa: F401
from app.models import event_change  # noqa: F401
from app.models import preissued_grant  # noqa: F401
from app.models import config  # noqa: F401
from app.models import video_webhook_event  # noqa: F401
from app.models import video_asset  # noqa: F401
from app.models import video_asset_entitlement  # noqa: F401
from app.models import live_recording  # noqa: F401
from app.models import replay_job  # noqa: F401
from app.models import chat  # noqa: F401

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# --- our addition #1: inject the DB URL from our own settings/.env ---
# Must be at this exact indentation level (column 0, not inside a function)
# so it runs unconditionally, before either run_migrations_* function below.
config.set_main_option("sqlalchemy.url", settings.database_url.replace("+asyncpg", ""))

# Interpret the config file for Python logging.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# --- our addition #2: point Alembic at our models' metadata ---
target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()

