import asyncio
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.config import settings
from app.db.base import AsyncSessionLocal
from app.services.replay_job_service import replay_job_service

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("replay-worker")


async def run() -> None:
    while True:
        try:
            async with AsyncSessionLocal() as db:
                recovered = await replay_job_service.recover_stale(
                    db,
                    stale_after_seconds=settings.replay_job_stale_after_seconds,
                )
                if recovered:
                    logger.warning("Recovered %s stale replay jobs", recovered)

                result = await replay_job_service.dispatch_one(db)

            if result is None:
                await asyncio.sleep(settings.replay_worker_poll_seconds)
            else:
                logger.info("Replay job result: %s", result)

        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Replay worker iteration failed")
            await asyncio.sleep(settings.replay_worker_poll_seconds)


if __name__ == "__main__":
    asyncio.run(run())
