import asyncio
import sys
from pathlib import Path

sys.path.insert(
    0,
    str(
        Path(__file__)
        .resolve()
        .parents[1]
    )
)
from app.storage import (get_storage_provider,)


async def main():

    provider = get_storage_provider()

    source = Path(
        "static/media/test-media.mp4"
    )

    stored = await provider.put_file(
        source_path=source,
        object_key=(
            "storage-test/"
            "test-media.mp4"
        ),
        content_type="video/mp4",
    )

    print(
        f"provider={stored.provider}"
    )

    print(
        f"key={stored.object_key}"
    )

    print(
        f"url={stored.storage_url}"
    )

    print(
        "exists="
        f"{await provider.exists(stored.object_key)}"
    )


if __name__ == "__main__":
    asyncio.run(main())