import json

import pytest

from app.core.setting_registry import REGISTRY, SettingValidationError, get_def
from app.db.seed import SEED_PATH


def test_seed_file_covers_exactly_the_registered_settings_and_is_valid():
    seed = json.loads(SEED_PATH.read_text(encoding="utf-8"))["settings"]
    assert set(seed) == set(REGISTRY)
    for key, value in seed.items():
        get_def(key).validate(value)


def test_seed_file_has_exactly_one_default_currency_and_it_is_active():
    currencies = json.loads(SEED_PATH.read_text(encoding="utf-8"))["currencies"]
    defaults = [c for c in currencies if c["is_default"]]
    assert len(defaults) == 1 and defaults[0]["is_active"]


@pytest.mark.parametrize(
    "key,value",
    [
        ("live.idle_timeout_seconds", True),  # bool is not an int here
        ("live.idle_timeout_seconds", 0),
        ("mux.playback_policy", "drm"),
        ("mux.rtmp_ingest_url", "http://example.invalid"),
        ("mux.reduced_latency", "false"),
    ],
)
def test_invalid_values_are_rejected(key, value):
    with pytest.raises(SettingValidationError):
        get_def(key).validate(value)


def test_unknown_key_is_rejected():
    with pytest.raises(SettingValidationError):
        get_def("nope")
