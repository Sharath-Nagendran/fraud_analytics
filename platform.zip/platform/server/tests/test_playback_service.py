from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, MagicMock
import pytest
from fastapi import HTTPException
from app.models.entitlement import Entitlement, EntitlementStatus
from app.models.live_event import LiveEvent, LiveEventStatus
from app.services.playback_service import MockPlaybackTokenProvider, PlaybackService

@pytest.mark.asyncio
async def test_denies_fan_without_entitlement():
    db = AsyncMock()
    db.get.return_value = LiveEvent(id=None, status=LiveEventStatus.LIVE, mux_playback_id="pb-1")
    result = MagicMock(); result.scalar_one_or_none.return_value = None
    db.execute.return_value = result
    with pytest.raises(HTTPException) as exc:
        await PlaybackService(MockPlaybackTokenProvider()).issue_token(db, "fan-1", "event-1")
    assert exc.value.status_code == 403

@pytest.mark.asyncio
async def test_mock_mode_issues_same_contract_without_mux():
    db = AsyncMock()
    event = LiveEvent(status=LiveEventStatus.LIVE, mux_playback_id="pb-1")
    event.id = __import__('uuid').uuid4()
    db.get.return_value = event
    entitlement = Entitlement(fan_id="fan-1", event_id=event.id, status=EntitlementStatus.ACTIVE,
                              valid_from=datetime.now(timezone.utc)-timedelta(minutes=1))
    result = MagicMock(); result.scalar_one_or_none.return_value = entitlement
    db.execute.return_value = result
    out = await PlaybackService(MockPlaybackTokenProvider()).issue_token(db, "fan-1", str(event.id))
    assert out["mode"] == "mock"
    assert out["token"].startswith("mock-playback-token-")
    assert out["playback_id"] == "pb-1"
