import pytest
from pydantic import ValidationError

from app.core.config import Settings
from app.services.mux_service import FakeMuxService, StreamOptions

# A complete, valid deployment configuration. Tests override single fields.
VALID = dict(
    database_url="postgresql+asyncpg://u:p@h/db",
    environment="development",
    mux_stub_mode=True,
    settings_cache_ttl_seconds=30,
)


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    # Settings(...) also reads real environment variables; make sure none leak in.
    for name in (
        "DATABASE_URL", "ENVIRONMENT", "MUX_STUB_MODE", "SETTINGS_CACHE_TTL_SECONDS",
        "MUX_TOKEN_ID", "MUX_TOKEN_SECRET", "MUX_WEBHOOK_SECRET", "ADMIN_USER_IDS",
    ):
        monkeypatch.delenv(name, raising=False)


def make(**overrides) -> Settings:
    return Settings(_env_file=None, **{**VALID, **overrides})


def test_nothing_is_defaulted_in_code():
    for key in VALID:
        data = {k: v for k, v in VALID.items() if k != key}
        with pytest.raises(ValidationError):
            Settings(_env_file=None, **data)


def test_stub_mode_needs_no_mux_credentials():
    assert make().mux_stub_mode is True


def test_real_mode_requires_credentials():
    with pytest.raises(ValidationError) as exc:
        make(mux_stub_mode=False)
    assert "MUX_TOKEN_ID" in str(exc.value)


def test_real_mode_with_credentials_is_valid():
    s = make(
        mux_stub_mode=False,
        mux_token_id="id",
        mux_token_secret="secret",
        mux_webhook_secret="whsec",
        mux_signing_key_id="signing-key",
        mux_signing_private_key="private-key",
    )
    assert s.mux_stub_mode is False


def test_stub_mode_is_refused_in_production():
    with pytest.raises(ValidationError):
        make(environment="production")


def test_negative_cache_ttl_is_rejected():
    with pytest.raises(ValidationError):
        make(settings_cache_ttl_seconds=-1)


def test_admin_list_is_empty_unless_configured():
    assert make().admin_user_id_list == []
    assert make(admin_user_ids=" a , b ,").admin_user_id_list == ["a", "b"]


OPTIONS = StreamOptions(
    reconnect_window_seconds=1,
    reduced_latency=False,
    playback_policy="signed",
    rtmp_ingest_url="rtmps://example.invalid/app",
)


def test_fake_mux_returns_the_same_shape_as_the_real_service():
    data = FakeMuxService().create_live_stream("event-1", OPTIONS)
    assert set(data) == {
        "mux_live_stream_id",
        "mux_stream_key",
        "mux_playback_id",
        "rtmp_ingest_url",
    }
    assert data["rtmp_ingest_url"] == OPTIONS.rtmp_ingest_url
    assert data["mux_live_stream_id"].startswith("fake-")


def test_fake_mux_complete_and_delete_do_not_raise():
    svc = FakeMuxService()
    svc.complete_live_stream("fake-1")
    svc.delete_live_stream("fake-1")
