"""
Integration tests against a real Postgres. Skipped unless TEST_DATABASE_URL is
set (use a throw-away database: tables are created and dropped by these tests).

    set TEST_DATABASE_URL=postgresql+asyncpg://user:pass@localhost/platform_test
"""
import os

import pytest
import pytest_asyncio
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.core.setting_registry import REGISTRY
from app.db.base import Base
from app.db.seed import seed
from app.models.config import ConfigAuditLog
from app.models.live_event import LiveEvent  # noqa: F401 — registers the table
from app.services.config_service import ConfigError, ConfigService

URL = os.environ.get("TEST_DATABASE_URL")
pytestmark = pytest.mark.skipif(not URL, reason="TEST_DATABASE_URL not set")


@pytest_asyncio.fixture
async def factory():
    engine = create_async_engine(URL)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield async_sessionmaker(engine, expire_on_commit=False)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest_asyncio.fixture
async def svc(factory):
    await seed(session_factory=factory)
    return ConfigService(session_factory=factory)


@pytest.mark.asyncio
async def test_startup_fails_before_seed_and_passes_after(factory):
    s = ConfigService(session_factory=factory)
    with pytest.raises(ConfigError):
        await s.validate_startup()
    await seed(session_factory=factory)
    await s.validate_startup()


@pytest.mark.asyncio
async def test_seed_is_idempotent_and_never_overwrites_admin_changes(factory, svc):
    async with factory() as db:
        await svc.update_setting(db, "admin-1", "live.idle_timeout_seconds", 999)
    again = await seed(session_factory=factory)
    assert again == {"settings": 0, "currencies": 0}
    assert await svc.get_setting("live.idle_timeout_seconds") == 999


@pytest.mark.asyncio
async def test_resolve_currency_default_explicit_and_unsupported(svc):
    default = await svc.default_currency()
    assert (await svc.resolve_currency(None)).code == default.code
    assert (await svc.resolve_currency("usd")).code == "USD"
    with pytest.raises(HTTPException) as exc:
        await svc.resolve_currency("XXX")
    assert exc.value.status_code == 422


@pytest.mark.asyncio
async def test_changing_default_leaves_exactly_one_default(factory, svc):
    async with factory() as db:
        await svc.update_currency(db, "admin-1", "USD", is_default=True)
    defaults = [c for c in await svc.list_currencies() if c.is_default]
    assert [c.code for c in defaults] == ["USD"]


@pytest.mark.asyncio
async def test_default_currency_cannot_be_deactivated_or_unset(factory, svc):
    default = (await svc.default_currency()).code
    async with factory() as db:
        with pytest.raises(HTTPException) as exc:
            await svc.update_currency(db, "admin-1", default, is_active=False)
        assert exc.value.status_code == 409
    async with factory() as db:
        with pytest.raises(HTTPException):
            await svc.update_currency(db, "admin-1", default, is_default=False)


@pytest.mark.asyncio
async def test_deactivated_currency_is_rejected_for_new_events(factory, svc):
    async with factory() as db:
        await svc.update_currency(db, "admin-1", "EUR", is_active=False)
    with pytest.raises(HTTPException):
        await svc.resolve_currency("EUR")


@pytest.mark.asyncio
async def test_minor_unit_cannot_change_while_events_use_the_currency(factory, svc):
    from datetime import datetime, timezone

    async with factory() as db:
        db.add(
            LiveEvent(
                artist_id="a",
                title="t",
                scheduled_start=datetime.now(timezone.utc),
                ticket_price_cents=100,
                currency="USD",
                status="SCHEDULED",
            )
        )
        await db.commit()
    async with factory() as db:
        with pytest.raises(HTTPException) as exc:
            await svc.update_currency(db, "admin-1", "USD", minor_unit=0)
        assert exc.value.status_code == 409


@pytest.mark.asyncio
async def test_setting_update_validates_and_writes_an_audit_row(factory, svc):
    async with factory() as db:
        with pytest.raises(HTTPException) as exc:
            await svc.update_setting(db, "admin-1", "mux.playback_policy", "drm")
        assert exc.value.status_code == 422
    async with factory() as db:
        await svc.update_setting(db, "admin-1", "mux.reduced_latency", True)
    async with factory() as db:
        rows = (
            await db.execute(select(ConfigAuditLog).where(ConfigAuditLog.entity_key == "mux.reduced_latency"))
        ).scalars().all()
    assert len(rows) == 1 and rows[0].changed_by == "admin-1" and rows[0].new_value is True
    assert await svc.get_setting("mux.reduced_latency") is True


@pytest.mark.asyncio
async def test_every_registered_setting_is_seeded(svc):
    for key in REGISTRY:
        await svc.get_setting(key)
