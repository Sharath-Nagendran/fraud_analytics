from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pydantic

from app.models.live_event import LiveEvent, LiveEventStatus
from app.schemas.live_event import CreateLiveEventRequest
from app.services.config_service import CurrencyInfo
from app.services.live_service import LiveService


def test_create_live_event_request_rejects_a_past_date():
    """The Pydantic schema itself blocks a past scheduled_start before any
    service or database code ever runs."""
    with pytest.raises(pydantic.ValidationError):
        CreateLiveEventRequest(
            title="Test show",
            scheduled_start=datetime.now(timezone.utc) - timedelta(minutes=1),
            ticket_price_cents=500,
        )


@pytest.mark.asyncio
async def test_create_event_calls_mux_and_returns_the_ingest_credentials():
    service = LiveService()
    db = AsyncMock()
    db.add = MagicMock()  # AsyncSession.add is synchronous
    ingest_url = "rtmps://example.invalid/app"
    setting_values = {
        "mux.reconnect_window_seconds": 1,
        "mux.reduced_latency": False,
        "mux.playback_policy": "signed",
        "mux.rtmp_ingest_url": ingest_url,
    }

    with patch("app.services.live_service.mux_service") as mock_mux, patch(
        "app.services.live_service.config_service"
    ) as mock_cfg:
        mock_cfg.resolve_currency = AsyncMock(
            return_value=CurrencyInfo("XYZ", "Test Currency", 2, True, True)
        )
        mock_cfg.get_setting = AsyncMock(side_effect=lambda key: setting_values[key])
        mock_mux.create_live_stream.return_value = {
            "mux_live_stream_id": "mux-1",
            "mux_stream_key": "secret-key",
            "mux_playback_id": "pb-1",
            "rtmp_ingest_url": ingest_url,
        }

        payload = CreateLiveEventRequest(
            title="Test show",
            scheduled_start=datetime.now(timezone.utc) + timedelta(hours=1),
            ticket_price_cents=500,
        )

        result = await service.create_event(db, "artist-1", payload)

        mock_cfg.resolve_currency.assert_awaited_once_with(None)  # no currency in request
        assert mock_mux.create_live_stream.called
        assert result["currency"] == "XYZ"  # came from the config service, not code
        assert result["rtmp_ingest_url"] == ingest_url
        assert result["stream_key"] == "secret-key"
        assert result["status"] == LiveEventStatus.SCHEDULED.value


@pytest.mark.asyncio
async def test_cancel_refuses_an_event_that_is_already_live():
    service = LiveService()
    db = AsyncMock()
    db.get.return_value = LiveEvent(artist_id="artist-1", status=LiveEventStatus.LIVE)

    with pytest.raises(Exception) as exc_info:
        await service.cancel(db, "artist-1", "event-1")
    assert exc_info.value.status_code == 400


@pytest.mark.asyncio
async def test_cancel_refuses_an_event_owned_by_a_different_artist():
    service = LiveService()
    db = AsyncMock()
    db.get.return_value = LiveEvent(artist_id="someone-else", status=LiveEventStatus.SCHEDULED)

    with pytest.raises(Exception) as exc_info:
        await service.cancel(db, "artist-1", "event-1")
    assert exc_info.value.status_code == 403
