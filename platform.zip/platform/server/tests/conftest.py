"""
Test isolation: the app builds its global `settings` object at import time from
the environment / .env. Tests must never depend on (or leak) a developer's real
.env, so a neutral environment is installed just long enough to import the app
config, then removed again. Tests that need other values build `Settings(...)`
explicitly (see test_mux_mode.py).
"""
import os

_TEST_ENV = {
    "DATABASE_URL": "postgresql+asyncpg://test:test@localhost/test_unused",
    "ENVIRONMENT": "development",
    "MUX_STUB_MODE": "true",
    "SETTINGS_CACHE_TTL_SECONDS": "0",
    "MUX_TOKEN_ID": "",
    "MUX_TOKEN_SECRET": "",
    "MUX_WEBHOOK_SECRET": "",
    "PLAYBACK_TOKEN_TTL_SECONDS": "300",
    "ADMIN_USER_IDS": "",
}

_saved = {k: os.environ.get(k) for k in _TEST_ENV}
os.environ.update(_TEST_ENV)
try:
    import app.core.config  # noqa: E402,F401 — builds the global settings from _TEST_ENV
finally:
    for _k, _v in _saved.items():
        if _v is None:
            os.environ.pop(_k, None)
        else:
            os.environ[_k] = _v
