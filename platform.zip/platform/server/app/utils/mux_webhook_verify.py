import hashlib
import hmac
import time

from fastapi import HTTPException

from app.core.config import settings


def verify_mux_signature(
    raw_body: bytes, signature_header: str | None, tolerance_seconds: int
) -> None:
    """
    Verifies that an incoming webhook actually came from Mux, not an
    attacker forging a "video.live_stream.active" event to fake entitlement
    or state.

    Mux's header looks like: `Mux-Signature: t=1565220904,v1=<hex-signature>`
    The expected signature is HMAC-SHA256 of `f"{timestamp}.{raw_body}"`
    using the webhook signing secret. This is Mux's officially documented
    manual-verification scheme (https://www.mux.com/docs/core/verify-webhook-signatures)
    — their SDK convenience helpers for this only exist for Node and
    Elixir, so Python implements it directly rather than guessing at an
    SDK method that may not exist.
    """
    if not settings.mux_webhook_secret:
        raise RuntimeError("MUX_WEBHOOK_SECRET is not set — see .env.example")
    if not signature_header:
        raise HTTPException(401, "Missing Mux-Signature header")

    try:
        parts = dict(part.split("=", 1) for part in signature_header.split(","))
        timestamp = parts["t"]
        signature = parts["v1"]
    except (KeyError, ValueError) as exc:
        raise HTTPException(401, "Malformed Mux-Signature header") from exc

    if abs(time.time() - int(timestamp)) > tolerance_seconds:
        raise HTTPException(401, "Mux webhook timestamp outside tolerance window")

    signed_payload = f"{timestamp}.{raw_body.decode('utf-8')}".encode("utf-8")
    expected_signature = hmac.new(
        settings.mux_webhook_secret.encode("utf-8"), signed_payload, hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(expected_signature, signature):
        raise HTTPException(401, "Invalid Mux webhook signature")
