from fastapi import (
    APIRouter,
    Depends,
)

from sqlalchemy.ext.asyncio import AsyncSession

from app.api.playback_router import (
    get_current_fan_id,
)

from app.db.base import get_db

from app.schemas.video_asset_playback import (
    VideoAssetPlaybackRequest,
    VideoAssetPlaybackResponse,
)

from app.services.video_asset_playback_service import (
    video_asset_playback_service,
)


router = APIRouter(
    prefix="/video-assets",
    tags=["video-asset-playback"],
)


@router.post(
    "/{asset_id}/playback-token",
    response_model=VideoAssetPlaybackResponse,
)
async def issue_video_asset_playback_token(
    asset_id: str,
    payload: VideoAssetPlaybackRequest | None = None,
    fan_id: str = Depends(
        get_current_fan_id
    ),
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await (
        video_asset_playback_service.issue_grant(
            db=db,
            asset_id=asset_id,
            fan_id=fan_id,
            requested_session_id=(
                payload.session_id
                if payload
                else None
            ),
        )
    )