from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.base import get_db
from app.schemas.ticket import PurchaseTicketRequest, RefundTicketRequest, TicketResponse
from app.services.ticket_service import ticket_service
router = APIRouter(prefix="/tickets", tags=["tickets"])

@router.post("/purchase", response_model=TicketResponse, status_code=201)
async def purchase_ticket(payload: PurchaseTicketRequest, db: AsyncSession = Depends(get_db)):
    """D5: mock payment confirmation creates an immediately usable entitlement."""
    return await ticket_service.purchase(db, payload)

@router.post("/refund", response_model=TicketResponse)
async def refund_ticket(payload: RefundTicketRequest, db: AsyncSession = Depends(get_db)):
    """D7: refund revokes the entitlement, active sessions and pre-issued token."""
    return await ticket_service.refund(db, payload)
