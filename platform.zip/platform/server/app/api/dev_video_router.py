from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import get_db
from app.services.video_webhook_service import (
    video_webhook_service,
)

router = APIRouter(
    prefix="/dev/video-events",
    tags=["dev-video"],
)


@router.post("/fastpix")
async def simulate_fastpix(
    payload: dict,
    db: AsyncSession = Depends(get_db),
):
    return await (
        video_webhook_service.process_fastpix_event(
            db,
            payload,
        )
    )