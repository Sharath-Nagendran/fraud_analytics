from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import require_admin
from app.db.base import get_db
from app.schemas.config import (
    CurrencyAdmin,
    CurrencyCreate,
    CurrencyPublic,
    CurrencyUpdate,
    SettingOut,
    SettingUpdate,
)
from app.services.config_service import config_service

public_router = APIRouter(tags=["config"])
admin_router = APIRouter(prefix="/admin", tags=["admin-config"])


@public_router.get("/currencies", response_model=list[CurrencyPublic])
async def list_active_currencies():
    """Active currencies for pickers in the app (no auth)."""
    return await config_service.list_currencies(active_only=True)


@admin_router.get("/currencies", response_model=list[CurrencyAdmin])
async def admin_list_currencies(_: str = Depends(require_admin)):
    return await config_service.list_currencies()


@admin_router.post("/currencies", response_model=CurrencyAdmin, status_code=201)
async def admin_create_currency(
    payload: CurrencyCreate,
    admin_id: str = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    return await config_service.create_currency(db, admin_id, **payload.model_dump())


@admin_router.patch("/currencies/{code}", response_model=CurrencyAdmin)
async def admin_update_currency(
    code: str,
    payload: CurrencyUpdate,
    admin_id: str = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    return await config_service.update_currency(
        db, admin_id, code, **payload.model_dump(exclude_unset=True)
    )


@admin_router.get("/settings", response_model=list[SettingOut])
async def admin_list_settings(
    _: str = Depends(require_admin), db: AsyncSession = Depends(get_db)
):
    return await config_service.list_settings(db)


@admin_router.put("/settings/{key}", response_model=SettingOut)
async def admin_update_setting(
    key: str,
    payload: SettingUpdate,
    admin_id: str = Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    return await config_service.update_setting(db, admin_id, key, payload.value)
