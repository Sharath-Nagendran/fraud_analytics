from fastapi import APIRouter,Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.base import get_db
from app.schemas.health import CandidateDecisionRequest,EventHealth,IncidentResponse,SimulateOutageRequest
from app.services.health_service import health_service
router=APIRouter(prefix="/admin",tags=["monitoring"])
@router.get("/live-events/{event_id}/health",response_model=EventHealth)
async def event_health(event_id:str,db:AsyncSession=Depends(get_db)):return await health_service.health(db,event_id)
@router.post("/live-events/{event_id}/simulate-outage",response_model=IncidentResponse)
async def simulate_outage(event_id:str,payload:SimulateOutageRequest,db:AsyncSession=Depends(get_db)):return await health_service.simulate_outage(db,event_id,payload)
@router.post("/refund-candidates/{candidate_id}/decision")
async def decide(candidate_id:str,payload:CandidateDecisionRequest,db:AsyncSession=Depends(get_db)):return await health_service.decide_candidate(db,candidate_id,payload.decision)
