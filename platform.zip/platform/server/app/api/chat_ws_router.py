from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

from app.chat.connection_manager import (
    chat_connection_manager,
)
from app.db.base import AsyncSessionLocal
from app.services.chat_ws_service import (
    chat_websocket_service,
)


router = APIRouter(tags=["chat-websocket"])


@router.websocket("/ws/chat/{room_id}")
async def chat_websocket(
    websocket: WebSocket,
    room_id: str,
):
    participant_type = websocket.query_params.get(
        "participant_type",
        "",
    )
    participant_id = websocket.query_params.get(
        "participant_id",
        "",
    )

    if not participant_type or not participant_id:
        await websocket.close(
            code=4400,
            reason=(
                "participant_type and participant_id "
                "are required"
            ),
        )
        return

    try:
        async with AsyncSessionLocal() as db:
            room, participant = (
                await chat_websocket_service.authorize(
                    db=db,
                    room_id=room_id,
                    participant_type=participant_type,
                    participant_id=participant_id,
                )
            )

    except Exception as exc:
        status_code = getattr(exc, "status_code", 500)
        detail = getattr(exc, "detail", "Chat connection failed")

        close_code = {
            400: 4400,
            403: 4403,
            404: 4404,
            409: 4409,
        }.get(status_code, 4500)

        await websocket.close(
            code=close_code,
            reason=str(detail)[:120],
        )
        return

    connection = await chat_connection_manager.connect(
        room_id=str(room.id),
        participant_id=participant.participant_id,
        participant_type=participant.participant_type.value,
        websocket=websocket,
    )

    await websocket.send_json(
        {
            "type": "connection.ready",
            "room_id": str(room.id),
            "participant_id": participant.participant_id,
            "participant_type": participant.participant_type.value,
            "connection_id": connection.connection_id,
            "active_connections": (
                await chat_connection_manager.count(
                    str(room.id)
                )
            ),
        }
    )

    try:
        while True:
            payload = await websocket.receive_json()
            event_type = payload.get("type")

            if event_type == "ping":
                await websocket.send_json(
                    {
                        "type": "pong",
                    }
                )
            else:
                await websocket.send_json(
                    {
                        "type": "error",
                        "code": "UNSUPPORTED_EVENT",
                        "message": (
                            "Messages must be created through "
                            "the HTTP chat API"
                        ),
                    }
                )

    except WebSocketDisconnect:
        pass

    finally:
        await chat_connection_manager.disconnect(
            str(room.id),
            connection.connection_id,
        )

        if (
            websocket.application_state
            == WebSocketState.CONNECTED
        ):
            await websocket.close()
