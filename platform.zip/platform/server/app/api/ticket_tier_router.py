from uuid import UUID
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.api.deps import get_current_artist_id
from app.db.base import get_db
from app.schemas.ticket_tier import CreateTicketTierRequest, PurchaseTierRequest, TicketTierResponse
from app.services.ticket_tier_service import ticket_tier_service

router = APIRouter(tags=["ticket-tiers"])

@router.post("/live-events/{event_id}/ticket-tiers", response_model=TicketTierResponse, status_code=201)
async def create_ticket_tier(event_id: UUID, payload: CreateTicketTierRequest,
                             artist_id: str = Depends(get_current_artist_id),
                             db: AsyncSession = Depends(get_db)):
    return await ticket_tier_service.create(db, artist_id, event_id, payload)

@router.get("/live-events/{event_id}/ticket-tiers", response_model=list[TicketTierResponse])
async def list_ticket_tiers(event_id: UUID, db: AsyncSession = Depends(get_db)):
    return await ticket_tier_service.list_for_event(db, event_id)

@router.post("/live-events/{event_id}/purchase-tier", status_code=201)
async def purchase_ticket_tier(event_id: UUID, payload: PurchaseTierRequest,
                               db: AsyncSession = Depends(get_db)):
    return await ticket_tier_service.purchase(db, event_id, payload)
