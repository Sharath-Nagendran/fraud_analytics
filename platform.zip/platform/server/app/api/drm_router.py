from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
)
from uuid import UUID
from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.base import get_db

from app.models.live_event import (
    LiveEvent,
    LiveEventStatus,
)
import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.api.playback_router import (
    get_current_fan_id,
)

from app.db.base import get_db

from app.schemas.drm import (
    DrmLicenseRequest,
    DrmLicenseResponse,
)

from app.services.drm_provider_resolver import (
    drm_provider_resolver
)
from app.services.playback_service import (
    playback_service,
)

router = APIRouter(
    tags=["drm"]
)


@router.get(
    "/live-events/{event_id}/drm"
)
async def drm_status(
    event_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    provider = (
        await drm_provider_resolver.resolve(db)
    )

    return {
        "enabled": True,
        "provider":
            provider.__class__.__name__
    }


@router.post(
    "/live-events/{event_id}/drm-license",
    response_model=DrmLicenseResponse
)
async def drm_license(
    event_id: str,
    payload: DrmLicenseRequest,
    fan_id: str = Depends(
        get_current_fan_id
    ),
    db: AsyncSession = Depends(
        get_db
    )
):

    #
    # Reuse entitlement validation.
    #
    try:
        event_key = uuid.UUID(event_id)

    except ValueError:

        raise HTTPException(
            404,
            "Event not found"
        )

    live_event = await db.get(
        LiveEvent,
        event_key
    )

    if not live_event:
        raise HTTPException(
            404,
            "Event not found"
        )

    access_type = (
        "REPLAY"
        if live_event.status
           == LiveEventStatus.ARCHIVED
        else "LIVE"
    )

    entitlement = await playback_service.entitlement(
        db,
        fan_id,
        event_key,
        access_type
    )

    provider = (
        await drm_provider_resolver.resolve(
            db
        )
    )
    result = await provider.issue_license(db=db, event_id=event_key, fan_id=fan_id, entitlement_id=entitlement.id,
        playback_session_id=payload.session_id)

    return result