from datetime import datetime,timezone
from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.api.deps import get_current_artist_id
from app.db.base import get_db
from app.schemas.event_change import DispatchRequest,DispatchSummary,EventChangeStatus,EventChangeSummary
from app.schemas.live_event import LiveEventPublic,RescheduleLiveEventRequest
from app.services.event_change_service import event_change_service
router=APIRouter(tags=["event-changes"])
@router.patch("/event-management/live-events/{event_id}/reschedule",response_model=LiveEventPublic)
async def reschedule(event_id:str,payload:RescheduleLiveEventRequest,artist_id:str=Depends(get_current_artist_id),db:AsyncSession=Depends(get_db)):
    now=datetime.now(payload.scheduled_start.tzinfo) if payload.scheduled_start.tzinfo else datetime.now()
    if payload.scheduled_start<=now:raise HTTPException(422,"scheduled_start must be in the future")
    event,_,_=await event_change_service.reschedule(db,artist_id,event_id,payload.scheduled_start);return event
@router.post("/event-management/live-events/{event_id}/cancel",response_model=EventChangeSummary)
async def cancel(event_id:str,artist_id:str=Depends(get_current_artist_id),db:AsyncSession=Depends(get_db)):return await event_change_service.cancel(db,artist_id,event_id)
@router.get("/event-management/live-events/{event_id}/status",response_model=EventChangeStatus)
async def status(event_id:str,db:AsyncSession=Depends(get_db)):return await event_change_service.status(db,event_id)
@router.post("/admin/event-change-jobs/dispatch",response_model=DispatchSummary)
async def dispatch(payload:DispatchRequest,db:AsyncSession=Depends(get_db)):return await event_change_service.dispatch(db,payload.batch_size)
