from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.base import get_db
from app.models.operational_alert import AlertStatus
from app.schemas.operational_alert import (
    AlertActionRequest,
    AlertDispatchRequest,
    AlertDispatchResponse,
    AlertSignalRequest,
    AlertSummary,
    OperationalAlertResponse,
)
from app.services.operational_alert_service import operational_alert_service

router = APIRouter(tags=["operational-alerts"])

@router.get("/admin/alerts", response_model=list[OperationalAlertResponse])
async def list_alerts(event_id: str | None = None, status: AlertStatus | None = None,
                      db: AsyncSession = Depends(get_db)):
    return await operational_alert_service.list_alerts(db, event_id, status)

@router.get("/admin/alerts/summary", response_model=AlertSummary)
async def alert_summary(db: AsyncSession = Depends(get_db)):
    return await operational_alert_service.summary(db)

@router.post("/admin/alerts/{alert_id}/acknowledge", response_model=OperationalAlertResponse)
async def acknowledge(alert_id: str, payload: AlertActionRequest, db: AsyncSession = Depends(get_db)):
    return await operational_alert_service.acknowledge(db, alert_id, payload.operator_id, payload.note)

@router.post("/admin/alerts/{alert_id}/resolve", response_model=OperationalAlertResponse)
async def resolve(alert_id: str, payload: AlertActionRequest, db: AsyncSession = Depends(get_db)):
    return await operational_alert_service.resolve(db, alert_id, payload.operator_id, payload.note)

@router.post("/admin/alert-deliveries/dispatch", response_model=AlertDispatchResponse)
async def dispatch(payload: AlertDispatchRequest, db: AsyncSession = Depends(get_db)):
    return await operational_alert_service.dispatch(db, payload.batch_size)

@router.post("/dev/monitoring/live-events/{event_id}/ingest-failure", response_model=OperationalAlertResponse)
async def simulate_ingest_failure(event_id: str, payload: AlertSignalRequest,
                                  db: AsyncSession = Depends(get_db)):
    if not settings.mux_stub_mode:
        from fastapi import HTTPException
        raise HTTPException(404, "Not found")
    return await operational_alert_service.signal_ingest_failure(db, event_id, payload.details)

@router.post("/dev/monitoring/live-events/{event_id}/playback-errors", response_model=OperationalAlertResponse)
async def simulate_playback_errors(event_id: str, payload: AlertSignalRequest,
                                   db: AsyncSession = Depends(get_db)):
    if not settings.mux_stub_mode:
        from fastapi import HTTPException
        raise HTTPException(404, "Not found")
    return await operational_alert_service.signal_playback_errors(
        db, event_id, payload.error_rate_percent or 0.0, payload.details
    )
