from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_artist_id
from app.db.base import get_db
from app.schemas.live_event import (CreateLiveEventRequest, RescheduleLiveEventRequest, LiveEventPublic, LiveEventCreateResponse, IngestCredentials,)
from app.services.live_service import live_service
from app.schemas.live_recording import (FinalizeLiveEventResponse,)
from app.schemas.live_recording import (FinalizeLiveEventResponse,RecordingDiscoveryResponse,)
from app.services.recording_locator_service import (recording_locator_service,)
from app.schemas.live_recording import (FinalizeLiveEventResponse,RecordingDiscoveryResponse,RecordingDownloadResponse,)
from app.services.recording_download_service import (recording_download_service,)
from app.schemas.live_recording import (FinalizeLiveEventResponse,RecordingDiscoveryResponse,RecordingDownloadResponse,ReplayAssemblyResponse,)
from app.services.replay_assembly_service import (replay_assembly_service,)
from app.schemas.live_recording import (FinalizeLiveEventResponse,RecordingDiscoveryResponse,RecordingDownloadResponse,ReplayAssemblyResponse,ReplayPipelineResponse,)
from app.services.replay_pipeline_service import (replay_pipeline_service,)
from app.schemas.replay_job import (ReplayJobResponse,)
from app.services.replay_job_service import (replay_job_service,)

router = APIRouter(prefix="/live-events", tags=["live-events"])


@router.post("", response_model=LiveEventCreateResponse)
async def create_event(
    payload: CreateLiveEventRequest,
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    """A1-A4: artist schedules a new live event."""
    return await live_service.create_event(db, artist_id, payload)


@router.get("/{event_id}", response_model=LiveEventPublic)
async def get_public_event(event_id: str, db: AsyncSession = Depends(get_db)):
    """A5: fan-facing event detail for the lobby/countdown screen. No auth
    required — ticket/entitlement checks happen later, in the D-group
    playback-token endpoint, not here."""
    return await live_service.get_public_event(db, event_id)


@router.get("/{event_id}/ingest-credentials", response_model=IngestCredentials)
async def get_ingest_credentials(
    event_id: str,
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    """A3: artist retrieves their own ingest credentials again later."""
    return await live_service.get_ingest_credentials(db, artist_id, event_id)


@router.patch("/{event_id}/reschedule", response_model=LiveEventPublic)
async def reschedule(
    event_id: str,
    payload: RescheduleLiveEventRequest,
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    """A6: reschedule before going live."""
    return await live_service.reschedule(db, artist_id, event_id, payload)


@router.delete("/{event_id}", response_model=LiveEventPublic)
async def cancel(
    event_id: str,
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    """A6: cancel before going live."""
    return await live_service.cancel(db, artist_id, event_id)


@router.post("/{event_id}/end", response_model=LiveEventPublic)
async def end_broadcast(
    event_id: str,
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    """B7: artist explicitly ends their own broadcast."""
    return await live_service.end_broadcast(db, artist_id, event_id)

@router.post(
    "/{event_id}/finalize",
    response_model=FinalizeLiveEventResponse,
)
async def finalize_live_event(event_id: str,
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),):
    return await live_service.finalize_event(db=db, artist_id=artist_id, event_id=event_id,)

@router.post(
    "/{event_id}/recordings/discover",
    response_model=RecordingDiscoveryResponse,
)
async def discover_live_recordings(event_id: str, artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    return await recording_locator_service.discover(db=db, artist_id=artist_id, event_id=event_id,)

@router.post("/{event_id}/recordings/download",response_model=RecordingDownloadResponse,)
async def download_live_recordings(event_id: str, artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    return await recording_download_service.download(db=db, artist_id=artist_id, event_id=event_id,)

@router.post("/{event_id}/recordings/assemble",response_model=ReplayAssemblyResponse,)
async def assemble_live_replay(event_id: str,artist_id: str = Depends(get_current_artist_id),db: AsyncSession = Depends(get_db),):
    return await replay_assembly_service.assemble(db=db,artist_id=artist_id,event_id=event_id,)

@router.post(
    "/{event_id}/recordings/process",
    response_model=ReplayPipelineResponse,
)
async def process_live_replay(event_id: str,artist_id: str = Depends(get_current_artist_id),db: AsyncSession = Depends(get_db),):
    return await replay_pipeline_service.process(db=db,artist_id=artist_id,event_id=event_id,)

@router.get(
    "/{event_id}/replay-status",
    response_model=ReplayJobResponse,
)
async def get_replay_status(event_id: str,artist_id: str = Depends(get_current_artist_id),db: AsyncSession = Depends(get_db),):
    return await replay_job_service.get_for_artist(db=db, artist_id=artist_id, event_id=event_id,)