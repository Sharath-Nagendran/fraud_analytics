from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.api.playback_router import get_current_fan_id
from app.db.base import get_db
from app.schemas.replay import ReplayDetails, ReplayTokenRequest, ReplayTokenResponse
from app.services.archive_service import archive_service

router = APIRouter(tags=["replay"])

@router.get("/live-events/{event_id}/replay", response_model=ReplayDetails)
async def replay_details(event_id: str, db: AsyncSession = Depends(get_db)):
    return await archive_service.details(db, event_id)

@router.post("/live-events/{event_id}/replay-token", response_model=ReplayTokenResponse)
async def replay_token(event_id: str, payload: ReplayTokenRequest | None = None,
                       fan_id: str = Depends(get_current_fan_id), db: AsyncSession = Depends(get_db)):
    return await archive_service.token(db, event_id, fan_id, payload.session_id if payload else None)

@router.post("/dev/archive/{event_id}", response_model=ReplayDetails)
async def mock_archive(event_id: str, db: AsyncSession = Depends(get_db)):
    event = await archive_service.archive_mock(db, event_id)
    return {"event_id": event.id, "status": event.status.value, "available": True, "archived_at": event.archived_at}
