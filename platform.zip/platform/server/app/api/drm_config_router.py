from fastapi import (APIRouter, Depends, HTTPException)

from sqlalchemy.ext.asyncio import (AsyncSession)

from app.db.base import (get_db)

from app.schemas.drm_config import (DrmConfigResponse, DrmConfigUpdate)

from app.services.drm_config_service import (drm_config_service)

router = APIRouter(
    prefix="/admin/drm",
    tags=["drm-config"]
)


@router.get(
    "/config",
    response_model=DrmConfigResponse
)
async def config(
    db: AsyncSession = Depends(get_db)
):
    return await drm_config_service.get(db)


@router.put(
    "/config",
    response_model=DrmConfigResponse
)
async def update_config(
    payload:DrmConfigUpdate,
    db: AsyncSession = Depends(get_db)
):
    try:
        return await drm_config_service.update( db, payload, )
    except ValueError as exc:
        raise HTTPException( status_code=422, detail=str(exc), ) from exc