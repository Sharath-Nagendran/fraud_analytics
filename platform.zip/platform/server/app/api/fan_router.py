from pathlib import Path
from fastapi import APIRouter
from fastapi.responses import FileResponse

router = APIRouter(tags=["fan-ui"])
_UI = Path(__file__).resolve().parents[1] / "static" / "fan" / "index.html"

@router.get("/fan/live/{event_id}", include_in_schema=False)
async def fan_live_page(event_id: str) -> FileResponse:
    # The event id is read from location.pathname by the browser application.
    return FileResponse(_UI, media_type="text/html")
