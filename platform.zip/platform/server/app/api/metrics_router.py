from fastapi import APIRouter,Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.base import get_db
from app.schemas.metrics import PlatformMetrics
from app.services.metrics_service import metrics_service
router=APIRouter(prefix='/admin',tags=['monitoring'])
@router.get('/metrics',response_model=PlatformMetrics)
async def metrics(db:AsyncSession=Depends(get_db)):
    return await metrics_service.platform(db)
