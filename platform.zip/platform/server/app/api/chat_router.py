from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_artist_id, get_current_fan_id
from app.db.base import get_db
from app.schemas.chat import (
    ChatMessageCreateRequest,
    ChatMessagePageResponse,
    ChatMessageResponse,
    ChatParticipantResponse,
    ChatRoomResponse,
)
from app.services.chat_service import chat_service


router = APIRouter(prefix="/chat", tags=["chat"])

@router.get("/live-events/{event_id}/room", response_model=ChatRoomResponse,)
async def get_live_event_chat_room(event_id: str, artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    return await chat_service.get_live_event_room(db=db, artist_id=artist_id, event_id=event_id,)

@router.post(
    "/live-events/{event_id}/room",
    response_model=ChatRoomResponse,
)
async def create_live_event_chat_room(
    event_id: str,
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    return await chat_service.create_live_event_room(
        db, artist_id, event_id
    )

@router.get("/live-events/{event_id}/fan/room", response_model=ChatRoomResponse,)
async def get_live_event_chat_room_for_fan(event_id: str, fan_id: str = Depends(get_current_fan_id), db: AsyncSession = Depends(get_db),):
    return await chat_service.get_live_event_room_for_fan(db=db, fan_id=fan_id, event_id=event_id,)

@router.post(
    "/rooms/{room_id}/artist/join",
    response_model=ChatParticipantResponse,
)
async def join_chat_as_artist(
    room_id: str,
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    return await chat_service.join_artist(db, room_id, artist_id)


@router.post(
    "/rooms/{room_id}/fan/join",
    response_model=ChatParticipantResponse,
)
async def join_chat_as_fan(
    room_id: str,
    fan_id: str = Depends(get_current_fan_id),
    db: AsyncSession = Depends(get_db),
):
    return await chat_service.join_fan(db, room_id, fan_id)


@router.post(
    "/rooms/{room_id}/artist/messages",
    response_model=ChatMessageResponse,
)
async def send_artist_chat_message(
    room_id: str,
    payload: ChatMessageCreateRequest,
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    return await chat_service.send_artist_message(
        db,
        room_id,
        artist_id,
        payload.client_message_id,
        payload.body,
    )


@router.post(
    "/rooms/{room_id}/fan/messages",
    response_model=ChatMessageResponse,
)
async def send_fan_chat_message(
    room_id: str,
    payload: ChatMessageCreateRequest,
    fan_id: str = Depends(get_current_fan_id),
    db: AsyncSession = Depends(get_db),
):
    return await chat_service.send_fan_message(
        db,
        room_id,
        fan_id,
        payload.client_message_id,
        payload.body,
    )


@router.get(
    "/rooms/{room_id}/artist/messages",
    response_model=ChatMessagePageResponse,
)
async def list_artist_chat_messages(
    room_id: str,
    after_sequence: int | None = Query(default=None, ge=0),
    limit: int = Query(default=100, ge=1, le=200),
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    return await chat_service.list_for_artist(
        db, room_id, artist_id, after_sequence, limit
    )


@router.get(
    "/rooms/{room_id}/fan/messages",
    response_model=ChatMessagePageResponse,
)
async def list_fan_chat_messages(
    room_id: str,
    after_sequence: int | None = Query(default=None, ge=0),
    limit: int = Query(default=100, ge=1, le=200),
    fan_id: str = Depends(get_current_fan_id),
    db: AsyncSession = Depends(get_db),
):
    return await chat_service.list_for_fan(
        db, room_id, fan_id, after_sequence, limit
    )
