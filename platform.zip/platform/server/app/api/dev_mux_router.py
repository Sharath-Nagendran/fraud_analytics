"""
Mock-mode only: lets you drive an event through the lifecycle that real Mux
webhooks would normally drive. Only mounted when MUX_STUB_MODE=true (see
main.py), so none of these routes exist when real Mux is in use.

Typical run:
  POST /live-events                      -> SCHEDULED
  POST /dev/mux/{id}/go-live             -> LIVE      (video.live_stream.active)
  POST /live-events/{id}/end             -> ENDED     (artist presses End Stream)
  POST /dev/mux/{id}/asset-ready         -> ARCHIVED  (video.asset.live_stream_completed)
"""
import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import get_db
from app.models.live_event import LiveEvent
from app.services.live_service import live_service

router = APIRouter(prefix="/dev/mux", tags=["dev-mock-mux"])


async def _mux_id(db: AsyncSession, event_id: str) -> str:
    try:
        key = uuid.UUID(event_id)
    except ValueError:
        raise HTTPException(404, "Event not found")
    event = await db.get(LiveEvent, key)
    if not event or not event.mux_live_stream_id:
        raise HTTPException(404, "Event not found or has no Mux stream")
    return event.mux_live_stream_id


@router.post("/{event_id}/go-live")
async def go_live(event_id: str, db: AsyncSession = Depends(get_db)):
    """Simulates video.live_stream.active."""
    await live_service.handle_stream_active(db, await _mux_id(db, event_id))
    return {"simulated": "video.live_stream.active"}


@router.post("/{event_id}/disconnect")
async def disconnect(event_id: str, db: AsyncSession = Depends(get_db)):
    """Simulates video.live_stream.idle (starts the real idle-timeout timer)."""
    await live_service.handle_stream_idle(db, await _mux_id(db, event_id))
    return {"simulated": "video.live_stream.idle"}


@router.post("/{event_id}/asset-ready")
async def asset_ready(event_id: str, db: AsyncSession = Depends(get_db)):
    """Simulates video.asset.live_stream_completed."""
    await live_service.handle_asset_ready(
        db, await _mux_id(db, event_id), f"fake-asset-{uuid.uuid4()}"
    )
    return {"simulated": "video.asset.live_stream_completed"}
