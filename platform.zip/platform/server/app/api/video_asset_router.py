from fastapi import (
    APIRouter,
    Depends,
)

from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import (
    get_current_artist_id,
)

from app.db.base import get_db

from app.schemas.video_asset import (
    CreateVideoAssetRequest,
    PublishVideoAssetResponse,
    UpdateVideoAssetRequest,
    VideoAssetArtistResponse,
    VideoAssetPublicResponse,
)

from app.services.video_asset_service import (
    video_asset_service,
)


router = APIRouter(
    prefix="/video-assets",
    tags=["video-assets"],
)


@router.post(
    "",
    response_model=VideoAssetArtistResponse,
    status_code=201,
)
async def create_video_asset(
    payload: CreateVideoAssetRequest,
    artist_id: str = Depends(
        get_current_artist_id
    ),
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await video_asset_service.create(
        db=db,
        artist_id=artist_id,
        payload=payload,
    )


@router.get(
    "",
    response_model=list[
        VideoAssetArtistResponse
    ],
)
async def list_my_video_assets(
    artist_id: str = Depends(
        get_current_artist_id
    ),
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await (
        video_asset_service.list_for_artist(
            db=db,
            artist_id=artist_id,
        )
    )


@router.get(
    "/artist/{asset_id}",
    response_model=VideoAssetArtistResponse,
)
async def get_my_video_asset(
    asset_id: str,
    artist_id: str = Depends(
        get_current_artist_id
    ),
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await (
        video_asset_service.get_for_artist(
            db=db,
            asset_id=asset_id,
            artist_id=artist_id,
        )
    )


@router.patch(
    "/artist/{asset_id}",
    response_model=VideoAssetArtistResponse,
)
async def update_my_video_asset(
    asset_id: str,
    payload: UpdateVideoAssetRequest,
    artist_id: str = Depends(
        get_current_artist_id
    ),
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await video_asset_service.update(
        db=db,
        asset_id=asset_id,
        artist_id=artist_id,
        payload=payload,
    )


@router.post(
    "/artist/{asset_id}/publish",
    response_model=PublishVideoAssetResponse,
)
async def publish_my_video_asset(
    asset_id: str,
    artist_id: str = Depends(
        get_current_artist_id
    ),
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await video_asset_service.publish(
        db=db,
        asset_id=asset_id,
        artist_id=artist_id,
    )

@router.get(
    "/catalog",
    response_model=list[
        VideoAssetPublicResponse
    ],
)
async def list_public_video_assets(
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await (
        video_asset_service.list_public_catalog(
            db=db,
        )
    )

@router.get(
    "/{asset_id}",
    response_model=VideoAssetPublicResponse,
)
async def get_public_video_asset(
    asset_id: str,
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await video_asset_service.get_public(
        db=db,
        asset_id=asset_id,
    )