from fastapi import (APIRouter, Depends)

from sqlalchemy import select

from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import get_db

from app.models.drm_session import (DrmSession)

from app.services.drm_lifecycle_service import (drm_lifecycle_service)

router = APIRouter(
    prefix="/admin/drm",
    tags=["drm-admin"]
)


@router.get(
    "/sessions"
)
async def sessions(
    db: AsyncSession = Depends(get_db)
):
    rows = (
        await db.execute(
            select(DrmSession)
            .order_by(DrmSession.created_at.desc())
        )
    ).scalars().all()
    return rows


@router.post(
    "/expire"
)
async def expire(
    db: AsyncSession = Depends(get_db)
):
    return await drm_lifecycle_service.expire_sessions(db)