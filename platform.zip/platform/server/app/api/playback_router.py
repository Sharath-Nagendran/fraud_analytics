﻿import uuid
from fastapi import APIRouter,Depends,Header,HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.db.base import get_db
from app.models.entitlement import Entitlement
from app.models.live_event import LiveEvent
from app.schemas.playback import MockEntitlementRequest,PlaybackTokenRequest,PlaybackTokenResponse
from app.services.playback_service import playback_service
from app.services.preissue_service import preissue_service

router=APIRouter(tags=["playback"])
async def get_current_fan_id(x_test_fan_id:str|None=Header(default=None,alias="x-test-fan-id")):
    if not x_test_fan_id:raise HTTPException(401,"Missing x-test-fan-id header (development auth stub)")
    return x_test_fan_id

@router.post(
    "/live-events/{event_id}/playback-token",
    response_model=PlaybackTokenResponse
)
async def issue(
    event_id:str,
    payload:PlaybackTokenRequest|None=None,
    fan_id:str=Depends(get_current_fan_id),
    db:AsyncSession=Depends(get_db)
):
    #
    # D3 pre-issued tokens
    # Provider-neutral pre-issuance will be implemented
    # in a later sprint.
    #
    '''
    if not payload or not payload.session_id:

        preissued = await preissue_service.claim(
            db,
            event_id,
            fan_id
        )

        if preissued:
            return preissued
    '''
    return await playback_service.issue_token(
        db,
        fan_id,
        event_id,
        payload.session_id if payload else None
    )

@router.delete("/live-events/{event_id}/playback-sessions/{session_id}",status_code=204)
async def release(event_id:str,session_id:str,fan_id:str=Depends(get_current_fan_id),db:AsyncSession=Depends(get_db)):
    await playback_service.release_session(db,fan_id,event_id,session_id)
@router.post("/dev/entitlements/{event_id}",status_code=201)
async def grant(event_id:str,payload:MockEntitlementRequest,db:AsyncSession=Depends(get_db)):
    if not settings.mux_stub_mode:raise HTTPException(404,"Not found")
    try:key=uuid.UUID(event_id)
    except ValueError:raise HTTPException(404,"Event not found")
    if not await db.get(LiveEvent,key):raise HTTPException(404,"Event not found")
    db.add(Entitlement(fan_id=payload.fan_id,event_id=key,source="MOCK"));await db.commit();return {"granted":True,"fan_id":payload.fan_id,"event_id":event_id}

@router.post("/dev/preissue/{event_id}")
async def preissue(
    event_id:str,
    db:AsyncSession=Depends(get_db)
):
    if not settings.mux_stub_mode:
        raise HTTPException(404,"Not found")

    return await preissue_service.run_for_event(
        db,
        event_id,
        500
    )
