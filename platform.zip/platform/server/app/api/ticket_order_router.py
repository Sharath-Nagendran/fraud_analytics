from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import get_db
from app.schemas.ticket_order import CreateTicketOrderRequest, TicketOrderResponse
from app.services.ticket_order_service import ticket_order_service

router = APIRouter(prefix="/ticket-orders", tags=["ticket-orders"])


async def current_fan(x_test_fan_id: str | None = Header(default=None, alias="x-test-fan-id")) -> str:
    if not x_test_fan_id:
        raise HTTPException(401, "Missing x-test-fan-id header")
    return x_test_fan_id


@router.post("", response_model=TicketOrderResponse, status_code=201)
async def create_order(payload: CreateTicketOrderRequest, db: AsyncSession = Depends(get_db)):
    # Maintains compatibility with the existing purchase endpoint, where the fan
    # identity is supplied in the request body during local development.
    return await ticket_order_service.create(db, payload)


@router.get("", response_model=list[TicketOrderResponse])
async def list_orders(fan_id: str = Depends(current_fan), db: AsyncSession = Depends(get_db)):
    return await ticket_order_service.list_for_buyer(db, fan_id)


@router.get("/{order_id}", response_model=TicketOrderResponse)
async def get_order(order_id: str, fan_id: str = Depends(current_fan), db: AsyncSession = Depends(get_db)):
    return await ticket_order_service.get(db, order_id, fan_id)
