from fastapi import APIRouter

from app.services.video_reconciliation_runner import (
    video_reconciliation_runner,
)


router = APIRouter(
    prefix="/admin/video-reconciliation",
    tags=["video-reconciliation"],
)


@router.post("/run")
async def run_video_reconciliation():
    result = (
        await video_reconciliation_runner
        .run_once()
    )

    if result is None:
        return {
            "started": False,
            "reason": (
                "A reconciliation run is already active"
            ),
        }

    return result