from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import get_db
from app.schemas.security import EventSecurityAudit
from app.services.security_audit_service import security_audit_service

router = APIRouter(prefix="/admin/security", tags=["security"])

@router.get("/live-events/{event_id}/audit", response_model=EventSecurityAudit)
async def audit_live_event(event_id: str, db: AsyncSession = Depends(get_db)):
    """C1-C3 readiness audit. Mock mode reports unverifiable provider controls honestly."""
    return await security_audit_service.audit_event(db, event_id)
