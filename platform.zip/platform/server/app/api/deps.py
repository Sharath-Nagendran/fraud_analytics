from fastapi import Depends, Header, HTTPException

from app.core.config import settings
from fastapi import Header


def get_current_fan_id(x_test_fan_id: str = Header(alias="x-test-fan-id",),) -> str:
    return x_test_fan_id

async def get_current_artist_id(x_test_artist_id: str | None = Header(default=None, alias="x-test-artist-id"),) -> str:
    """
    ⚠️ TEMPORARY STUB — DO NOT SHIP TO PRODUCTION.

    The real version of this dependency belongs to the identity module
    (AUTH-01 through AUTH-06 in the master backlog) and should verify a
    real Clerk session JWT. This stand-in exists only so the live-video
    module can be tested in isolation before that module is built.

    Send a header `x-test-artist-id: <any-string>` on your requests, and
    this treats that as the logged-in user's ID. There is no real
    verification happening — anyone can claim to be any artist. That's
    intentional and fine for local testing, and a serious security hole if
    this ever reaches a real deployment.
    """
    if not x_test_artist_id:
        raise HTTPException(401,"Missing x-test-artist-id header (stub auth — see app/api/deps.py)",)
    return x_test_artist_id


async def require_admin(user_id: str = Depends(get_current_artist_id)) -> str:
    """
    ⚠️ TEMPORARY — gates /admin/* by an allow-list of user IDs from the
    ADMIN_USER_IDS setting (empty list = nobody). Replace with a real role
    check from the identity module (AUTH-*) once it exists; because
    get_current_artist_id is itself a stub, do not expose /admin/* publicly yet.
    """
    if user_id not in settings.admin_user_id_list:
        raise HTTPException(403, "Admin access required")
    return user_id
