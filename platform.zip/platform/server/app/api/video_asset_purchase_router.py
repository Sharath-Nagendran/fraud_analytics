from fastapi import (
    APIRouter,
    Depends,
)

from sqlalchemy.ext.asyncio import AsyncSession

from app.api.playback_router import (
    get_current_fan_id,
)

from app.db.base import get_db

from app.schemas.video_asset_purchase import (
    PurchaseVideoAssetRequest,
    VideoAssetEntitlementResponse,
    VideoAssetPurchaseResponse,
)

from app.services.video_asset_purchase_service import (
    video_asset_purchase_service,
)


router = APIRouter(
    prefix="/video-assets",
    tags=["video-asset-purchases"],
)


@router.post(
    "/{asset_id}/purchase",
    response_model=VideoAssetPurchaseResponse,
    status_code=201,
)
async def purchase_video_asset(
    asset_id: str,
    payload: PurchaseVideoAssetRequest,
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await video_asset_purchase_service.purchase(
        db=db,
        asset_id=asset_id,
        fan_id=payload.fan_id,
        idempotency_key=payload.idempotency_key,
    )


@router.get(
    "/{asset_id}/entitlement",
    response_model=VideoAssetEntitlementResponse,
)
async def get_video_asset_entitlement(
    asset_id: str,
    fan_id: str = Depends(
        get_current_fan_id
    ),
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await (
        video_asset_purchase_service
        .get_entitlement(
            db=db,
            asset_id=asset_id,
            fan_id=fan_id,
        )
    )


@router.get(
    "/entitlements/mine",
    response_model=list[
        VideoAssetEntitlementResponse
    ],
)
async def list_my_video_asset_entitlements(
    fan_id: str = Depends(
        get_current_fan_id
    ),
    db: AsyncSession = Depends(
        get_db
    ),
):
    return await (
        video_asset_purchase_service
        .list_for_fan(
            db=db,
            fan_id=fan_id,
        )
    )