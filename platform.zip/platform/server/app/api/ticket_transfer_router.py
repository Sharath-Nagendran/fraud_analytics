from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.base import get_db
from app.schemas.ticket_transfer import InitiateTransferRequest, OwnedTicketResponse, TransferResponse
from app.services.ticket_transfer_service import ticket_transfer_service
router = APIRouter(tags=["ticket-ownership"])
async def current_fan(x_test_fan_id: str | None = Header(default=None, alias="x-test-fan-id")):
    if not x_test_fan_id: raise HTTPException(401, "Missing x-test-fan-id header")
    return x_test_fan_id
@router.post("/tickets/{ticket_id}/transfers", response_model=TransferResponse, status_code=201)
async def initiate(ticket_id: str, payload: InitiateTransferRequest, fan_id: str = Depends(current_fan), db: AsyncSession = Depends(get_db)):
    return await ticket_transfer_service.initiate(db,ticket_id,fan_id,payload.to_fan_id,payload.idempotency_key,payload.message)
@router.post("/ticket-transfers/{transfer_id}/accept", response_model=TransferResponse)
async def accept(transfer_id: str, fan_id: str = Depends(current_fan), db: AsyncSession = Depends(get_db)): return await ticket_transfer_service.accept(db,transfer_id,fan_id)
@router.post("/ticket-transfers/{transfer_id}/cancel", response_model=TransferResponse)
async def cancel(transfer_id: str, fan_id: str = Depends(current_fan), db: AsyncSession = Depends(get_db)): return await ticket_transfer_service.cancel(db,transfer_id,fan_id)
@router.post("/ticket-transfers/{transfer_id}/decline", response_model=TransferResponse)
async def decline(transfer_id: str, fan_id: str = Depends(current_fan), db: AsyncSession = Depends(get_db)): return await ticket_transfer_service.decline(db,transfer_id,fan_id)
@router.get("/tickets/my-tickets", response_model=list[OwnedTicketResponse])
async def my_tickets(fan_id: str = Depends(current_fan), db: AsyncSession = Depends(get_db)): return await ticket_transfer_service.my_tickets(db,fan_id)
@router.get("/ticket-transfers", response_model=list[TransferResponse])
async def transfers(fan_id: str = Depends(current_fan), db: AsyncSession = Depends(get_db)): return await ticket_transfer_service.transfers(db,fan_id)
