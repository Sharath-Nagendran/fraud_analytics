from fastapi import APIRouter, Depends, File, Form, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_artist_id
from app.db.base import get_db
from app.models.video_asset import VideoAssetVisibility
from app.schemas.video_asset import VideoAssetArtistResponse
from app.services.video_asset_upload_service import (
    video_asset_upload_service,
)


router = APIRouter(
    prefix="/video-assets/artist",
    tags=["video-asset-uploads"],
)


@router.post(
    "/upload",
    response_model=VideoAssetArtistResponse,
    status_code=201,
)
async def upload_video_asset(
    file: UploadFile = File(...),
    title: str = Form(...),
    description: str | None = Form(default=None),
    visibility: VideoAssetVisibility = Form(
        default=VideoAssetVisibility.PRIVATE
    ),
    price_cents: int | None = Form(default=None),
    currency: str = Form(default="GBP"),
    artist_id: str = Depends(get_current_artist_id),
    db: AsyncSession = Depends(get_db),
):
    return await video_asset_upload_service.upload(
        db=db,
        artist_id=artist_id,
        file=file,
        title=title,
        description=description,
        visibility=visibility,
        price_cents=price_cents,
        currency=currency,
    )
