from fastapi import APIRouter, Request

from app.db.base import AsyncSessionLocal
from app.services.config_service import config_service
from app.services.live_service import live_service
from app.utils.mux_webhook_verify import verify_mux_signature

router = APIRouter(prefix="/webhooks/mux", tags=["webhooks"])


@router.post("")
async def handle_mux_webhook(request: Request):
    """
    All Mux webhook types are delivered to one endpoint; we branch on
    `event["type"]`. Unlike the NestJS version, FastAPI's `request.body()`
    gives you the raw bytes directly — no special app-level configuration
    needed to get at the raw body for signature verification.
    """
    raw_body = await request.body()
    signature_header = request.headers.get("mux-signature")
    tolerance = await config_service.get_setting("mux.webhook_tolerance_seconds")
    verify_mux_signature(raw_body, signature_header, tolerance)

    event = await request.json()
    event_type = event.get("type")
    data = event.get("data", {})

    async with AsyncSessionLocal() as db:
        if event_type == "video.live_stream.active":
            await live_service.handle_stream_active(db, data["id"])
        elif event_type == "video.live_stream.idle":
            await live_service.handle_stream_idle(db, data["id"])
        elif event_type == "video.asset.live_stream_completed":
            await live_service.handle_asset_ready(db, data["live_stream_id"], data["id"])
        # Anything else is ignored — not every Mux event type belongs to
        # this module (e.g. events for on-demand, non-live assets).

    # Always 200 quickly — Mux retries on non-2xx, and slow/failing
    # responses here can cause duplicate delivery and backlog.
    return {"received": True}
