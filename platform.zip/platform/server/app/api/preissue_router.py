from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.base import get_db
from app.schemas.preissue import PreissueRunRequest, PreissueRunResponse, PreissueStatusResponse
from app.services.preissue_service import preissue_service

router = APIRouter(prefix="/admin/preissue", tags=["preissue"])

@router.post("/{event_id}/run", response_model=PreissueRunResponse)
async def run_preissue(event_id: str, payload: PreissueRunRequest, db: AsyncSession = Depends(get_db)):
    return await preissue_service.run_for_event(db, event_id, payload.batch_size)

@router.get("/{event_id}/status", response_model=PreissueStatusResponse)
async def preissue_status(event_id: str, db: AsyncSession = Depends(get_db)):
    return await preissue_service.status(db, event_id)
