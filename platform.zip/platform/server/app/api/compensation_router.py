from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.base import get_db
from app.schemas.compensation import (
    ApproveCompensationRequest,
    CompensationApprovalResponse,
    CompensationCaseResponse,
    CompensationDispatchRequest,
    CompensationDispatchResponse,
    CompensationReconcileResponse,
    CompensationSummary,
    RejectCompensationRequest,
)
from app.services.compensation_service import compensation_service

router = APIRouter(prefix="/admin", tags=["outage-compensation"])


@router.post("/incidents/{incident_id}/compensation/approve", response_model=CompensationApprovalResponse)
async def approve(incident_id: str, payload: ApproveCompensationRequest,
                  db: AsyncSession = Depends(get_db)):
    return await compensation_service.approve_incident(db, incident_id, payload.operator_id)


@router.post("/incidents/{incident_id}/compensation/reject")
async def reject(incident_id: str, payload: RejectCompensationRequest,
                 db: AsyncSession = Depends(get_db)):
    return await compensation_service.reject_incident(db, incident_id, payload.operator_id, payload.reason)


@router.get("/incidents/{incident_id}/compensation/cases", response_model=list[CompensationCaseResponse])
async def cases(incident_id: str, db: AsyncSession = Depends(get_db)):
    return await compensation_service.list_cases(db, incident_id)


@router.get("/incidents/{incident_id}/compensation/summary", response_model=CompensationSummary)
async def summary(incident_id: str, db: AsyncSession = Depends(get_db)):
    return await compensation_service.summary(db, incident_id)


@router.post("/compensation-jobs/dispatch", response_model=CompensationDispatchResponse)
async def dispatch(payload: CompensationDispatchRequest,
                   db: AsyncSession = Depends(get_db)):
    return await compensation_service.dispatch(db, payload.batch_size)


@router.post("/compensation-jobs/reconcile", response_model=CompensationReconcileResponse)
async def reconcile(payload: CompensationDispatchRequest,
                    db: AsyncSession = Depends(get_db)):
    return await compensation_service.reconcile(db, payload.batch_size)
