﻿from app.api.ticket_order_router import router as ticket_order_router
from app.api.compensation_router import router as compensation_router
from app.api.operational_alert_router import router as operational_alert_router
from app.api.event_change_router import router as event_change_router
from app.api.preissue_router import router as preissue_router
from app.api.ticket_tier_router import router as ticket_tier_router
from app.api.security_router import router as security_router
from app.core.security_middleware import SecurityHeadersMiddleware
from app.api.health_router import router as health_router
from app.api.metrics_router import router as metrics_router
from app.api.replay_router import router as replay_router
from app.api.ticket_router import router as ticket_router
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi.staticfiles import StaticFiles

from fastapi import FastAPI

from app.api.config_router import admin_router, public_router
from app.api.live_router import router as live_router
from app.api.mux_webhook_router import router as mux_webhook_router
from app.api.playback_router import router as playback_router
from app.core.config import settings
from app.services.config_service import config_service
from app.api.fan_router import router as fan_router
from app.api.ticket_transfer_router import router as ticket_transfer_router
from app.api.drm_router import router as drm_router
from app.api.drm_audit_router import (router as drm_audit_router)
from app.api.drm_admin_router import (router as drm_admin_router)
from app.api.drm_config_router import (router as drm_config_router)
from app.api.dev_video_router import (router as dev_video_router,)
from app.api.video_reconciliation_router import (router as video_reconciliation_router,)
from app.services.video_reconciliation_runner import (video_reconciliation_runner,)
from app.api.video_asset_router import (router as video_asset_router)
from app.api.video_asset_purchase_router import (router as video_asset_purchase_router,)
from app.api.video_asset_playback_router import (router as video_asset_playback_router,)
from app.api.video_asset_upload_router import (router as video_asset_upload_router,)
from app.api.chat_router import (router as chat_router,)
from app.api.chat_ws_router import (router as chat_ws_router,)

@asynccontextmanager
async def lifespan(_: FastAPI):
    await config_service.validate_startup()
    await video_reconciliation_runner.start()
    try:
        yield
    finally:
        await video_reconciliation_runner.stop()


app = FastAPI(title="Music Platform API", lifespan=lifespan)

STATIC_DIR = (Path(__file__).resolve().parents[1]/ "static")
MEDIA_DIR = (STATIC_DIR/ "media")
MEDIA_DIR.mkdir(parents=True,exist_ok=True,)
app.mount("/media",StaticFiles(directory=str(MEDIA_DIR)),name="media",)

app.include_router(live_router)
app.include_router(mux_webhook_router)
app.include_router(playback_router)
app.include_router(public_router)
app.include_router(admin_router)
app.include_router(fan_router)
app.include_router(ticket_transfer_router)
app.include_router(drm_router)
app.include_router(drm_audit_router)
app.include_router(drm_admin_router)
app.include_router(drm_config_router)
app.include_router(dev_video_router)
app.include_router(video_reconciliation_router)
app.include_router(video_asset_router)
app.include_router(video_asset_purchase_router)
app.include_router(video_asset_playback_router)
app.include_router(video_asset_upload_router)
app.include_router(chat_router)
app.include_router(chat_ws_router)

if settings.mux_stub_mode:
    # Mock mode: expose lifecycle simulation endpoints. Absent in real mode.
    from app.api.dev_mux_router import router as dev_mux_router

    app.include_router(dev_mux_router)
    logging.getLogger(__name__).warning(
        "MUX_STUB_MODE is ON â€” Mux is mocked, /dev/mux/* endpoints are enabled"
    )


@app.get("/health")
async def health():
    return {"status": "ok", "mux_mode": "mock" if settings.mux_stub_mode else "real"}
app.include_router(ticket_router)
app.include_router(replay_router)


app.include_router(metrics_router)
app.include_router(health_router)
app.add_middleware(SecurityHeadersMiddleware)
app.include_router(security_router)
app.include_router(ticket_tier_router)
app.include_router(preissue_router)
app.include_router(event_change_router)
app.include_router(operational_alert_router)
app.include_router(compensation_router)
app.include_router(ticket_order_router)

