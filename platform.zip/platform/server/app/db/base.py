from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase

from app.core.config import settings


class Base(DeclarativeBase):
    pass


# NOTE: the connection string must use the `postgresql+asyncpg://` prefix,
# not the plain `postgresql://` Neon gives you by default in its dashboard
# — see the setup guide, step 4.
engine = create_async_engine(settings.database_url, echo=False)

AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False)


async def get_db():
    """FastAPI dependency — yields one session per request, closed automatically after."""
    async with AsyncSessionLocal() as session:
        yield session
