"""
Loads initial runtime configuration from app/db/seed_data.json.

    python -m app.db.seed

Idempotent and non-destructive: it only INSERTS rows that are missing and never
overwrites a value an admin has changed. The default currency is only assigned
if none exists yet. Edit seed_data.json to change what a fresh database gets.
"""
import asyncio
import json
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert

from app.core.setting_registry import get_def
from app.db.base import AsyncSessionLocal
from app.models.config import AppSetting, Currency

SEED_PATH = Path(__file__).with_name("seed_data.json")


async def seed(session_factory=AsyncSessionLocal, path: Path = SEED_PATH) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    added = {"settings": 0, "currencies": 0}

    async with session_factory() as db:
        for key, value in data["settings"].items():
            value = get_def(key).validate(value)  # unknown key / bad value -> error
            res = await db.execute(
                pg_insert(AppSetting)
                .values(key=key, value=value, updated_by="seed")
                .on_conflict_do_nothing(index_elements=["key"])
            )
            added["settings"] += res.rowcount or 0

        has_default = (
            await db.execute(select(Currency.code).where(Currency.is_default))
        ).first() is not None

        for c in data["currencies"]:
            make_default = bool(c["is_default"]) and not has_default
            res = await db.execute(
                pg_insert(Currency)
                .values(
                    code=c["code"].upper(),
                    name=c["name"],
                    minor_unit=c["minor_unit"],
                    is_active=c["is_active"],
                    is_default=make_default,
                )
                .on_conflict_do_nothing(index_elements=["code"])
            )
            if res.rowcount:
                added["currencies"] += 1
                has_default = has_default or make_default

        await db.commit()
    return added


if __name__ == "__main__":
    print("Seeded:", asyncio.run(seed()))
