"""
Registry of runtime-tunable settings that live in the `app_settings` table.

This file declares WHICH keys exist and what a valid value looks like (type,
bounds, allowed choices). It deliberately contains NO values: the values come
from the database, seeded from app/db/seed_data.json and editable afterwards
through the admin API. Stdlib only, so it can be imported anywhere.
"""
from dataclasses import dataclass
from typing import Any


class SettingValidationError(ValueError):
    pass


@dataclass(frozen=True)
class SettingDef:
    key: str
    kind: str  # "int" | "bool" | "str" | "choice"
    description: str
    minimum: int | None = None
    choices: tuple[str, ...] = ()
    prefixes: tuple[str, ...] = ()  # for "str": value must start with one of these

    def validate(self, value: Any) -> Any:
        k = self.key
        if self.kind == "int":
            # bool is a subclass of int in Python; reject it explicitly.
            if isinstance(value, bool) or not isinstance(value, int):
                raise SettingValidationError(f"{k} must be an integer")
            if self.minimum is not None and value < self.minimum:
                raise SettingValidationError(f"{k} must be >= {self.minimum}")
            return value
        if self.kind == "bool":
            if not isinstance(value, bool):
                raise SettingValidationError(f"{k} must be true or false")
            return value
        if self.kind == "choice":
            if value not in self.choices:
                raise SettingValidationError(f"{k} must be one of: {', '.join(self.choices)}")
            return value
        if self.kind == "str":
            if not isinstance(value, str) or not value.strip():
                raise SettingValidationError(f"{k} must be a non-empty string")
            value = value.strip()
            if self.prefixes and not value.startswith(self.prefixes):
                raise SettingValidationError(
                    f"{k} must start with one of: {', '.join(self.prefixes)}"
                )
            return value
        raise SettingValidationError(f"{k}: unknown setting kind '{self.kind}'")


_DEFS = (
    SettingDef(
        "live.idle_timeout_seconds",
        "int",
        "How long a LIVE event may stay idle before it is considered ended (B8).",
        minimum=1,
    ),
    SettingDef(
        "mux.reconnect_window_seconds",
        "int",
        "Mux reconnect window applied to NEWLY created streams (B6).",
        minimum=1,
    ),
    SettingDef(
        "mux.reduced_latency",
        "bool",
        "Use Mux reduced-latency mode on NEWLY created streams (B5).",
    ),
    SettingDef(
        "mux.playback_policy",
        "choice",
        "Playback policy applied to NEWLY created streams and their assets.",
        choices=("public", "signed"),
    ),
    SettingDef(
        "mux.rtmp_ingest_url",
        "str",
        "RTMP(S) ingest URL given to artists.",
        prefixes=("rtmp://", "rtmps://"),
    ),
    SettingDef(
        "mux.webhook_tolerance_seconds",
        "int",
        "Reject Mux webhooks whose timestamp is older than this (replay protection).",
        minimum=1,
    ),
)

REGISTRY: dict[str, SettingDef] = {d.key: d for d in _DEFS}


def get_def(key: str) -> SettingDef:
    try:
        return REGISTRY[key]
    except KeyError:
        raise SettingValidationError(f"Unknown setting '{key}'") from None
