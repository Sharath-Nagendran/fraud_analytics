from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", protected_namespaces=())

    database_url: str
    environment: str
    settings_cache_ttl_seconds: int
    payment_stub_mode: bool = True

    video_provider: str = "mock"
    video_development_mode: bool = True
    session_registry_mode: str = "memory"

    mux_stub_mode: bool = True  # legacy compatibility only
    mux_token_id: str = ""
    mux_token_secret: str = ""
    mux_webhook_secret: str = ""
    mux_signing_key_id: str = ""
    mux_signing_private_key: str = ""
    mux_ingest_url: str = "rtmps://global-live.mux.com:443/app"

    fastpix_token_id: str = "c43991bf-ed13-4410-820c-6ca7c5db3828"
    fastpix_secret_key: str = "0a19a2db-b771-4b96-8d51-e96ae95c10c3s"
    fastpix_api_base_url: str = "https://api.fastpix.com/v1"
    fastpix_ingest_url: str = "rtmps://live.fastpix.com:443/live"
    fastpix_playback_base_url: str = "https://stream.fastpix.com"
    fastpix_ca_bundle: str = ""
    fastpix_webhook_secret: str = ""
    selfhosted_rtmp_ingest_url: str = ("rtmp://localhost:1935")
    selfhosted_hls_base_url: str = ("http://localhost:8888")
    selfhosted_playback_api_base_url: str = ("http://localhost:9996")
    selfhosted_api_base_url: str = ("http://localhost:9997")
    selfhosted_playback_api_base_url: str = ("http://localhost:9996")
    webhook_reconciliation_seconds: int = 30
    replay_work_root: str = ("replay-work")
    replay_download_timeout_seconds: float = (600.0)

    playback_token_ttl_seconds: int = 300
    playback_token_refresh_seconds: int = 120
    playback_session_ttl_seconds: int = 180
    max_concurrent_playback_sessions: int = 2
    preissue_window_seconds: int = 900

    video_reconciliation_enabled: bool = True
    video_reconciliation_interval_seconds: int = 30
    video_idle_grace_seconds: int = 90

    redis_url: str = ""

    drm_enabled: bool = False
    drm_provider: str = "mock"
    drm_configuration_id: str = ""
    playback_restriction_id: str = ""
    widevine_license_url: str = ""
    fairplay_license_url: str = ""
    playready_license_url: str = ""
    drm_signing_secret: str = ""
    admin_user_ids: str = ""

    storage_provider: str = "local"
    storage_local_root: str = ("static/media")
    storage_public_base_url: str = ("http://localhost:8000/media")
    storage_presigned_urls: bool = False
    storage_url_expiry_seconds: int = 300
    storage_s3_bucket: str = ""
    storage_s3_region: str = "us-east-1"
    storage_s3_endpoint_url: str = ""
    storage_s3_access_key: str = ""
    storage_s3_secret_key: str = ""
    storage_s3_addressing_style: str = ("path")

    ffmpeg_path: str = "ffmpeg"
    replay_assembly_timeout_seconds: float = (900.0)
    replay_default_visibility: str = ("PPV")
    replay_auto_publish: bool = True

    replay_job_initial_delay_seconds: int = 15
    replay_job_max_attempts: int = 5
    replay_job_stale_after_seconds: int = 1800
    replay_worker_poll_seconds: float = 5.0

    video_upload_temp_root: str = "upload-work"
    video_upload_max_bytes: int = (5 * 1024 * 1024 * 1024)
    video_upload_chunk_bytes: int = (1024 * 1024)

    chat_moderation_provider: str = ("allow_all")
    chat_message_max_characters: int = (2000)
    chat_warning_threshold: int = 3

    chat_mute_minutes: int = 10
    chat_blocked_terms: str = ("idiot,stupid,abuseword1,abuseword2")

    @property
    def admin_user_id_list(self) -> list[str]:
        return [u.strip() for u in self.admin_user_ids.split(",") if u.strip()]

    @property
    def blocked_terms(self) -> set[str]:
        return {
            value.strip().lower()
            for value in self.chat_blocked_terms.split(",")
            if value.strip()
        }

    @model_validator(mode="after")
    def _validate(self):
        provider = self.video_provider.lower()
        if provider not in {"mock", "mux", "fastpix", "selfhosted"}:
            raise ValueError("VIDEO_PROVIDER must be mock, mux, fastpix or selfhosted")
        if provider == "fastpix" and (not self.fastpix_token_id or not self.fastpix_secret_key):
            raise ValueError("FASTPIX_TOKEN_ID and FASTPIX_SECRET_KEY are required for VIDEO_PROVIDER=fastpix")
        if provider == "mux" and (not self.mux_token_id or not self.mux_token_secret):
            raise ValueError("MUX_TOKEN_ID and MUX_TOKEN_SECRET are required for VIDEO_PROVIDER=mux")
        if self.session_registry_mode not in {"memory", "redis"}:
            raise ValueError("SESSION_REGISTRY_MODE must be memory or redis")
        if self.session_registry_mode == "redis" and not self.redis_url:
            raise ValueError("REDIS_URL is required for SESSION_REGISTRY_MODE=redis")
        if self.environment.lower() == "production" and provider == "mock":
            raise ValueError("VIDEO_PROVIDER=mock is not allowed in production")
        if self.max_concurrent_playback_sessions < 1:
            raise ValueError("MAX_CONCURRENT_PLAYBACK_SESSIONS must be >= 1")
        if self.playback_session_ttl_seconds < 30:
            raise ValueError("PLAYBACK_SESSION_TTL_SECONDS must be >= 30")
        if self.playback_token_ttl_seconds < 30:
            raise ValueError("PLAYBACK_TOKEN_TTL_SECONDS must be >= 30")
        if self.settings_cache_ttl_seconds < 0:
            raise ValueError("SETTINGS_CACHE_TTL_SECONDS must be >= 0")
        if self.video_reconciliation_interval_seconds < 5:
            raise ValueError("VIDEO_RECONCILIATION_INTERVAL_SECONDS must be >= 5")
        if self.video_idle_grace_seconds < 30:
            raise ValueError("VIDEO_IDLE_GRACE_SECONDS must be >= 30")
        storage_provider = (self.storage_provider.strip().lower())

        if storage_provider not in {"local", "s3", "seaweedfs", "s3_compatible",}:
            raise ValueError("STORAGE_PROVIDER must be local, s3, seaweedfs or s3_compatible")
        if (storage_provider == "local" and not self.storage_local_root):
            raise ValueError("STORAGE_LOCAL_ROOT is required for local storage")
        if (storage_provider in {"s3","seaweedfs","s3_compatible",} and not self.storage_s3_bucket):
            raise ValueError("STORAGE_S3_BUCKET is required for S3-compatible storage")
        if (self.storage_s3_addressing_style not in {"auto","path","virtual",}):
            raise ValueError("STORAGE_S3_ADDRESSING_STYLE must be auto, path or virtual")
        if self.storage_url_expiry_seconds < 30:
            raise ValueError("STORAGE_URL_EXPIRY_SECONDS must be at least 30")
        return self


settings = Settings()
