import asyncio
import mimetypes

from pathlib import Path

from botocore.exceptions import (
    ClientError,
)

from app.storage.base import (
    StorageProvider,
    StoredObject,
)


class S3StorageProvider(StorageProvider):

    def __init__(
        self,
        client,
        bucket: str,
        public_base_url: str | None,
        presigned_urls: bool,
        default_url_expiry_seconds: int,
        provider_name: str,
    ):
        self.client = client
        self.bucket = bucket

        self.public_base_url = (
            public_base_url.rstrip("/")
            if public_base_url
            else None
        )

        self.presigned_urls = presigned_urls

        self.default_url_expiry_seconds = (
            default_url_expiry_seconds
        )

        self.provider_name = provider_name

    async def put_file(
        self,
        source_path: Path,
        object_key: str,
        content_type: str | None = None,
    ) -> StoredObject:

        source = source_path.resolve()

        if not source.exists():
            raise FileNotFoundError(
                f"Source file not found: {source}"
            )

        if not source.is_file():
            raise ValueError(
                f"Source path is not a file: "
                f"{source}"
            )

        key = self._normalize_key(
            object_key
        )

        resolved_content_type = (
            content_type
            or mimetypes.guess_type(
                source.name
            )[0]
            or "application/octet-stream"
        )

        extra_args = {
            "ContentType": resolved_content_type,
        }

        await asyncio.to_thread(
            self.client.upload_file,
            str(source),
            self.bucket,
            key,
            ExtraArgs=extra_args,
        )

        head = await asyncio.to_thread(
            self.client.head_object,
            Bucket=self.bucket,
            Key=key,
        )

        return StoredObject(
            provider=self.provider_name,
            object_key=key,
            storage_url=await self.get_playback_url(
                key
            ),
            content_type=resolved_content_type,
            size_bytes=head.get(
                "ContentLength"
            ),
            etag=(
                head.get("ETag", "")
                .strip('"')
                or None
            ),
        )

    async def delete(
        self,
        object_key: str,
    ) -> None:

        key = self._normalize_key(
            object_key
        )

        await asyncio.to_thread(
            self.client.delete_object,
            Bucket=self.bucket,
            Key=key,
        )

    async def exists(
        self,
        object_key: str,
    ) -> bool:

        key = self._normalize_key(
            object_key
        )

        try:
            await asyncio.to_thread(
                self.client.head_object,
                Bucket=self.bucket,
                Key=key,
            )

            return True

        except ClientError as exc:
            response = exc.response or {}

            status = (
                response
                .get("ResponseMetadata", {})
                .get("HTTPStatusCode")
            )

            if status == 404:
                return False

            raise

    async def get_playback_url(
        self,
        object_key: str,
        expires_seconds: int | None = None,
    ) -> str:

        key = self._normalize_key(
            object_key
        )

        if self.presigned_urls:
            expiry = (
                expires_seconds
                or self.default_url_expiry_seconds
            )

            return await asyncio.to_thread(
                self.client.generate_presigned_url,
                "get_object",
                Params={
                    "Bucket": self.bucket,
                    "Key": key,
                },
                ExpiresIn=expiry,
            )

        if not self.public_base_url:
            raise RuntimeError(
                "STORAGE_PUBLIC_BASE_URL is "
                "required when presigned URLs "
                "are disabled"
            )

        return (
            f"{self.public_base_url}/"
            f"{key}"
        )

    @staticmethod
    def _normalize_key(
        object_key: str,
    ) -> str:

        normalized = (
            object_key
            .replace("\\", "/")
            .strip("/")
        )

        if not normalized:
            raise ValueError(
                "object_key is required"
            )

        if ".." in Path(normalized).parts:
            raise ValueError(
                "object_key cannot contain '..'"
            )

        return normalized