from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class StoredObject:
    provider: str
    object_key: str
    storage_url: str

    content_type: str | None = None
    size_bytes: int | None = None
    etag: str | None = None


class StorageProvider(ABC):

    @abstractmethod
    async def put_file(
        self,
        source_path: Path,
        object_key: str,
        content_type: str | None = None,
    ) -> StoredObject:
        raise NotImplementedError

    @abstractmethod
    async def delete(
        self,
        object_key: str,
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    async def exists(
        self,
        object_key: str,
    ) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def get_playback_url(
        self,
        object_key: str,
        expires_seconds: int | None = None,
    ) -> str:
        raise NotImplementedError