from functools import lru_cache
from pathlib import Path

import boto3

from botocore.config import Config

from app.core.config import settings

from app.storage.base import (
    StorageProvider,
)

from app.storage.local import (
    LocalStorageProvider,
)

from app.storage.s3 import (
    S3StorageProvider,
)


@lru_cache(maxsize=1)
def get_storage_provider() -> StorageProvider:

    provider = (
        settings.storage_provider
        .strip()
        .lower()
    )

    if provider == "local":
        return LocalStorageProvider(
            root_directory=Path(
                settings.storage_local_root
            ),
            public_base_url=(
                settings.storage_public_base_url
            ),
        )

    if provider in {
        "s3",
        "seaweedfs",
        "s3_compatible",
    }:
        client = boto3.client(
            "s3",
            endpoint_url=(
                settings.storage_s3_endpoint_url
                or None
            ),
            region_name=(
                settings.storage_s3_region
            ),
            aws_access_key_id=(
                settings.storage_s3_access_key
                or None
            ),
            aws_secret_access_key=(
                settings.storage_s3_secret_key
                or None
            ),
            config=Config(
                signature_version="s3v4",
                s3={
                    "addressing_style": (
                        settings
                        .storage_s3_addressing_style
                    ),
                },
            ),
        )

        return S3StorageProvider(
            client=client,
            bucket=settings.storage_s3_bucket,
            public_base_url=(
                settings.storage_public_base_url
                or None
            ),
            presigned_urls=(
                settings
                .storage_presigned_urls
            ),
            default_url_expiry_seconds=(
                settings
                .storage_url_expiry_seconds
            ),
            provider_name=provider,
        )

    raise RuntimeError(
        "Unsupported STORAGE_PROVIDER: "
        f"{settings.storage_provider}"
    )