import asyncio
import mimetypes
import shutil

from pathlib import Path

from app.storage.base import (
    StorageProvider,
    StoredObject,
)


class LocalStorageProvider(StorageProvider):

    def __init__(
        self,
        root_directory: Path,
        public_base_url: str,
    ):
        self.root_directory = (
            root_directory.resolve()
        )

        self.public_base_url = (
            public_base_url.rstrip("/")
        )

        self.root_directory.mkdir(
            parents=True,
            exist_ok=True,
        )

    async def put_file(
        self,
        source_path: Path,
        object_key: str,
        content_type: str | None = None,
    ) -> StoredObject:

        source = source_path.resolve()

        if not source.exists():
            raise FileNotFoundError(
                f"Source file not found: {source}"
            )

        if not source.is_file():
            raise ValueError(
                f"Source path is not a file: {source}"
            )

        safe_key = self._normalize_key(
            object_key
        )

        destination = (
            self.root_directory
            / Path(safe_key)
        ).resolve()

        self._ensure_inside_root(
            destination
        )

        destination.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        if source != destination:
            await asyncio.to_thread(
                shutil.copy2,
                source,
                destination,
            )

        resolved_content_type = (
            content_type
            or mimetypes.guess_type(
                destination.name
            )[0]
        )

        size_bytes = destination.stat().st_size

        return StoredObject(
            provider="local",
            object_key=safe_key,
            storage_url=(
                f"{self.public_base_url}/"
                f"{safe_key}"
            ),
            content_type=resolved_content_type,
            size_bytes=size_bytes,
        )

    async def delete(
        self,
        object_key: str,
    ) -> None:

        target = self._resolve_object_path(
            object_key
        )

        if target.exists():
            await asyncio.to_thread(
                target.unlink
            )

    async def exists(
        self,
        object_key: str,
    ) -> bool:

        target = self._resolve_object_path(
            object_key
        )

        return target.is_file()

    async def get_playback_url(
        self,
        object_key: str,
        expires_seconds: int | None = None,
    ) -> str:

        del expires_seconds

        target = self._resolve_object_path(
            object_key
        )

        if not target.is_file():
            raise FileNotFoundError(
                f"Stored object not found: "
                f"{object_key}"
            )

        safe_key = self._normalize_key(
            object_key
        )

        return (
            f"{self.public_base_url}/"
            f"{safe_key}"
        )

    def _resolve_object_path(
        self,
        object_key: str,
    ) -> Path:

        safe_key = self._normalize_key(
            object_key
        )

        target = (
            self.root_directory
            / Path(safe_key)
        ).resolve()

        self._ensure_inside_root(
            target
        )

        return target

    def _ensure_inside_root(
        self,
        path: Path,
    ) -> None:

        try:
            path.relative_to(
                self.root_directory
            )

        except ValueError as exc:
            raise ValueError(
                "Object key resolves outside "
                "the storage root"
            ) from exc

    @staticmethod
    def _normalize_key(
        object_key: str,
    ) -> str:

        normalized = (
            object_key
            .replace("\\", "/")
            .strip("/")
        )

        if not normalized:
            raise ValueError(
                "object_key is required"
            )

        parts = Path(normalized).parts

        if ".." in parts:
            raise ValueError(
                "object_key cannot contain '..'"
            )

        return normalized