import uuid

from datetime import (
    datetime,
    timezone
)

from sqlalchemy import (
    Boolean,
    DateTime,
    String
)

from sqlalchemy.dialects.postgresql import UUID

from sqlalchemy.orm import (
    Mapped,
    mapped_column
)

from app.db.base import Base


class DrmConfig(Base):
    __tablename__ = "drm_config"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4
    )

    enabled: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False
    )

    provider: Mapped[str] = mapped_column(
        String,
        nullable=False,
        default="mock"
    )

    watermark_enabled: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True
    )

    widevine_url: Mapped[str | None] = mapped_column(
        String,
        nullable=True
    )

    fairplay_url: Mapped[str | None] = mapped_column(
        String,
        nullable=True
    )

    playready_url: Mapped[str | None] = mapped_column(
        String,
        nullable=True
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda:
            datetime.now(timezone.utc)
    )
