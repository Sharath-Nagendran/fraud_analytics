import enum
import uuid

from datetime import datetime, timezone

from sqlalchemy import (
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Integer,
    String,
    Text,
)

from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class VideoAssetType(str, enum.Enum):
    UPLOAD = "UPLOAD"
    LIVE_RECORDING = "LIVE_RECORDING"


class VideoAssetVisibility(str, enum.Enum):
    PRIVATE = "PRIVATE"
    PPV = "PPV"
    SUBSCRIPTION = "SUBSCRIPTION"
    PUBLIC = "PUBLIC"


class VideoAssetStatus(str, enum.Enum):
    PROCESSING = "PROCESSING"
    READY = "READY"
    FAILED = "FAILED"
    ARCHIVED = "ARCHIVED"


class VideoAsset(Base):
    __tablename__ = "video_assets"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )

    artist_id: Mapped[str] = mapped_column(
        String,
        nullable=False,
        index=True,
    )

    source_live_event_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("live_events.id"),
        nullable=True,
        index=True,
    )

    title: Mapped[str] = mapped_column(
        String(300),
        nullable=False,
    )

    description: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    asset_type: Mapped[VideoAssetType] = mapped_column(
        SAEnum(VideoAssetType),
        nullable=False,
    )

    video_provider: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
    )

    video_asset_provider_id: Mapped[str | None] = mapped_column(
        String,
        nullable=True,
    )

    storage_url: Mapped[str | None] = mapped_column(
        String,
        nullable=True,
    )

    storage_provider: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True,
    )

    storage_object_key: Mapped[str | None] = mapped_column(
        String(1000),
        nullable=True,
    )

    thumbnail_url: Mapped[str | None] = mapped_column(
        String,
        nullable=True,
    )

    duration_seconds: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
    )

    visibility: Mapped[VideoAssetVisibility] = mapped_column(
        SAEnum(VideoAssetVisibility),
        nullable=False,
        default=VideoAssetVisibility.PRIVATE,
    )

    price_cents: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
    )

    currency: Mapped[str] = mapped_column(
        String(3),
        nullable=False,
        default="GBP",
    )

    status: Mapped[VideoAssetStatus] = mapped_column(
        SAEnum(VideoAssetStatus),
        nullable=False,
        default=VideoAssetStatus.PROCESSING,
    )

    published_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )