import enum
import uuid
from datetime import datetime, timezone
from sqlalchemy import String, Integer, DateTime, Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base


class LiveEventStatus(str, enum.Enum):
    DRAFT = "DRAFT"
    SCHEDULED = "SCHEDULED"
    LIVE = "LIVE"
    ENDED = "ENDED"
    ARCHIVED = "ARCHIVED"
    CANCELLED = "CANCELLED"


class LiveEvent(Base):
    __tablename__ = "live_events"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    artist_id: Mapped[str] = mapped_column(String, index=True)
    title: Mapped[str] = mapped_column(String)
    description: Mapped[str | None] = mapped_column(String, nullable=True)
    cover_image_url: Mapped[str | None] = mapped_column(String, nullable=True)
    scheduled_start: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    ticket_price_cents: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String, default="GBP")
    capacity: Mapped[int | None] = mapped_column(Integer, nullable=True)
    status: Mapped[LiveEventStatus] = mapped_column(SAEnum(LiveEventStatus), default=LiveEventStatus.DRAFT, index=True)

    video_provider: Mapped[str | None] = mapped_column(String(30), nullable=True, index=True)
    video_stream_id: Mapped[str | None] = mapped_column(String, unique=True, nullable=True)
    video_stream_key: Mapped[str | None] = mapped_column(String, nullable=True)
    video_playback_id: Mapped[str | None] = mapped_column(String, nullable=True)
    video_ingest_url: Mapped[str | None] = mapped_column(String, nullable=True)
    video_playback_url: Mapped[str | None] = mapped_column(String, nullable=True)
    video_asset_id: Mapped[str | None] = mapped_column(String, nullable=True)
    video_vod_playback_id: Mapped[str | None] = mapped_column(String, nullable=True, unique=True)

    # Legacy columns retained for one compatibility sprint. Do not write new data here.
    mux_live_stream_id: Mapped[str | None] = mapped_column(String, unique=True, nullable=True)
    mux_stream_key: Mapped[str | None] = mapped_column(String, nullable=True)
    mux_playback_id: Mapped[str | None] = mapped_column(String, nullable=True)
    mux_asset_id: Mapped[str | None] = mapped_column(String, nullable=True)
    mux_vod_playback_id: Mapped[str | None] = mapped_column(String, nullable=True, unique=True)

    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finalized_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True),nullable=True,)
    provider_idle_since: Mapped[datetime | None] = mapped_column(DateTime(timezone=True),nullable=True,index=True,)
