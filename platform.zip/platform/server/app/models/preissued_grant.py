import enum, uuid
from datetime import datetime, timezone
from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Index, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base

class PreissuedGrantStatus(str, enum.Enum):
    READY = "READY"
    CONSUMED = "CONSUMED"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"

class PreissuedPlaybackGrant(Base):
    __tablename__ = "preissued_playback_grants"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("live_events.id"), nullable=False)
    entitlement_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("entitlements.id"), nullable=False)
    fan_id: Mapped[str] = mapped_column(String, nullable=False)
    session_id: Mapped[str] = mapped_column(String, nullable=False)
    playback_id: Mapped[str] = mapped_column(String, nullable=False)
    token: Mapped[str] = mapped_column(String, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    status: Mapped[PreissuedGrantStatus] = mapped_column(SAEnum(PreissuedGrantStatus), nullable=False, default=PreissuedGrantStatus.READY)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    __table_args__ = (
        UniqueConstraint("event_id", "entitlement_id", name="uq_preissued_event_entitlement"),
        Index("ix_preissued_event_fan_status", "event_id", "fan_id", "status"),
        Index("ix_preissued_expires_at", "expires_at"),
    )
