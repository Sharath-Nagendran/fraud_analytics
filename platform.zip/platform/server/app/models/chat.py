import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class ChatRoomType(str, enum.Enum):
    LIVE_EVENT = "LIVE_EVENT"
    VIDEO_ASSET = "VIDEO_ASSET"
    DIRECT = "DIRECT"


class ChatRoomStatus(str, enum.Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"
    ARCHIVED = "ARCHIVED"


class ChatParticipantType(str, enum.Enum):
    ARTIST = "ARTIST"
    FAN = "FAN"
    MODERATOR = "MODERATOR"
    SYSTEM = "SYSTEM"


class ChatParticipantStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"
    MUTED = "MUTED"
    SUSPENDED = "SUSPENDED"
    REMOVED = "REMOVED"


class ChatMessageType(str, enum.Enum):
    TEXT = "TEXT"
    SYSTEM = "SYSTEM"
    MODERATION_NOTICE = "MODERATION_NOTICE"


class ChatMessageStatus(str, enum.Enum):
    PENDING = "PENDING"
    VISIBLE = "VISIBLE"
    BLOCKED = "BLOCKED"
    DELETED = "DELETED"


class ModerationDecisionType(str, enum.Enum):
    ALLOW = "ALLOW"
    WARN = "WARN"
    BLOCK = "BLOCK"
    ESCALATE = "ESCALATE"


class ModerationIncidentType(str, enum.Enum):
    ABUSE = "ABUSE"
    HARASSMENT = "HARASSMENT"
    THREAT = "THREAT"
    SPAM = "SPAM"
    OTHER = "OTHER"


class ModerationAction(str, enum.Enum):
    NONE = "NONE"
    WARNING = "WARNING"
    MESSAGE_BLOCKED = "MESSAGE_BLOCKED"
    TEMPORARY_MUTE = "TEMPORARY_MUTE"
    CHAT_REMOVAL = "CHAT_REMOVAL"
    HUMAN_REVIEW = "HUMAN_REVIEW"


class ModerationIncidentStatus(str, enum.Enum):
    OPEN = "OPEN"
    RESOLVED = "RESOLVED"
    APPEALED = "APPEALED"


class ChatRoom(Base):
    __tablename__ = "chat_rooms"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    room_type: Mapped[ChatRoomType] = mapped_column(
        SAEnum(ChatRoomType, name="chatroomtype"), nullable=False
    )
    live_event_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("live_events.id"), nullable=True
    )
    video_asset_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("video_assets.id"), nullable=True
    )
    artist_id: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[ChatRoomStatus] = mapped_column(
        SAEnum(ChatRoomStatus, name="chatroomstatus"),
        nullable=False,
        default=ChatRoomStatus.OPEN,
    )
    moderation_enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True
    )
    moderation_policy_version: Mapped[str] = mapped_column(
        String(100), nullable=False, default="chat-policy-v1"
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    closed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    __table_args__ = (
        UniqueConstraint("live_event_id", name="uq_chat_rooms_live_event"),
        UniqueConstraint("video_asset_id", name="uq_chat_rooms_video_asset"),
        Index("ix_chat_rooms_artist_status", "artist_id", "status"),
    )


class ChatParticipant(Base):
    __tablename__ = "chat_participants"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    chat_room_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("chat_rooms.id"), nullable=False
    )
    participant_type: Mapped[ChatParticipantType] = mapped_column(
        SAEnum(ChatParticipantType, name="chatparticipanttype"), nullable=False
    )
    participant_id: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[ChatParticipantStatus] = mapped_column(
        SAEnum(ChatParticipantStatus, name="chatparticipantstatus"),
        nullable=False,
        default=ChatParticipantStatus.ACTIVE,
    )
    warning_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    muted_until: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    joined_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    last_seen_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    removed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    removal_reason: Mapped[str | None] = mapped_column(Text, nullable=True)

    __table_args__ = (
        UniqueConstraint(
            "chat_room_id",
            "participant_type",
            "participant_id",
            name="uq_chat_participants_room_identity",
        ),
        Index("ix_chat_participants_room_status", "chat_room_id", "status"),
        Index("ix_chat_participants_identity", "participant_type", "participant_id"),
    )


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    chat_room_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("chat_rooms.id"), nullable=False
    )
    sender_participant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("chat_participants.id"), nullable=False
    )
    sequence_number: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    message_type: Mapped[ChatMessageType] = mapped_column(
        SAEnum(ChatMessageType, name="chatmessagetype"),
        nullable=False,
        default=ChatMessageType.TEXT,
    )
    body: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[ChatMessageStatus] = mapped_column(
        SAEnum(ChatMessageStatus, name="chatmessagestatus"),
        nullable=False,
        default=ChatMessageStatus.PENDING,
    )
    client_message_id: Mapped[str] = mapped_column(String(255), nullable=False)
    moderation_required: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    edited_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    deleted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    __table_args__ = (
        UniqueConstraint(
            "chat_room_id", "client_message_id", name="uq_chat_messages_room_client_id"
        ),
        UniqueConstraint(
            "chat_room_id", "sequence_number", name="uq_chat_messages_room_sequence"
        ),
        Index("ix_chat_messages_room_created", "chat_room_id", "created_at"),
        Index("ix_chat_messages_sender_created", "sender_participant_id", "created_at"),
        Index("ix_chat_messages_room_status", "chat_room_id", "status"),
    )


class ModerationDecision(Base):
    __tablename__ = "moderation_decisions"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    chat_message_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("chat_messages.id"), nullable=False, unique=True
    )
    moderation_provider: Mapped[str] = mapped_column(String(100), nullable=False)
    moderation_model_version: Mapped[str | None] = mapped_column(
        String(200), nullable=True
    )
    policy_version: Mapped[str] = mapped_column(String(100), nullable=False)
    decision: Mapped[ModerationDecisionType] = mapped_column(
        SAEnum(ModerationDecisionType, name="moderationdecisiontype"), nullable=False
    )
    categories: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    severity: Mapped[int | None] = mapped_column(Integer, nullable=True)
    confidence: Mapped[float | None] = mapped_column(nullable=True)
    reason_code: Mapped[str | None] = mapped_column(String(100), nullable=True)
    policy_rule: Mapped[str | None] = mapped_column(String(200), nullable=True)
    provider_request_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    provider_payload: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    processing_milliseconds: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )

    __table_args__ = (
        Index("ix_moderation_decisions_decision_created", "decision", "created_at"),
    )


class ModerationIncident(Base):
    __tablename__ = "moderation_incidents"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    chat_room_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("chat_rooms.id"), nullable=False
    )
    participant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("chat_participants.id"), nullable=False
    )
    chat_message_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("chat_messages.id"), nullable=True
    )
    moderation_decision_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("moderation_decisions.id"), nullable=True
    )
    incident_type: Mapped[ModerationIncidentType] = mapped_column(
        SAEnum(ModerationIncidentType, name="moderationincidenttype"), nullable=False
    )
    action: Mapped[ModerationAction] = mapped_column(
        SAEnum(ModerationAction, name="moderationaction"), nullable=False
    )
    warning_number: Mapped[int | None] = mapped_column(Integer, nullable=True)
    action_expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    status: Mapped[ModerationIncidentStatus] = mapped_column(
        SAEnum(ModerationIncidentStatus, name="moderationincidentstatus"),
        nullable=False,
        default=ModerationIncidentStatus.OPEN,
    )
    evidence_snapshot: Mapped[str | None] = mapped_column(Text, nullable=True)
    reason_code: Mapped[str | None] = mapped_column(String(100), nullable=True)
    requested_by_type: Mapped[ChatParticipantType | None] = mapped_column(
        SAEnum(ChatParticipantType, name="chatparticipanttype", create_type=False),
        nullable=True,
    )
    requested_by_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    resolved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    resolved_by: Mapped[str | None] = mapped_column(String(255), nullable=True)
    resolution_notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    __table_args__ = (
        Index("ix_moderation_incidents_room_created", "chat_room_id", "created_at"),
        Index("ix_moderation_incidents_participant_status", "participant_id", "status"),
        Index("ix_moderation_incidents_status_created", "status", "created_at"),
    )
