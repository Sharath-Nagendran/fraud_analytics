import enum
import uuid

from datetime import datetime, timezone

from sqlalchemy import (
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Index,
    Integer,
    String,
    UniqueConstraint,
)

from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class VideoAssetEntitlementStatus(
    str,
    enum.Enum,
):
    ACTIVE = "ACTIVE"
    REVOKED = "REVOKED"
    EXPIRED = "EXPIRED"


class VideoAssetPurchaseStatus(
    str,
    enum.Enum,
):
    PAID = "PAID"
    REFUNDED = "REFUNDED"
    FAILED = "FAILED"


class VideoAssetEntitlement(Base):
    __tablename__ = "video_asset_entitlements"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )

    video_asset_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("video_assets.id"),
        nullable=False,
        index=True,
    )

    fan_id: Mapped[str] = mapped_column(
        String,
        nullable=False,
        index=True,
    )

    source: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
    )

    status: Mapped[VideoAssetEntitlementStatus] = mapped_column(
        SAEnum(
            VideoAssetEntitlementStatus,
            name="videoassetentitlementstatus",
        ),
        nullable=False,
        default=VideoAssetEntitlementStatus.ACTIVE,
    )

    valid_from: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    valid_until: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    __table_args__ = (
        UniqueConstraint(
            "video_asset_id",
            "fan_id",
            name="uq_video_asset_entitlement_asset_fan",
        ),
        Index(
            "ix_video_asset_entitlements_fan_status",
            "fan_id",
            "status",
        ),
        Index(
            "ix_video_asset_entitlements_asset_status",
            "video_asset_id",
            "status",
        ),
    )


class VideoAssetPurchase(Base):
    __tablename__ = "video_asset_purchases"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )

    video_asset_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("video_assets.id"),
        nullable=False,
        index=True,
    )

    fan_id: Mapped[str] = mapped_column(
        String,
        nullable=False,
        index=True,
    )

    entitlement_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("video_asset_entitlements.id"),
        nullable=False,
    )

    provider: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
    )

    provider_payment_id: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        unique=True,
    )

    idempotency_key: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        unique=True,
    )

    amount_cents: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )

    currency: Mapped[str] = mapped_column(
        String(3),
        nullable=False,
    )

    status: Mapped[VideoAssetPurchaseStatus] = mapped_column(
        SAEnum(
            VideoAssetPurchaseStatus,
            name="videoassetpurchasestatus",
        ),
        nullable=False,
        default=VideoAssetPurchaseStatus.PAID,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    refunded_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    __table_args__ = (
        UniqueConstraint(
            "video_asset_id",
            "fan_id",
            name="uq_video_asset_purchase_asset_fan",
        ),
        Index(
            "ix_video_asset_purchases_fan_created",
            "fan_id",
            "created_at",
        ),
    )