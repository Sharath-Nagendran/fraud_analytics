import enum
import uuid

from datetime import datetime, timezone

from sqlalchemy import (
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)

from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class LiveRecordingStatus(str, enum.Enum):
    COLLECTING = "COLLECTING"
    FINALIZING = "FINALIZING"
    READY = "READY"
    FAILED = "FAILED"


class LiveRecordingSpanStatus(str, enum.Enum):
    DISCOVERED = "DISCOVERED"
    DOWNLOADING = "DOWNLOADING"
    DOWNLOADED = "DOWNLOADED"
    MERGED = "MERGED"
    FAILED = "FAILED"


class LiveRecording(Base):
    __tablename__ = "live_recordings"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )

    live_event_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("live_events.id"),
        nullable=False,
        unique=True,
        index=True,
    )

    stream_path: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    status: Mapped[LiveRecordingStatus] = mapped_column(
        SAEnum(
            LiveRecordingStatus,
            name="liverecordingstatus",
        ),
        nullable=False,
        default=LiveRecordingStatus.COLLECTING,
    )

    video_asset_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("video_assets.id"),
        nullable=True,
        unique=True,
    )

    storage_provider: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True,
    )

    storage_object_key: Mapped[str | None] = mapped_column(
        String(1000),
        nullable=True,
    )

    failure_reason: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    finalized_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )


class LiveRecordingSpan(Base):
    __tablename__ = "live_recording_spans"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )

    live_recording_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("live_recordings.id"),
        nullable=False,
        index=True,
    )

    source_url: Mapped[str] = mapped_column(
        Text,
        nullable=False,
    )

    started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )

    duration_milliseconds: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )

    status: Mapped[LiveRecordingSpanStatus] = mapped_column(
        SAEnum(
            LiveRecordingSpanStatus,
            name="liverecordingspanstatus",
        ),
        nullable=False,
        default=LiveRecordingSpanStatus.DISCOVERED,
    )

    local_path: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    failure_reason: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )

    __table_args__ = (
        UniqueConstraint(
            "live_recording_id",
            "started_at",
            name="uq_live_recording_span_start",
        ),
        Index(
            "ix_live_recording_spans_recording_status",
            "live_recording_id",
            "status",
        ),
    )