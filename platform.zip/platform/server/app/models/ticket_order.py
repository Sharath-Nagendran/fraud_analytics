import enum
import uuid
from datetime import datetime, timezone
from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Index, Integer, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base


class TicketOrderStatus(str, enum.Enum):
    PAID = "PAID"
    PARTIALLY_REFUNDED = "PARTIALLY_REFUNDED"
    REFUNDED = "REFUNDED"


class TicketOrderType(str, enum.Enum):
    LIVE_EVENT = "LIVE_EVENT"
    REPLAY = "REPLAY"


class TicketOrder(Base):
    __tablename__ = "ticket_orders"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("live_events.id"), nullable=False, index=True)
    buyer_fan_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    unit_amount_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    total_amount_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    currency: Mapped[str] = mapped_column(String(3), nullable=False)
    provider: Mapped[str] = mapped_column(String, nullable=False)
    provider_payment_id: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    idempotency_key: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    status: Mapped[TicketOrderStatus] = mapped_column(SAEnum(TicketOrderStatus), nullable=False, default=TicketOrderStatus.PAID)
    purchase_type: Mapped[TicketOrderType] = mapped_column(SAEnum(TicketOrderType), nullable=False, default=TicketOrderType.LIVE_EVENT)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    __table_args__ = (
        Index("ix_ticket_orders_buyer_created", "buyer_fan_id", "created_at"),
        Index("ix_ticket_orders_event_purchase_type", "event_id", "purchase_type"),
    )


class TicketOrderItem(Base):
    __tablename__ = "ticket_order_items"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    order_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("ticket_orders.id"), nullable=False, index=True)
    ticket_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("ticket_purchases.id"), nullable=False, unique=True)
    line_number: Mapped[int] = mapped_column(Integer, nullable=False)
    __table_args__ = (UniqueConstraint("order_id", "line_number", name="uq_ticket_order_line"),)
