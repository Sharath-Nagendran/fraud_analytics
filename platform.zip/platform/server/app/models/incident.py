import enum, uuid
from datetime import datetime, timezone
from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base

class IncidentStatus(str, enum.Enum):
    OPEN="OPEN"; RECOVERED="RECOVERED"; REVIEW_REQUIRED="REVIEW_REQUIRED"; CLOSED="CLOSED"
class RefundCandidateStatus(str, enum.Enum):
    PENDING_REVIEW="PENDING_REVIEW"; APPROVED="APPROVED"; REJECTED="REJECTED"; REFUNDED="REFUNDED"
class StreamIncident(Base):
    __tablename__="stream_incidents"
    id:Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    event_id:Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),ForeignKey("live_events.id"),nullable=False,index=True)
    kind:Mapped[str]=mapped_column(String,nullable=False)
    status:Mapped[IncidentStatus]=mapped_column(SAEnum(IncidentStatus),nullable=False,default=IncidentStatus.OPEN)
    started_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False,default=lambda:datetime.now(timezone.utc))
    recovered_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    duration_seconds:Mapped[int|None]=mapped_column(Integer)
    details:Mapped[str|None]=mapped_column(Text)
class RefundCandidate(Base):
    __tablename__="refund_candidates"
    id:Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    incident_id:Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),ForeignKey("stream_incidents.id"),nullable=False,index=True)
    ticket_id:Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),ForeignKey("ticket_purchases.id"),nullable=False)
    status:Mapped[RefundCandidateStatus]=mapped_column(SAEnum(RefundCandidateStatus),nullable=False,default=RefundCandidateStatus.PENDING_REVIEW)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False,default=lambda:datetime.now(timezone.utc))
    __table_args__=(UniqueConstraint("incident_id","ticket_id",name="uq_refund_candidate_incident_ticket"),)
