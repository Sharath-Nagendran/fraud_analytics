import enum, uuid
from datetime import datetime, timezone
from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base

class TicketOwnershipStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"
    TRANSFER_PENDING = "TRANSFER_PENDING"
    REVOKED = "REVOKED"

class TicketTransferStatus(str, enum.Enum):
    PENDING = "PENDING"
    ACCEPTED = "ACCEPTED"
    CANCELLED = "CANCELLED"
    DECLINED = "DECLINED"
    EXPIRED = "EXPIRED"

class TicketOwnership(Base):
    __tablename__ = "ticket_ownerships"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ticket_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("ticket_purchases.id"), nullable=False)
    owner_fan_id: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[TicketOwnershipStatus] = mapped_column(SAEnum(TicketOwnershipStatus), nullable=False, default=TicketOwnershipStatus.ACTIVE)
    ownership_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    acquired_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    transferred_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (UniqueConstraint("ticket_id", name="uq_ticket_ownership_ticket"), Index("ix_ticket_ownership_owner_status", "owner_fan_id", "status"))

class TicketTransfer(Base):
    __tablename__ = "ticket_transfers"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ticket_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("ticket_purchases.id"), nullable=False, index=True)
    from_fan_id: Mapped[str] = mapped_column(String, nullable=False)
    to_fan_id: Mapped[str] = mapped_column(String, nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String(250), nullable=False, unique=True)
    status: Mapped[TicketTransferStatus] = mapped_column(SAEnum(TicketTransferStatus), nullable=False, default=TicketTransferStatus.PENDING)
    message: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    accepted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    cancelled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (Index("ix_ticket_transfers_recipient_status", "to_fan_id", "status"),)

class TicketOwnershipAudit(Base):
    __tablename__ = "ticket_ownership_audit"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ticket_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("ticket_purchases.id"), nullable=False, index=True)
    transfer_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("ticket_transfers.id"))
    action: Mapped[str] = mapped_column(String(80), nullable=False)
    actor_fan_id: Mapped[str] = mapped_column(String, nullable=False)
    from_fan_id: Mapped[str | None] = mapped_column(String)
    to_fan_id: Mapped[str | None] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
