﻿import enum
import uuid
from datetime import datetime, timezone
from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base

class TicketStatus(str, enum.Enum):
    PAID = "PAID"
    REFUNDED = "REFUNDED"
    FAILED = "FAILED"

class TicketPurchase(Base):
    __tablename__ = "ticket_purchases"
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("live_events.id"), nullable=False, index=True)
    fan_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    entitlement_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("entitlements.id"), nullable=True)
    tier_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("ticket_tiers.id"), nullable=True)
    provider: Mapped[str] = mapped_column(String, nullable=False)
    provider_payment_id: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    amount_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    currency: Mapped[str] = mapped_column(String(3), nullable=False)
    status: Mapped[TicketStatus] = mapped_column(SAEnum(TicketStatus), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    refunded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

class ProcessedPaymentEvent(Base):
    __tablename__ = "processed_payment_events"
    event_id: Mapped[str] = mapped_column(String, primary_key=True)
    event_type: Mapped[str] = mapped_column(String, nullable=False)
    processed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))

class ProcessedPurchaseRequest(Base):
    __tablename__ = "processed_purchase_requests"

    idempotency_key = mapped_column(
        String(255),
        primary_key=True
    )

    ticket_id = mapped_column(
        UUID,
        nullable=False,
        index=True
    )

    event_id = mapped_column(
        UUID,
        nullable=False,
        index=True
    )

    fan_id = mapped_column(
        String,
        nullable=False
    )

    created_at = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc)
    )