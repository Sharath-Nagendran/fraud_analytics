import enum, uuid
from datetime import datetime, timezone
from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Index, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base

class DeliveryStatus(str, enum.Enum):
    PENDING="PENDING"; SENT="SENT"; FAILED="FAILED"
class RefundJobStatus(str, enum.Enum):
    PENDING="PENDING"; COMPLETED="COMPLETED"; FAILED="FAILED"

class EventNotification(Base):
    __tablename__="event_notifications"
    id:Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    event_id:Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),ForeignKey("live_events.id"),nullable=False,index=True)
    fan_id:Mapped[str]=mapped_column(String,nullable=False)
    kind:Mapped[str]=mapped_column(String,nullable=False)
    payload:Mapped[str]=mapped_column(Text,nullable=False)
    status:Mapped[DeliveryStatus]=mapped_column(SAEnum(DeliveryStatus),nullable=False,default=DeliveryStatus.PENDING)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False,default=lambda:datetime.now(timezone.utc))
    sent_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    __table_args__=(Index("ix_event_notifications_status_created","status","created_at"),)

class EventRefundJob(Base):
    __tablename__="event_refund_jobs"
    id:Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    event_id:Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),ForeignKey("live_events.id"),nullable=False,index=True)
    ticket_id:Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),ForeignKey("ticket_purchases.id"),nullable=False)
    provider_payment_id:Mapped[str]=mapped_column(String,nullable=False)
    idempotency_key:Mapped[str]=mapped_column(String,nullable=False,unique=True)
    status:Mapped[RefundJobStatus]=mapped_column(SAEnum(RefundJobStatus),nullable=False,default=RefundJobStatus.PENDING)
    error:Mapped[str|None]=mapped_column(Text)
    created_at:Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False,default=lambda:datetime.now(timezone.utc))
    completed_at:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    __table_args__=(UniqueConstraint("event_id","ticket_id",name="uq_event_refund_job_ticket"),Index("ix_event_refund_jobs_status_created","status","created_at"),)
