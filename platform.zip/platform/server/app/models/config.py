import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    Index,
    SmallInteger,
    String,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Currency(Base):
    """
    Currencies events may be priced in. Rows are deactivated, never deleted,
    because existing events keep referring to their currency code.
    """

    __tablename__ = "currencies"

    code: Mapped[str] = mapped_column(String(3), primary_key=True)  # ISO 4217, upper-case
    name: Mapped[str] = mapped_column(String)
    # Decimal places of the currency's smallest unit (GBP/USD/EUR=2, JPY=0, KWD=3).
    # Needed to interpret integer prices correctly (see ticket_price_cents).
    minor_unit: Mapped[int] = mapped_column(SmallInteger)
    is_active: Mapped[bool] = mapped_column(Boolean)
    is_default: Mapped[bool] = mapped_column(Boolean)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now, onupdate=_now
    )

    __table_args__ = (
        CheckConstraint("code = upper(code)", name="ck_currencies_code_upper"),
        CheckConstraint("minor_unit >= 0 AND minor_unit <= 4", name="ck_currencies_minor_unit"),
        CheckConstraint("NOT is_default OR is_active", name="ck_currencies_default_is_active"),
        # At most one default currency, enforced by the database itself.
        Index(
            "uq_currencies_single_default",
            "is_default",
            unique=True,
            postgresql_where=text("is_default"),
        ),
    )


class AppSetting(Base):
    """Runtime-tunable key/value settings. Valid keys/types: app/core/setting_registry.py."""

    __tablename__ = "app_settings"

    key: Mapped[str] = mapped_column(String, primary_key=True)
    value: Mapped[object] = mapped_column(JSONB)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now, onupdate=_now
    )
    updated_by: Mapped[str | None] = mapped_column(String, nullable=True)


class ConfigAuditLog(Base):
    """Append-only history of every change made to currencies and settings."""

    __tablename__ = "config_audit_log"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    entity: Mapped[str] = mapped_column(String)  # "currency" | "setting"
    entity_key: Mapped[str] = mapped_column(String)
    action: Mapped[str] = mapped_column(String)  # "create" | "update"
    old_value: Mapped[object | None] = mapped_column(JSONB, nullable=True)
    new_value: Mapped[object | None] = mapped_column(JSONB, nullable=True)
    changed_by: Mapped[str] = mapped_column(String)
    changed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    __table_args__ = (Index("ix_config_audit_entity", "entity", "entity_key"),)
