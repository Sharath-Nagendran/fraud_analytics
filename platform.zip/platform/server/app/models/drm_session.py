import uuid
import enum
from datetime import datetime, timezone

from sqlalchemy import (
    DateTime,
    String,
    ForeignKey,
    Enum as SAEnum
)

from sqlalchemy.dialects.postgresql import UUID

from sqlalchemy.orm import (
    Mapped,
    mapped_column
)

from app.db.base import Base

class DrmSessionStatus(
    str,
    enum.Enum
):
    ACTIVE = "ACTIVE"
    REVOKED = "REVOKED"
    EXPIRED = "EXPIRED"

class DrmSession(Base):
    __tablename__ = "drm_sessions"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4
    )

    event_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("live_events.id"),
        nullable=False
    )

    fan_id: Mapped[str] = mapped_column(
        String,
        nullable=False
    )

    entitlement_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entitlements.id"),
        nullable=False
    )

    playback_session_id: Mapped[str] = mapped_column(
        String,
        nullable=False
    )

    drm_mode: Mapped[str] = mapped_column(
        String,
        nullable=False
    )

    watermark_id: Mapped[str] = mapped_column(
        String,
        nullable=False
    )

    status: Mapped[DrmSessionStatus] = mapped_column(SAEnum(DrmSessionStatus),nullable=False,default=DrmSessionStatus.ACTIVE)

    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),nullable=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )