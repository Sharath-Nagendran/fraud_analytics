from app.models.chat import ModerationDecisionType
from app.moderation.base import (
    ModerationProvider,
    ModerationRequest,
    ModerationResult,
)


class AllowAllModerationProvider(ModerationProvider):
    async def evaluate(
        self,
        request: ModerationRequest,
    ) -> ModerationResult:
        del request

        return ModerationResult(
            provider="allow_all",
            model_version="allow-all-v1",
            decision=ModerationDecisionType.ALLOW,
            categories={},
            severity=0,
            confidence=1.0,
            reason_code="ALLOW_ALL_PROVIDER",
            policy_rule="chat-policy-v1:allow-all",
        )
