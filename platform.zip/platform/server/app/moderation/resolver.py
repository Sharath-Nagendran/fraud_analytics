from functools import lru_cache

from app.core.config import settings
from app.moderation.allow_all import AllowAllModerationProvider
from app.moderation.base import ModerationProvider

from app.moderation.rule_based import RuleBasedModerationProvider

@lru_cache(maxsize=1)
def get_moderation_provider() -> ModerationProvider:
    provider = settings.chat_moderation_provider.strip().lower()

    if provider == "allow_all":
        return AllowAllModerationProvider()

    if provider == "rule_based":
        return RuleBasedModerationProvider()

    raise RuntimeError(
        "Unsupported CHAT_MODERATION_PROVIDER: "
        f"{settings.chat_moderation_provider}"
    )