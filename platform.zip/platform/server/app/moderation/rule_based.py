from app.core.config import settings
from app.models.chat import (
    ModerationDecisionType,
)
from app.moderation.base import (
    ModerationProvider,
    ModerationRequest,
    ModerationResult,
)

class RuleBasedModerationProvider(
    ModerationProvider
):
    async def evaluate(
        self,
        request: ModerationRequest,
    ) -> ModerationResult:

        message = request.text.lower()

        for term in settings.blocked_terms:

            if term in message:

                return ModerationResult(
                    provider="rule_based",
                    model_version="v1",
                    decision=(
                        ModerationDecisionType.BLOCK
                    ),
                    categories={
                        "abusive_language": True
                    },
                    severity=5,
                    confidence=1.0,
                    reason_code="BLOCKED_TERM",
                    policy_rule=(
                        f"contains:{term}"
                    ),
                )

        return ModerationResult(
            provider="rule_based",
            model_version="v1",
            decision=(
                ModerationDecisionType.ALLOW
            ),
            confidence=1.0,
        )