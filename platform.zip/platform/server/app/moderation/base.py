from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from app.models.chat import (
    ChatParticipantType,
    ModerationDecisionType,
)


@dataclass(frozen=True)
class ModerationRequest:
    text: str
    room_id: str
    sender_type: ChatParticipantType
    sender_id: str
    warning_count: int
    policy_version: str


@dataclass(frozen=True)
class ModerationResult:
    provider: str
    model_version: str | None
    decision: ModerationDecisionType
    categories: dict = field(default_factory=dict)
    severity: int | None = None
    confidence: float | None = None
    reason_code: str | None = None
    policy_rule: str | None = None
    provider_request_id: str | None = None
    provider_payload: dict | None = None


class ModerationProvider(ABC):
    @abstractmethod
    async def evaluate(
        self,
        request: ModerationRequest,
    ) -> ModerationResult:
        raise NotImplementedError
