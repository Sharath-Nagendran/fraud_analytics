from datetime import datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, field_validator


class CreateLiveEventRequest(BaseModel):
    title: str
    description: Optional[str] = None
    cover_image_url: Optional[str] = None
    scheduled_start: datetime
    ticket_price_cents: int = Field(gt=0)
    currency: Optional[str] = None
    capacity: Optional[int] = Field(default=None, gt=0)

    @field_validator("currency")
    @classmethod
    def normalize_currency(cls, value):
        return value.strip().upper() if value else None

    @field_validator("scheduled_start")
    @classmethod
    def future(cls, value):
        now = datetime.now(value.tzinfo) if value.tzinfo else datetime.now()
        if value <= now:
            raise ValueError("scheduled_start must be in the future")
        return value


class RescheduleLiveEventRequest(BaseModel):
    scheduled_start: datetime


class LiveEventPublic(BaseModel):
    id: UUID
    title: str
    description: Optional[str] = None
    cover_image_url: Optional[str] = None
    scheduled_start: datetime
    ticket_price_cents: int
    currency: str
    capacity: Optional[int] = None
    status: str
    stream_active: bool = False
    model_config = ConfigDict(from_attributes=True)
    finalized_at: datetime | None = None

class LiveEventCreateResponse(LiveEventPublic):
    video_provider: str
    rtmp_ingest_url: str
    stream_key: str
    playback_id: str


class IngestCredentials(BaseModel):
    video_provider: str
    rtmp_ingest_url: str
    stream_key: str
    playback_id: str
