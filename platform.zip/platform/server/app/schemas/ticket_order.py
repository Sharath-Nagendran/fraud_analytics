from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, Field
from app.models.ticket_order import TicketOrderType


class CreateTicketOrderRequest(BaseModel):
    event_id: UUID
    buyer_fan_id: str = Field(min_length=1, max_length=200)
    quantity: int = Field(ge=1, le=20)
    idempotency_key: str = Field(min_length=8, max_length=255)
    purchase_type: TicketOrderType = TicketOrderType.LIVE_EVENT


class OrderedTicketResponse(BaseModel):
    ticket_id: UUID
    entitlement_id: UUID
    owner_fan_id: str
    line_number: int


class TicketOrderResponse(BaseModel):
    order_id: UUID
    event_id: UUID
    buyer_fan_id: str
    quantity: int
    unit_amount_cents: int
    total_amount_cents: int
    currency: str
    provider: str
    provider_payment_id: str
    status: str
    purchase_type: str
    created_at: datetime
    tickets: list[OrderedTicketResponse]
