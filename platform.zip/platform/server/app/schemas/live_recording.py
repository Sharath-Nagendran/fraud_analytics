from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class FinalizeLiveEventResponse(BaseModel):
    event_id: UUID
    status: str
    finalized_at: datetime
    recording_id: UUID
    recording_status: str
    stream_path: str
    replay_job_id: UUID
    replay_job_status: str


class LiveRecordingSpanResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    live_recording_id: UUID
    source_url: str
    started_at: datetime
    duration_milliseconds: int
    status: str
    local_path: str | None
    failure_reason: str | None
    created_at: datetime


class RecordingDiscoveryResponse(BaseModel):
    recording_id: UUID
    event_id: UUID
    stream_path: str
    recording_status: str
    provider_span_count: int
    discovered: int
    existing: int
    total_persisted: int
    spans: list[LiveRecordingSpanResponse]


class RecordingDownloadFailure(BaseModel):
    span_id: UUID
    error: str


class RecordingDownloadResponse(BaseModel):
    recording_id: UUID
    event_id: UUID
    stream_path: str
    total_spans: int
    downloaded: int
    existing: int
    failed: int
    work_directory: str
    failures: list[RecordingDownloadFailure]


class ReplayAssemblyResponse(BaseModel):
    recording_id: UUID
    event_id: UUID
    recording_status: str
    video_asset_id: UUID
    video_asset_status: str
    storage_provider: str | None
    storage_object_key: str | None
    storage_url: str | None
    reused: bool


class ReplayPipelineResponse(BaseModel):
    event_id: UUID
    recording_id: UUID
    discovery: RecordingDiscoveryResponse
    download: RecordingDownloadResponse
    assembly: ReplayAssemblyResponse