from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
)


class DrmConfigResponse(BaseModel):
    model_config = ConfigDict(
        from_attributes=True,
    )

    enabled: bool

    provider: str

    watermark_enabled: bool

    widevine_url: str | None = None

    fairplay_url: str | None = None

    playready_url: str | None = None


class DrmConfigUpdate(BaseModel):
    enabled: bool

    provider: str = Field(
        min_length=4,
        max_length=10,
    )

    watermark_enabled: bool

    widevine_url: str | None = None

    fairplay_url: str | None = None

    playready_url: str | None = None