from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class ChatRoomResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    room_type: str
    live_event_id: UUID | None
    video_asset_id: UUID | None
    artist_id: str
    status: str
    moderation_enabled: bool
    moderation_policy_version: str
    created_at: datetime
    closed_at: datetime | None


class ChatParticipantResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    chat_room_id: UUID
    participant_type: str
    participant_id: str
    status: str
    warning_count: int
    muted_until: datetime | None
    joined_at: datetime
    last_seen_at: datetime | None
    removed_at: datetime | None


class ChatMessageCreateRequest(BaseModel):
    client_message_id: str = Field(min_length=1, max_length=255)
    body: str = Field(min_length=1, max_length=2000)


class ChatMessageResponse(BaseModel):
    id: UUID
    chat_room_id: UUID
    sender_participant_id: UUID
    sender_type: str
    sender_id: str
    sequence_number: int
    message_type: str
    body: str
    status: str
    client_message_id: str
    created_at: datetime
    moderation_decision: str


class ChatMessagePageResponse(BaseModel):
    room_id: UUID
    messages: list[ChatMessageResponse]
    next_after_sequence: int | None
