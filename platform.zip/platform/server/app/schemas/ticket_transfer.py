from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, Field

class InitiateTransferRequest(BaseModel):
    to_fan_id: str = Field(min_length=1, max_length=200)
    idempotency_key: str = Field(min_length=8, max_length=250)
    message: str | None = Field(default=None, max_length=1000)

class TransferResponse(BaseModel):
    id: UUID
    ticket_id: UUID
    from_fan_id: str
    to_fan_id: str
    status: str
    message: str | None
    created_at: datetime
    expires_at: datetime
    accepted_at: datetime | None
    cancelled_at: datetime | None

class OwnedTicketResponse(BaseModel):
    ticket_id: UUID
    event_id: UUID
    purchaser_fan_id: str
    owner_fan_id: str
    ownership_status: str
    ticket_status: str
    entitlement_id: UUID | None
    tier_id: UUID | None
    amount_cents: int
    currency: str
