from datetime import datetime

from pydantic import BaseModel


class VideoAssetPlaybackRequest(BaseModel):
    session_id: str | None = None


class VideoAssetPlaybackResponse(BaseModel):
    asset_id: str
    entitlement_id: str
    session_id: str

    provider: str
    playback_url: str
    token: str | None

    expires_at: datetime
    refresh_after_seconds: int