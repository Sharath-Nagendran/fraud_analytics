from datetime import datetime
from uuid import UUID
from pydantic import BaseModel,Field
class EventChangeSummary(BaseModel):
    event_id:UUID; status:str; notifications_queued:int; refund_jobs_queued:int; entitlements_revoked:int; preissued_grants_revoked:int
class DispatchRequest(BaseModel):
    batch_size:int=Field(default=100,ge=1,le=1000)
class DispatchSummary(BaseModel):
    refund_jobs_completed:int; refund_jobs_failed:int; notifications_sent:int
class EventChangeStatus(BaseModel):
    event_id:UUID; notifications_pending:int; notifications_sent:int; refunds_pending:int; refunds_completed:int; refunds_failed:int
