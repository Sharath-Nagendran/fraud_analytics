from datetime import datetime

from pydantic import BaseModel, Field


class PlaybackTokenRequest(BaseModel):
    session_id: str | None = None


class PlaybackTokenResponse(BaseModel):
    event_id: str
    provider: str
    playback_id: str
    playback_url: str | None = None
    token: str | None = None
    expires_at: datetime
    refresh_after_seconds: int
    session_id: str
    mode: str


class MockEntitlementRequest(BaseModel):
    fan_id: str = Field(
        min_length=1
    )