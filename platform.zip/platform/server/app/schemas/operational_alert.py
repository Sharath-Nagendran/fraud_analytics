from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class AlertSignalRequest(BaseModel):
    details: str | None = Field(default=None, max_length=2000)
    error_rate_percent: float | None = Field(default=None, ge=0, le=100)


class AlertActionRequest(BaseModel):
    operator_id: str = Field(min_length=1, max_length=200)
    note: str | None = Field(default=None, max_length=2000)


class OperationalAlertResponse(BaseModel):
    id: UUID
    event_id: UUID
    alert_type: str
    severity: str
    status: str
    summary: str
    details: str | None
    occurrence_count: int
    first_seen_at: datetime
    last_seen_at: datetime
    acknowledged_at: datetime | None
    acknowledged_by: str | None
    resolved_at: datetime | None
    resolution_note: str | None


class AlertDispatchRequest(BaseModel):
    batch_size: int = Field(default=100, ge=1, le=1000)


class AlertDispatchResponse(BaseModel):
    sent: int
    failed: int


class AlertSummary(BaseModel):
    firing: int
    acknowledged: int
    resolved: int
    pending_deliveries: int
