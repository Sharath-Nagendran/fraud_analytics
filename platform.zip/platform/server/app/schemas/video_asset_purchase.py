from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class PurchaseVideoAssetRequest(BaseModel):
    fan_id: str = Field(
        min_length=1,
        max_length=200,
    )

    idempotency_key: str = Field(
        min_length=8,
        max_length=255,
    )


class VideoAssetPurchaseResponse(BaseModel):
    purchase_id: UUID
    video_asset_id: UUID
    fan_id: str
    entitlement_id: UUID
    provider: str
    provider_payment_id: str
    amount_cents: int
    currency: str
    status: str
    entitlement_status: str
    created_at: datetime


class VideoAssetEntitlementResponse(BaseModel):
    model_config = ConfigDict(
        from_attributes=True,
    )

    id: UUID
    video_asset_id: UUID
    fan_id: str
    source: str
    status: str
    valid_from: datetime
    valid_until: datetime | None