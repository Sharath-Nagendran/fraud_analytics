from datetime import datetime
from uuid import UUID
from pydantic import BaseModel

class ReplayDetails(BaseModel):
    event_id: UUID
    status: str
    available: bool
    archived_at: datetime | None = None

class ReplayTokenRequest(BaseModel):
    session_id: str | None = None

class ReplayTokenResponse(BaseModel):
    event_id: UUID
    playback_id: str
    token: str
    expires_at: datetime
    refresh_after_seconds: int
    session_id: str
    mode: str
