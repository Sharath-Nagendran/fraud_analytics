from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field


class ApproveCompensationRequest(BaseModel):
    operator_id: str = Field(min_length=1, max_length=200)


class RejectCompensationRequest(BaseModel):
    operator_id: str = Field(min_length=1, max_length=200)
    reason: str = Field(min_length=1, max_length=2000)


class CompensationApprovalResponse(BaseModel):
    incident_id: UUID
    approved: int
    skipped: int
    queued: int


class CompensationCaseResponse(BaseModel):
    id: UUID
    incident_id: UUID
    candidate_id: UUID
    ticket_id: UUID
    event_id: UUID
    fan_id: str
    compensation_type: str
    amount_cents: int
    currency: str
    status: str
    provider_reference: str | None
    failure_reason: str | None
    approved_by: str
    approved_at: datetime
    completed_at: datetime | None
    reconciliation_attempts: int


class CompensationDispatchRequest(BaseModel):
    batch_size: int = Field(default=100, ge=1, le=1000)


class CompensationDispatchResponse(BaseModel):
    completed: int
    failed: int
    skipped: int


class CompensationReconcileResponse(BaseModel):
    examined: int
    corrected: int
    manual_review: int


class CompensationSummary(BaseModel):
    incident_id: UUID
    candidates_pending: int
    candidates_approved: int
    candidates_rejected: int
    candidates_refunded: int
    cases_queued: int
    cases_completed: int
    cases_failed: int
    cases_manual_review: int
