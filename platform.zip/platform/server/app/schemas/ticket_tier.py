from uuid import UUID
from pydantic import BaseModel, Field, field_validator

class CreateTicketTierRequest(BaseModel):
    code: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1, max_length=120)
    description: str | None = None
    price_cents: int = Field(gt=0)
    capacity: int | None = Field(default=None, gt=0)
    early_access_seconds: int = Field(default=0, ge=0, le=86400)
    content_access: list[str] = Field(default_factory=lambda: ["LIVE", "REPLAY"])

    @field_validator("code")
    @classmethod
    def normalize_code(cls, value: str) -> str:
        return value.strip().upper().replace(" ", "_")

    @field_validator("content_access")
    @classmethod
    def validate_access(cls, value: list[str]) -> list[str]:
        allowed = {"LIVE", "REPLAY", "VIP_CONTENT"}
        normalized = sorted({item.strip().upper() for item in value})
        if not normalized or not set(normalized).issubset(allowed):
            raise ValueError("content_access must contain LIVE, REPLAY and/or VIP_CONTENT")
        return normalized

class TicketTierResponse(BaseModel):
    id: UUID
    event_id: UUID
    code: str
    name: str
    description: str | None
    price_cents: int
    capacity: int | None
    sold_count: int
    early_access_seconds: int
    content_access: list[str]
    is_active: bool

class PurchaseTierRequest(BaseModel):
    fan_id: str = Field(min_length=1)
    tier_id: UUID
    idempotency_key: str = Field(min_length=8, max_length=128)
