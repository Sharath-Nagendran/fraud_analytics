from uuid import UUID
from pydantic import BaseModel, Field

class PurchaseTicketRequest(BaseModel):
    event_id: UUID
    fan_id: str = Field(min_length=1)
    idempotency_key: str = Field(min_length=8, max_length=128)

class RefundTicketRequest(BaseModel):
    payment_id: str = Field(min_length=1)
    reason: str = Field(default="requested_by_customer", min_length=1, max_length=200)
    idempotency_key: str = Field(min_length=8, max_length=128)

class TicketResponse(BaseModel):
    ticket_id: UUID
    payment_id: str
    event_id: UUID
    fan_id: str
    status: str
    entitlement_status: str
    amount_cents: int
    currency: str
    provider: str
