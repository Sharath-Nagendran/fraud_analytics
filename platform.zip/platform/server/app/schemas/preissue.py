from uuid import UUID
from pydantic import BaseModel, Field

class PreissueRunRequest(BaseModel):
    batch_size: int = Field(default=500, ge=1, le=5000)

class PreissueRunResponse(BaseModel):
    event_id: UUID
    eligible: int
    created: int
    refreshed: int
    skipped: int
    failed: int
    status: str

class PreissueStatusResponse(BaseModel):
    event_id: UUID
    ready: int
    consumed: int
    expired: int
    revoked: int
