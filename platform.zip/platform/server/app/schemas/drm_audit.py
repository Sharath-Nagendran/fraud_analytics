from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class DrmSessionResponse(BaseModel):
    id: UUID
    event_id: UUID
    fan_id: str
    entitlement_id: UUID
    playback_session_id: str
    drm_mode: str
    watermark_id: str
    created_at: datetime