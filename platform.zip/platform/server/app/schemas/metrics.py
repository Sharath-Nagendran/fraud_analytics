from pydantic import BaseModel
class PlatformMetrics(BaseModel):
    events_total:int; events_live:int; events_archived:int
    tickets_sold:int; tickets_refunded:int
    active_sessions:int; playback_tokens_issued:int; playback_tokens_denied:int
class EventHealth(BaseModel):
    event_id:str; status:str; active_sessions:int; stream_health:str
