from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, Field
class EventHealth(BaseModel):
    event_id:UUID; event_status:str; stream_health:str; active_sessions:int
    open_incidents:int; last_incident_at:datetime|None=None
class SimulateOutageRequest(BaseModel):
    duration_seconds:int=Field(ge=1,le=86400)
    affected_viewer_percent:int=Field(ge=0,le=100)
    details:str|None=None
class IncidentResponse(BaseModel):
    incident_id:UUID; status:str; refund_review_required:bool; refund_candidates:int
class CandidateDecisionRequest(BaseModel):
    decision:str=Field(pattern="^(APPROVED|REJECTED)$")
