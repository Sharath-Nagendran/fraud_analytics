from pydantic import BaseModel


class DrmLicenseRequest(BaseModel):

    session_id: str


class DrmLicenseResponse(BaseModel):

    drm_mode: str

    license_token: str | None = None

    watermark_id: str | None = None

    widevine: bool | None = None

    fairplay: bool | None = None

    playready: bool | None = None

    widevine_url: str | None = None

    fairplay_url: str | None = None

    playready_url: str | None = None