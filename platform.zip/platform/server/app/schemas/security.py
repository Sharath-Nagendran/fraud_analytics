from uuid import UUID
from pydantic import BaseModel

class SecurityCheck(BaseModel):
    name: str
    status: str
    detail: str

class EventSecurityAudit(BaseModel):
    event_id: UUID
    mode: str
    overall_status: str
    checks: list[SecurityCheck]
    public_schema_violations: list[str]
