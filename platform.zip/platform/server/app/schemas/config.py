from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator


class CurrencyPublic(BaseModel):
    code: str
    name: str
    minor_unit: int
    is_default: bool

    model_config = {"from_attributes": True}


class CurrencyAdmin(CurrencyPublic):
    is_active: bool


class CurrencyCreate(BaseModel):
    code: str
    name: str = Field(min_length=1)
    minor_unit: int = Field(ge=0, le=4)
    is_active: bool = True
    is_default: bool = False

    @field_validator("code")
    @classmethod
    def _upper(cls, v: str) -> str:
        return v.strip().upper()


class CurrencyUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1)
    minor_unit: Optional[int] = Field(default=None, ge=0, le=4)
    is_active: Optional[bool] = None
    is_default: Optional[bool] = None


class SettingOut(BaseModel):
    key: str
    kind: str
    description: str
    value: Any = None
    updated_at: Optional[datetime] = None
    updated_by: Optional[str] = None


class SettingUpdate(BaseModel):
    value: Any
