from datetime import datetime
from uuid import UUID

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    model_validator,
)

from app.models.video_asset import (
    VideoAssetStatus,
    VideoAssetType,
    VideoAssetVisibility,
)


class CreateVideoAssetRequest(BaseModel):
    title: str = Field(
        min_length=1,
        max_length=300,
    )

    description: str | None = None

    asset_type: VideoAssetType

    source_live_event_id: UUID | None = None

    storage_url: str | None = None

    thumbnail_url: str | None = None

    duration_seconds: int | None = Field(
        default=None,
        ge=0,
    )

    visibility: VideoAssetVisibility = (
        VideoAssetVisibility.PRIVATE
    )

    price_cents: int | None = Field(
        default=None,
        ge=0,
    )

    currency: str = Field(
        default="GBP",
        min_length=3,
        max_length=3,
    )

    @model_validator(mode="after")
    def validate_visibility_and_price(self):
        if (
            self.visibility
            == VideoAssetVisibility.PPV
            and (
                self.price_cents is None
                or self.price_cents <= 0
            )
        ):
            raise ValueError(
                "price_cents must be greater than zero "
                "for PPV video assets"
            )

        if (
            self.visibility
            != VideoAssetVisibility.PPV
            and self.price_cents is not None
        ):
            raise ValueError(
                "price_cents is only supported for "
                "PPV video assets"
            )

        self.currency = self.currency.upper()

        return self


class UpdateVideoAssetRequest(BaseModel):
    title: str | None = Field(
        default=None,
        min_length=1,
        max_length=300,
    )

    description: str | None = None

    storage_url: str | None = None

    thumbnail_url: str | None = None

    duration_seconds: int | None = Field(
        default=None,
        ge=0,
    )

    visibility: VideoAssetVisibility | None = None

    price_cents: int | None = Field(
        default=None,
        ge=0,
    )

    currency: str | None = Field(
        default=None,
        min_length=3,
        max_length=3,
    )


class VideoAssetPublicResponse(BaseModel):
    model_config = ConfigDict(
        from_attributes=True,
    )

    id: UUID
    artist_id: str

    source_live_event_id: UUID | None

    title: str
    description: str | None

    asset_type: VideoAssetType

    thumbnail_url: str | None
    duration_seconds: int | None

    visibility: VideoAssetVisibility

    price_cents: int | None
    currency: str

    status: VideoAssetStatus

    published_at: datetime | None

    created_at: datetime
    updated_at: datetime


class VideoAssetArtistResponse(
    VideoAssetPublicResponse
):
    video_provider: str

    video_asset_provider_id: str | None

    storage_url: str | None


class PublishVideoAssetResponse(BaseModel):
    model_config = ConfigDict(
        from_attributes=True,
    )

    id: UUID

    status: VideoAssetStatus

    visibility: VideoAssetVisibility

    published_at: datetime

    updated_at: datetime