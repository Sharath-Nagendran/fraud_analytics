from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class ReplayJobResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    live_event_id: UUID
    live_recording_id: UUID
    status: str
    attempts: int
    max_attempts: int
    next_attempt_at: datetime
    locked_at: datetime | None
    locked_by: str | None
    last_error: str | None
    video_asset_id: UUID | None
    created_at: datetime
    updated_at: datetime
    completed_at: datetime | None
