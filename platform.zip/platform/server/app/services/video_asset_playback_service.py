import secrets
import uuid

from datetime import datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.video_asset import (VideoAsset, VideoAssetStatus, VideoAssetVisibility,)
from app.models.video_asset_entitlement import (VideoAssetEntitlement, VideoAssetEntitlementStatus,)
from app.storage import get_storage_provider

class VideoAssetPlaybackService:

    async def issue_grant(
        self,
        db: AsyncSession,
        asset_id: str,
        fan_id: str,
        requested_session_id: str | None = None,
    ) -> dict:

        asset_key = self._parse_asset_id(
            asset_id
        )

        asset = await db.get(
            VideoAsset,
            asset_key,
        )

        if not asset:
            raise HTTPException(
                status_code=404,
                detail="Video asset not found",
            )

        if asset.status != VideoAssetStatus.READY:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Video asset is not ready "
                    "for playback"
                ),
            )

        if (not asset.storage_object_key
                and not asset.storage_url):
            raise HTTPException(
                status_code=409,
                detail=(
                    "Playback is not available "
                    "for this video asset"
                ),
            )

        if asset.visibility == VideoAssetVisibility.PRIVATE:
            raise HTTPException(
                status_code=403,
                detail=(
                    "This video asset is private"
                ),
            )

        entitlement = await self._active_entitlement(
            db=db,
            asset_id=asset_key,
            fan_id=fan_id,
        )

        session_id = (
            requested_session_id.strip()
            if requested_session_id
            and requested_session_id.strip()
            else str(uuid.uuid4())
        )

        now = datetime.now(timezone.utc)

        expires_at = now + timedelta(
            seconds=(
                settings.playback_token_ttl_seconds
            )
        )

        provider = (
            asset.video_provider
            or settings.video_provider
        )

        token = self._issue_token_for_provider(
            provider=provider,
        )

        if asset.storage_object_key:
            storage = get_storage_provider()

            playback_url = (
                await storage.get_playback_url(
                    object_key=(
                        asset.storage_object_key
                    ),
                    expires_seconds=(
                        settings
                        .playback_token_ttl_seconds
                    ),
                )
            )
        else:
            playback_url = asset.storage_url

        return {
            "asset_id": str(asset.id),
            "entitlement_id": str(
                entitlement.id
            ),
            "session_id": session_id,
            "provider": provider,
            "playback_url": playback_url,
            "token": token,
            "expires_at": expires_at,
            "refresh_after_seconds": (
                settings.playback_token_refresh_seconds
            ),
        }

    async def _active_entitlement(
        self,
        db: AsyncSession,
        asset_id: uuid.UUID,
        fan_id: str,
    ) -> VideoAssetEntitlement:

        now = datetime.now(timezone.utc)

        entitlement = (
            await db.execute(
                select(VideoAssetEntitlement)
                .where(
                    VideoAssetEntitlement.video_asset_id
                    == asset_id,
                    VideoAssetEntitlement.fan_id
                    == fan_id,
                    VideoAssetEntitlement.status
                    == VideoAssetEntitlementStatus.ACTIVE,
                    VideoAssetEntitlement.valid_from
                    <= now,
                    or_(
                        VideoAssetEntitlement.valid_until
                        .is_(None),
                        VideoAssetEntitlement.valid_until
                        > now,
                    ),
                )
                .order_by(
                    VideoAssetEntitlement.created_at.desc()
                )
            )
        ).scalars().first()

        if not entitlement:
            raise HTTPException(
                status_code=403,
                detail=(
                    "A valid video asset entitlement "
                    "is required"
                ),
            )

        return entitlement

    @staticmethod
    def _issue_token_for_provider(
        provider: str,
    ) -> str | None:

        normalized_provider = (
            provider.strip().lower()
        )

        if normalized_provider == "mock":
            return (
                "mock-video-asset-token-"
                f"{secrets.token_urlsafe(24)}"
            )

        if normalized_provider in {
            "selfhosted",
            "fastpix",
        }:
            return None

        if normalized_provider == "mux":
            raise HTTPException(
                status_code=501,
                detail=(
                    "Signed Mux VideoAsset playback "
                    "is not implemented yet"
                ),
            )

        raise HTTPException(
            status_code=500,
            detail=(
                "Unsupported VideoAsset "
                f"provider: {provider}"
            ),
        )

    @staticmethod
    def _parse_asset_id(
        asset_id: str,
    ) -> uuid.UUID:

        try:
            return uuid.UUID(
                str(asset_id)
            )

        except ValueError as exc:
            raise HTTPException(
                status_code=404,
                detail="Video asset not found",
            ) from exc


video_asset_playback_service = (
    VideoAssetPlaybackService()
)