import asyncio
import uuid
from datetime import datetime, timezone
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.base import AsyncSessionLocal
from app.models.live_event import LiveEvent, LiveEventStatus
from app.schemas.live_event import CreateLiveEventRequest, RescheduleLiveEventRequest
from app.services.config_service import config_service
from app.video.contracts import CreateStreamCommand
from app.video.resolver import video_provider_resolver
from app.models.live_recording import (LiveRecording,LiveRecordingStatus,)
from app.services.replay_job_service import (replay_job_service,)


class LiveService:
    async def create_event(self, db: AsyncSession, artist_id: str, payload: CreateLiveEventRequest) -> dict:
        currency = await config_service.resolve_currency(payload.currency)
        event = LiveEvent(
            artist_id=artist_id, title=payload.title, description=payload.description,
            cover_image_url=payload.cover_image_url, scheduled_start=payload.scheduled_start,
            ticket_price_cents=payload.ticket_price_cents, currency=currency.code,
            capacity=payload.capacity, status=LiveEventStatus.DRAFT,
        )
        db.add(event)
        await db.flush()
        provider = video_provider_resolver.default()
        resource = await provider.create_live_stream(CreateStreamCommand(
            event_id=str(event.id),
            reconnect_window_seconds=await config_service.get_setting("mux.reconnect_window_seconds"),
            low_latency=await config_service.get_setting("mux.reduced_latency"),
            playback_policy=await config_service.get_setting("mux.playback_policy"),
        ))
        event.video_provider = resource.provider
        event.video_stream_id = resource.stream_id
        event.video_stream_key = resource.stream_key
        event.video_playback_id = resource.playback_id
        event.video_ingest_url = resource.ingest_url
        event.video_playback_url = resource.playback_url
        event.status = LiveEventStatus.SCHEDULED
        await db.commit()
        await db.refresh(event)
        return {
            "id": str(event.id), "title": event.title, "description": event.description,
            "cover_image_url": event.cover_image_url, "scheduled_start": event.scheduled_start,
            "ticket_price_cents": event.ticket_price_cents, "currency": event.currency,
            "capacity": event.capacity, "status": event.status.value,
            "video_provider": event.video_provider,
            "rtmp_ingest_url": event.video_ingest_url,
            "stream_key": event.video_stream_key,
            "playback_id": event.video_playback_id,
        }

    async def get_ingest_credentials(self, db, artist_id, event_id):
        event = await self._get_owned_event(db, artist_id, event_id)
        if not event.video_stream_key or not event.video_ingest_url:
            raise HTTPException(400, "This event has no ingest credentials")
        return {"video_provider": event.video_provider, "rtmp_ingest_url": event.video_ingest_url,
                "stream_key": event.video_stream_key, "playback_id": event.video_playback_id}

    async def get_public_event(self, db, event_id):
        event = await self._get_event(db, event_id,)

        if event.status == LiveEventStatus.DRAFT:
            raise HTTPException(404,"Event not found",)

        stream_active = False

        if (event.video_provider and event.video_stream_id):
            try:
                provider = (video_provider_resolver.resolve(event.video_provider))
                state = (await provider.get_live_stream_status(event.video_stream_id))
                stream_active = (state.status.lower() == "active")
            except Exception:
                pass

        return {
            **event.__dict__,
            "stream_active": stream_active,
        }

    async def reschedule(self, db, artist_id, event_id, payload: RescheduleLiveEventRequest):
        event = await self._get_owned_event(db, artist_id, event_id)
        if event.status != LiveEventStatus.SCHEDULED:
            raise HTTPException(400, f"Cannot reschedule an event in status {event.status.value}")
        now = datetime.now(payload.scheduled_start.tzinfo) if payload.scheduled_start.tzinfo else datetime.now()
        if payload.scheduled_start <= now:
            raise HTTPException(400, "New scheduled_start must be in the future")
        event.scheduled_start = payload.scheduled_start
        await db.commit(); await db.refresh(event)
        return event

    async def cancel(self, db, artist_id, event_id):
        event = await self._get_owned_event(db, artist_id, event_id)
        if event.status in (LiveEventStatus.LIVE, LiveEventStatus.ENDED, LiveEventStatus.ARCHIVED):
            raise HTTPException(400, f"Cannot cancel an event in status {event.status.value}")
        provider = video_provider_resolver.resolve(event.video_provider)
        await provider.delete_live_stream(event.video_stream_id)
        event.status = LiveEventStatus.CANCELLED
        await db.commit(); await db.refresh(event)
        return event

    async def end_broadcast(self, db, artist_id, event_id):
        event = await self._get_owned_event(db, artist_id, event_id)
        if event.finalized_at is not None:
            raise
        if event.status != LiveEventStatus.LIVE:
            raise HTTPException(400, "Event is not currently live")
        provider = video_provider_resolver.resolve(event.video_provider)
        await provider.complete_live_stream(event.video_stream_id)
        return await self._mark_ended(db, event)

    async def finalize_event(self, db: AsyncSession, artist_id: str, event_id: str,) -> dict:
        event = await self._get_owned_event(db, artist_id, event_id,)
        if event.finalized_at is not None:
            recording = (await db.execute(select(LiveRecording).where(LiveRecording.live_event_id== event.id))).scalar_one_or_none()

            if not recording:
                raise HTTPException(status_code=500, detail=("Finalized event has no recording lifecycle record"),)

            provider = video_provider_resolver.resolve(event.video_provider)
            state = await provider.get_live_stream_status(event.video_stream_id)
            if state.status.lower() == "active":
                raise HTTPException(status_code=409, detail=("The performance is still receiving video. Stop streaming before finalization."),)

            replay_job = await replay_job_service.enqueue(db=db, event=event, recording=recording,)
            await db.commit()
            await db.refresh(replay_job)

            return {
                "event_id": event.id,
                "status": event.status.value,
                "finalized_at": event.finalized_at,
                "recording_id": recording.id,
                "recording_status": (
                    recording.status.value
                ),
                "stream_path": recording.stream_path,
                "replay_job_id": replay_job.id,
                "replay_job_status": (
                    replay_job.status.value
                ),
            }

        if event.status == LiveEventStatus.LIVE:
            raise HTTPException(status_code=409,detail=("End the live performance before finalizing it"),)

        if event.status != LiveEventStatus.ENDED:
            raise HTTPException(status_code=409, detail=("Only an ended performance can be finalized"),)

        stream_path = self._recording_stream_path(event)
        recording = (await db.execute(select(LiveRecording).where(LiveRecording.live_event_id== event.id).with_for_update())).scalar_one_or_none()

        if not recording:
            recording = LiveRecording(live_event_id=event.id,stream_path=stream_path,status=(LiveRecordingStatus.COLLECTING),)

            db.add(recording)
            await db.flush()

        provider = video_provider_resolver.resolve(event.video_provider)
        state = await provider.get_live_stream_status(event.video_stream_id)
        if state.status.lower() == "active":
            raise HTTPException(status_code=409, detail=(
                "The performance is still receiving video. Stop streaming before finalization."), )
        event.finalized_at = datetime.now(timezone.utc)
        recording.updated_at = datetime.now(timezone.utc)

        replay_job = await replay_job_service.enqueue(db=db,event=event,recording=recording,)

        await db.commit()
        await db.refresh(event)
        await db.refresh(recording)
        await db.refresh(replay_job)

        return {
            "event_id": event.id,
            "status": event.status.value,
            "finalized_at": event.finalized_at,
            "recording_id": recording.id,
            "recording_status": (
                recording.status.value
            ),
            "stream_path": recording.stream_path,
            "replay_job_id": replay_job.id,
            "replay_job_status": (
                replay_job.status.value
            ),
        }

    async def handle_stream_active(self, db, provider_name, stream_id):
        event = await self._find_by_stream(db, provider_name, stream_id)
        if event:
            if event.finalized_at is not None:
                raise HTTPException(status_code=409,detail=("Finalized events cannot be restarted"),)

            event.status = LiveEventStatus.LIVE
            event.ended_at = None

            await db.commit()
            await db.refresh(event)

            return event

    async def handle_stream_idle(self, db, provider_name, stream_id):
        event = await self._find_by_stream(db, provider_name, stream_id)
        if event and event.status == LiveEventStatus.LIVE:
            timeout = await config_service.get_setting("live.idle_timeout_seconds")
            asyncio.create_task(self._idle_timeout_check(event.id, timeout))

    async def _idle_timeout_check(self, event_id, timeout_seconds):
        await asyncio.sleep(timeout_seconds)
        async with AsyncSessionLocal() as db:
            event = await db.get(LiveEvent, event_id)
            if (event and event.status == LiveEventStatus.LIVE and event.finalized_at is None):
                await self._mark_ended(db, event)

    async def _mark_ended(self, db, event):
        event.status = LiveEventStatus.ENDED
        event.ended_at = datetime.now(timezone.utc)
        await db.commit(); await db.refresh(event)
        return event

    async def _find_by_stream(self, db, provider_name, stream_id):
        result = await db.execute(select(LiveEvent).where(
            LiveEvent.video_provider == provider_name,
            LiveEvent.video_stream_id == stream_id,
        ))
        return result.scalar_one_or_none()

    async def _get_event(self, db, event_id):
        event = await db.get(LiveEvent, event_id)
        if not event:
            raise HTTPException(404, "Event not found")
        return event

    async def _get_owned_event(self, db, artist_id, event_id):
        event = await self._get_event(db, event_id)
        if event.artist_id != artist_id:
            raise HTTPException(403, "You do not own this event")
        return event

    @staticmethod
    def _recording_stream_path(
        event: LiveEvent,
    ) -> str:

        if not event.video_stream_id:
            raise HTTPException(
                status_code=409,
                detail=(
                    "The event has no recording "
                    "stream path"
                ),
            )

        return event.video_stream_id

live_service = LiveService()
