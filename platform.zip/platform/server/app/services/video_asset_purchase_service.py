import uuid

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.video_asset import (
    VideoAsset,
    VideoAssetStatus,
    VideoAssetVisibility,
)

from app.models.video_asset_entitlement import (
    VideoAssetEntitlement,
    VideoAssetEntitlementStatus,
    VideoAssetPurchase,
    VideoAssetPurchaseStatus,
)

from app.services.payment_provider import (
    payment_provider,
)


class VideoAssetPurchaseService:

    async def purchase(
        self,
        db: AsyncSession,
        asset_id: str,
        fan_id: str,
        idempotency_key: str,
    ) -> dict:

        asset_key = self._parse_asset_id(
            asset_id
        )

        existing_by_key = (
            await db.execute(
                select(VideoAssetPurchase)
                .where(
                    VideoAssetPurchase.idempotency_key
                    == idempotency_key
                )
            )
        ).scalar_one_or_none()

        if existing_by_key:
            if (
                existing_by_key.video_asset_id
                == asset_key
                and existing_by_key.fan_id
                == fan_id
            ):
                return await self._response(
                    db,
                    existing_by_key,
                )

            raise HTTPException(
                status_code=409,
                detail=(
                    "Idempotency key was already used "
                    "for a different video asset purchase"
                ),
            )

        asset = (
            await db.execute(
                select(VideoAsset)
                .where(
                    VideoAsset.id == asset_key
                )
                .with_for_update()
            )
        ).scalar_one_or_none()

        if not asset:
            raise HTTPException(
                status_code=404,
                detail="Video asset not found",
            )

        if asset.status != VideoAssetStatus.READY:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Video asset is not ready "
                    "for purchase"
                ),
            )

        if asset.visibility != VideoAssetVisibility.PPV:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Only PPV video assets "
                    "can be purchased"
                ),
            )

        if (
            asset.price_cents is None
            or asset.price_cents <= 0
        ):
            raise HTTPException(
                status_code=409,
                detail=(
                    "Video asset does not have "
                    "a valid purchase price"
                ),
            )

        existing_purchase = (
            await db.execute(
                select(VideoAssetPurchase)
                .where(
                    VideoAssetPurchase.video_asset_id
                    == asset.id,
                    VideoAssetPurchase.fan_id
                    == fan_id,
                )
            )
        ).scalar_one_or_none()

        if existing_purchase:
            return await self._response(
                db,
                existing_purchase,
            )

        payment = await payment_provider.charge(
            amount_cents=asset.price_cents,
            currency=asset.currency,
            idempotency_key=idempotency_key,
        )

        if not payment.paid:
            raise HTTPException(
                status_code=402,
                detail="Payment was not completed",
            )

        entitlement = VideoAssetEntitlement(
            video_asset_id=asset.id,
            fan_id=fan_id,
            source=f"{payment.provider}:PPV",
            status=(
                VideoAssetEntitlementStatus.ACTIVE
            ),
        )

        db.add(entitlement)
        await db.flush()

        purchase = VideoAssetPurchase(
            video_asset_id=asset.id,
            fan_id=fan_id,
            entitlement_id=entitlement.id,
            provider=payment.provider,
            provider_payment_id=payment.payment_id,
            idempotency_key=idempotency_key,
            amount_cents=asset.price_cents,
            currency=asset.currency,
            status=VideoAssetPurchaseStatus.PAID,
        )

        db.add(purchase)

        try:
            await db.commit()

        except IntegrityError:
            await db.rollback()

            concurrent_purchase = (
                await db.execute(
                    select(VideoAssetPurchase)
                    .where(
                        VideoAssetPurchase.video_asset_id
                        == asset_key,
                        VideoAssetPurchase.fan_id
                        == fan_id,
                    )
                )
            ).scalar_one_or_none()

            if concurrent_purchase:
                return await self._response(
                    db,
                    concurrent_purchase,
                )

            raise HTTPException(
                status_code=409,
                detail=(
                    "Video asset purchase was "
                    "processed concurrently"
                ),
            )

        await db.refresh(purchase)

        return await self._response(
            db,
            purchase,
        )

    async def get_entitlement(
        self,
        db: AsyncSession,
        asset_id: str,
        fan_id: str,
    ) -> VideoAssetEntitlement:

        asset_key = self._parse_asset_id(
            asset_id
        )

        entitlement = (
            await db.execute(
                select(VideoAssetEntitlement)
                .where(
                    VideoAssetEntitlement.video_asset_id
                    == asset_key,
                    VideoAssetEntitlement.fan_id
                    == fan_id,
                    VideoAssetEntitlement.status
                    == VideoAssetEntitlementStatus.ACTIVE,
                )
            )
        ).scalar_one_or_none()

        if not entitlement:
            raise HTTPException(
                status_code=403,
                detail=(
                    "A valid video asset entitlement "
                    "is required"
                ),
            )

        return entitlement

    async def list_for_fan(
        self,
        db: AsyncSession,
        fan_id: str,
    ) -> list[VideoAssetEntitlement]:

        result = await db.execute(
            select(VideoAssetEntitlement)
            .where(
                VideoAssetEntitlement.fan_id
                == fan_id
            )
            .order_by(
                VideoAssetEntitlement.created_at.desc()
            )
        )

        return list(
            result.scalars().all()
        )

    @staticmethod
    async def _response(
        db: AsyncSession,
        purchase: VideoAssetPurchase,
    ) -> dict:

        entitlement = await db.get(
            VideoAssetEntitlement,
            purchase.entitlement_id,
        )

        if not entitlement:
            raise HTTPException(
                status_code=500,
                detail=(
                    "Purchase entitlement "
                    "could not be found"
                ),
            )

        return {
            "purchase_id": purchase.id,
            "video_asset_id": (
                purchase.video_asset_id
            ),
            "fan_id": purchase.fan_id,
            "entitlement_id": entitlement.id,
            "provider": purchase.provider,
            "provider_payment_id": (
                purchase.provider_payment_id
            ),
            "amount_cents": purchase.amount_cents,
            "currency": purchase.currency,
            "status": purchase.status.value,
            "entitlement_status": (
                entitlement.status.value
            ),
            "created_at": purchase.created_at,
        }

    @staticmethod
    def _parse_asset_id(
        asset_id: str,
    ) -> uuid.UUID:

        try:
            return uuid.UUID(
                str(asset_id)
            )
        except ValueError:
            raise HTTPException(
                status_code=404,
                detail="Video asset not found",
            )


video_asset_purchase_service = (
    VideoAssetPurchaseService()
)