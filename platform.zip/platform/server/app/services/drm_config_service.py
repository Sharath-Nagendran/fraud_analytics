from datetime import datetime, timezone

from sqlalchemy import select

from app.core.config import settings
from app.models.drm_config import DrmConfig


class DrmConfigService:

    async def get_or_create(
        self,
        db,
    ) -> DrmConfig:
        row = (
            await db.execute(
                select(DrmConfig)
                .order_by(
                    DrmConfig.updated_at.desc()
                )
                .limit(1)
            )
        ).scalars().first()

        if row:
            return row

        row = DrmConfig(
            enabled=settings.drm_enabled,
            provider=(
                settings.drm_provider
                if settings.drm_provider
                else "mock"
            ),
            watermark_enabled=True,
            widevine_url=(
                settings.widevine_license_url
                or None
            ),
            fairplay_url=(
                settings.fairplay_license_url
                or None
            ),
            playready_url=(
                settings.playready_license_url
                or None
            ),
            updated_at=datetime.now(
                timezone.utc
            ),
        )

        db.add(row)

        await db.commit()
        await db.refresh(row)

        return row

    async def get(
        self,
        db,
    ) -> DrmConfig:
        return await self.get_or_create(
            db
        )

    async def update(
        self,
        db,
        payload,
    ) -> DrmConfig:
        row = await self.get_or_create(
            db
        )

        provider = (
            payload.provider
            .strip()
            .lower()
        )

        if provider not in {
            "mock",
            "real",
        }:
            raise ValueError(
                "DRM provider must be "
                "either 'mock' or 'real'"
            )

        #
        # Validate real-provider configuration only
        # when real DRM is actually enabled.
        #
        if (
            payload.enabled
            and provider == "real"
        ):
            missing: list[str] = []

            if not payload.widevine_url:
                missing.append(
                    "widevine_url"
                )

            if not payload.fairplay_url:
                missing.append(
                    "fairplay_url"
                )

            if not payload.playready_url:
                missing.append(
                    "playready_url"
                )

            if missing:
                raise ValueError(
                    "Real DRM requires: "
                    + ", ".join(missing)
                )

        row.enabled = payload.enabled
        row.provider = provider

        row.watermark_enabled = (
            payload.watermark_enabled
        )

        row.widevine_url = (
            payload.widevine_url
        )

        row.fairplay_url = (
            payload.fairplay_url
        )

        row.playready_url = (
            payload.playready_url
        )

        row.updated_at = datetime.now(
            timezone.utc
        )

        await db.commit()
        await db.refresh(row)

        return row


drm_config_service = DrmConfigService()