import uuid
from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entitlement import Entitlement, EntitlementStatus
from app.models.live_event import LiveEvent, LiveEventStatus
from app.models.ticket import TicketPurchase, TicketStatus
from app.models.ticket_order import TicketOrder, TicketOrderItem, TicketOrderStatus, TicketOrderType
from app.models.ticket_ownership import TicketOwnership, TicketOwnershipStatus
from app.services.payment_provider import payment_provider


class TicketOrderService:
    async def create(self, db: AsyncSession, request) -> dict:
        existing = (await db.execute(select(TicketOrder).where(
            TicketOrder.idempotency_key == request.idempotency_key
        ))).scalar_one_or_none()
        if existing:
            if (existing.event_id == request.event_id and
                    existing.buyer_fan_id == request.buyer_fan_id and
                    existing.quantity == request.quantity and
                    existing.purchase_type == request.purchase_type):
                return await self._response(db, existing)
            raise HTTPException(409, "Idempotency key already used for a different ticket order")

        event = (await db.execute(select(LiveEvent).where(
            LiveEvent.id == request.event_id
        ).with_for_update())).scalar_one_or_none()
        if not event or event.status == LiveEventStatus.CANCELLED:
            raise HTTPException(409, "Event is not available for purchase")

        if request.purchase_type == TicketOrderType.REPLAY:
            if event.status != LiveEventStatus.ARCHIVED or not event.mux_vod_playback_id:
                raise HTTPException(409, "Replay purchase is available only after the replay is ready")
        elif event.status in (LiveEventStatus.ENDED, LiveEventStatus.ARCHIVED):
            raise HTTPException(409, "Event is not available for live-event ticket purchase")

        sold = (await db.scalar(select(func.count()).select_from(TicketPurchase).where(
            TicketPurchase.event_id == event.id, TicketPurchase.status == TicketStatus.PAID
        ))) or 0
        if request.purchase_type == TicketOrderType.LIVE_EVENT and event.capacity is not None and sold + request.quantity > event.capacity:
            raise HTTPException(409, f"Only {max(event.capacity - sold, 0)} ticket(s) remain")

        total = event.ticket_price_cents * request.quantity
        result = await payment_provider.charge(
            amount_cents=total, currency=event.currency, idempotency_key=request.idempotency_key
        )
        if not result.paid:
            raise HTTPException(402, "Payment was not completed")

        order = TicketOrder(
            event_id=event.id, buyer_fan_id=request.buyer_fan_id,
            quantity=request.quantity, unit_amount_cents=event.ticket_price_cents,
            total_amount_cents=total, currency=event.currency, provider=result.provider,
            provider_payment_id=result.payment_id, idempotency_key=request.idempotency_key,
            status=TicketOrderStatus.PAID, purchase_type=request.purchase_type,
        )
        db.add(order)
        await db.flush()

        source = f"{result.provider}:{request.purchase_type.value}"
        for line_number in range(1, request.quantity + 1):
            entitlement = Entitlement(
                fan_id=request.buyer_fan_id, event_id=event.id,
                source=source, status=EntitlementStatus.ACTIVE,
            )
            db.add(entitlement)
            await db.flush()
            ticket = TicketPurchase(
                event_id=event.id, fan_id=request.buyer_fan_id,
                entitlement_id=entitlement.id, provider=result.provider,
                provider_payment_id=f"{result.payment_id}:ticket:{line_number}",
                amount_cents=event.ticket_price_cents, currency=event.currency,
                status=TicketStatus.PAID,
            )
            db.add(ticket)
            await db.flush()
            db.add(TicketOrderItem(order_id=order.id, ticket_id=ticket.id, line_number=line_number))
            db.add(TicketOwnership(ticket_id=ticket.id, owner_fan_id=request.buyer_fan_id,
                                   status=TicketOwnershipStatus.ACTIVE))
        try:
            await db.commit()
        except IntegrityError:
            await db.rollback()
            existing = (await db.execute(select(TicketOrder).where(
                TicketOrder.idempotency_key == request.idempotency_key
            ))).scalar_one_or_none()
            if existing:
                return await self._response(db, existing)
            raise HTTPException(409, "Ticket order was processed concurrently")
        await db.refresh(order)
        return await self._response(db, order)

    async def get(self, db: AsyncSession, order_id: str, buyer_fan_id: str) -> dict:
        try:
            key = uuid.UUID(order_id)
        except ValueError:
            raise HTTPException(404, "Ticket order not found")
        order = await db.get(TicketOrder, key)
        if not order or order.buyer_fan_id != buyer_fan_id:
            raise HTTPException(404, "Ticket order not found")
        return await self._response(db, order)

    async def list_for_buyer(self, db: AsyncSession, buyer_fan_id: str) -> list[dict]:
        orders = (await db.execute(select(TicketOrder).where(
            TicketOrder.buyer_fan_id == buyer_fan_id
        ).order_by(TicketOrder.created_at.desc()))).scalars().all()
        return [await self._response(db, order) for order in orders]

    @staticmethod
    async def _response(db: AsyncSession, order: TicketOrder) -> dict:
        rows = (await db.execute(select(TicketOrderItem, TicketPurchase, TicketOwnership)
            .join(TicketPurchase, TicketPurchase.id == TicketOrderItem.ticket_id)
            .join(TicketOwnership, TicketOwnership.ticket_id == TicketPurchase.id)
            .where(TicketOrderItem.order_id == order.id)
            .order_by(TicketOrderItem.line_number))).all()
        return {
            "order_id": order.id, "event_id": order.event_id,
            "buyer_fan_id": order.buyer_fan_id, "quantity": order.quantity,
            "unit_amount_cents": order.unit_amount_cents,
            "total_amount_cents": order.total_amount_cents,
            "currency": order.currency, "provider": order.provider,
            "provider_payment_id": order.provider_payment_id,
            "status": order.status.value, "purchase_type": order.purchase_type.value,
            "created_at": order.created_at,
            "tickets": [{"ticket_id": t.id, "entitlement_id": t.entitlement_id,
                         "owner_fan_id": o.owner_fan_id, "line_number": i.line_number}
                        for i, t, o in rows],
        }


ticket_order_service = TicketOrderService()
