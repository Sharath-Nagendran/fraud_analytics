from sqlalchemy import func, select
from app.models.live_event import LiveEvent, LiveEventStatus
from app.models.ticket import TicketPurchase, TicketStatus
from app.services.session_registry import session_registry
class MetricsService:
  counters={"issued":0,"denied":0}
  async def platform(self,db):
    total=(await db.scalar(select(func.count()).select_from(LiveEvent))) or 0
    live=(await db.scalar(select(func.count()).where(LiveEvent.status==LiveEventStatus.LIVE))) or 0
    arch=(await db.scalar(select(func.count()).where(LiveEvent.status==LiveEventStatus.ARCHIVED))) or 0
    sold=(await db.scalar(select(func.count()).where(TicketPurchase.status==TicketStatus.PAID))) or 0
    refunded=(await db.scalar(select(func.count()).where(TicketPurchase.status==TicketStatus.REFUNDED))) or 0
    active=sum(len(v) for v in getattr(session_registry,'_sessions',{}).values())
    return dict(events_total=total,events_live=live,events_archived=arch,tickets_sold=sold,tickets_refunded=refunded,active_sessions=active,playback_tokens_issued=self.counters['issued'],playback_tokens_denied=self.counters['denied'])
metrics_service=MetricsService()
