﻿from datetime import datetime, timezone
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entitlement import Entitlement, EntitlementStatus
from app.models.live_event import LiveEvent, LiveEventStatus
from app.models.ticket import ProcessedPaymentEvent, TicketPurchase, TicketStatus, ProcessedPurchaseRequest
from app.services.payment_provider import payment_provider
from app.services.session_registry import session_registry

class TicketService:
    async def purchase(self, db: AsyncSession, request):
        processed = await db.get(
            ProcessedPurchaseRequest,
            request.idempotency_key
        )

        if processed:
            ticket = await db.get(
                TicketPurchase,
                processed.ticket_id
            )

            if (
                    processed.event_id == request.event_id
                    and
                    processed.fan_id == request.fan_id
            ):
                return self._response(
                    ticket,
                    "ACTIVE"
                    if ticket.status == TicketStatus.PAID
                    else "REVOKED"
                )

            raise HTTPException(
                409,
                "Idempotency key already used for a different purchase"
            )
        event = await db.get(
            LiveEvent,
            request.event_id
        )

        if not event or event.status in (
                LiveEventStatus.CANCELLED,
                LiveEventStatus.ENDED
        ):
            raise HTTPException(
                409,
                "Event is not available for ticket purchase"
            )

        existing = (await db.execute(select(TicketPurchase).where(
            TicketPurchase.event_id == request.event_id, TicketPurchase.fan_id == request.fan_id
        ))).scalar_one_or_none()
        if existing:
            return self._response(existing, "ACTIVE" if existing.status == TicketStatus.PAID else "REVOKED")
        result = await payment_provider.charge(amount_cents=event.ticket_price_cents, currency=event.currency,
                                               idempotency_key=request.idempotency_key)
        if not result.paid:
            raise HTTPException(402, "Payment was not completed")
        entitlement = Entitlement(fan_id=request.fan_id, event_id=event.id, source=result.provider,
                                  status=EntitlementStatus.ACTIVE)
        db.add(entitlement)
        await db.flush()
        ticket = TicketPurchase(
            event_id=event.id,
            fan_id=request.fan_id,
            entitlement_id=entitlement.id,
            provider=result.provider,
            provider_payment_id=result.payment_id,
            amount_cents=event.ticket_price_cents,
            currency=event.currency,
            status=TicketStatus.PAID
        )

        db.add(ticket)

        # IMPORTANT
        await db.flush()
        print("ticket.id =", ticket.id)
        db.add(
            ProcessedPurchaseRequest(
                idempotency_key=request.idempotency_key,
                ticket_id=ticket.id,
                event_id=ticket.event_id,
                fan_id=ticket.fan_id,
            )
        )

        try:
            await db.commit()
        except IntegrityError:
            await db.rollback()
            existing = (await db.execute(select(TicketPurchase).where(
                TicketPurchase.event_id == request.event_id, TicketPurchase.fan_id == request.fan_id
            ))).scalar_one_or_none()
            if existing: return self._response(existing, "ACTIVE" if existing.status == TicketStatus.PAID else "REVOKED")
            raise
        await db.refresh(ticket)
        return self._response(ticket, "ACTIVE")

    async def refund(self, db: AsyncSession, request):
        event_key = f"refund:{request.idempotency_key}"
        if await db.get(ProcessedPaymentEvent, event_key):
            ticket = (await db.execute(select(TicketPurchase).where(
                TicketPurchase.provider_payment_id == request.payment_id))).scalar_one_or_none()
            if not ticket: raise HTTPException(404, "Ticket not found")
            return self._response(ticket, "REVOKED")
        ticket = (await db.execute(select(TicketPurchase).where(
            TicketPurchase.provider_payment_id == request.payment_id))).scalar_one_or_none()
        if not ticket: raise HTTPException(404, "Ticket not found")
        if ticket.status == TicketStatus.REFUNDED:
            return self._response(ticket, "REVOKED")
        if not await payment_provider.refund(payment_id=request.payment_id, idempotency_key=request.idempotency_key):
            raise HTTPException(502, "Payment provider did not confirm the refund")
        entitlement = await db.get(Entitlement, ticket.entitlement_id)
        if entitlement:
            entitlement.status = EntitlementStatus.REVOKED
            from app.services.drm_lifecycle_service import (drm_lifecycle_service)
            await drm_lifecycle_service.revoke_entitlement(db,entitlement.id)
        ticket.status = TicketStatus.REFUNDED
        ticket.refunded_at = datetime.now(timezone.utc)
        db.add(ProcessedPaymentEvent(event_id=event_key, event_type="ticket.refunded"))
        await db.commit()
        if entitlement:
            await session_registry.release_all(
                str(entitlement.id)
            )

            from sqlalchemy import update

            from app.models.preissued_grant import (
                PreissuedGrantStatus,
                PreissuedPlaybackGrant,
            )

            await db.execute(
                update(PreissuedPlaybackGrant)
                .where(
                    PreissuedPlaybackGrant.event_id == ticket.event_id,
                    PreissuedPlaybackGrant.fan_id == ticket.fan_id,
                    PreissuedPlaybackGrant.status.in_([
                        PreissuedGrantStatus.READY,
                        PreissuedGrantStatus.CONSUMED,
                    ])
                )
                .values(
                    status=PreissuedGrantStatus.REVOKED
                )
            )

            await db.commit()
        return self._response(ticket, "REVOKED")

    @staticmethod
    def _response(ticket, entitlement_status):
        return {"ticket_id": ticket.id, "payment_id": ticket.provider_payment_id,
                "event_id": ticket.event_id, "fan_id": ticket.fan_id, "status": ticket.status.value,
                "entitlement_status": entitlement_status, "amount_cents": ticket.amount_cents,
                "currency": ticket.currency, "provider": ticket.provider}

ticket_service = TicketService()

