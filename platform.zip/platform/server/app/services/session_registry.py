import asyncio, time, uuid
from dataclasses import dataclass
from app.core.config import settings
@dataclass(frozen=True)
class SessionLease: session_id: str; expires_at_epoch: int
class SessionLimitExceeded(Exception): pass
class InMemorySessionRegistry:
    def __init__(self): self._sessions={}; self._lock=asyncio.Lock()
    async def acquire(self, entitlement_id, requested_session_id=None):
        now=int(time.time()); expiry=now+settings.playback_session_ttl_seconds
        async with self._lock:
            active=self._sessions.setdefault(entitlement_id,{})
            for sid,until in list(active.items()):
                if until<=now: active.pop(sid,None)
            if requested_session_id and requested_session_id in active:
                active[requested_session_id]=expiry; return SessionLease(requested_session_id,expiry)
            if len(active)>=settings.max_concurrent_playback_sessions: raise SessionLimitExceeded
            sid=requested_session_id or str(uuid.uuid4()); active[sid]=expiry; return SessionLease(sid,expiry)
    async def release(self, entitlement_id, session_id):
        async with self._lock: self._sessions.get(entitlement_id,{}).pop(session_id,None)
    async def release_all(self, entitlement_id):
        async with self._lock: self._sessions.pop(entitlement_id,None)
class RedisSessionRegistry:
    _LUA="""local k,n,e,c,s=KEYS[1],tonumber(ARGV[1]),tonumber(ARGV[2]),tonumber(ARGV[3]),ARGV[4]
redis.call('ZREMRANGEBYSCORE',k,'-inf',n)
if redis.call('ZSCORE',k,s) then redis.call('ZADD',k,e,s); redis.call('EXPIRE',k,e-n); return 1 end
if redis.call('ZCARD',k)>=c then return 0 end
redis.call('ZADD',k,e,s); redis.call('EXPIRE',k,e-n); return 1"""
    def __init__(self):
        from redis.asyncio import from_url
        self.redis=from_url(settings.redis_url,decode_responses=True)
    async def acquire(self, entitlement_id, requested_session_id=None):
        now=int(time.time()); expiry=now+settings.playback_session_ttl_seconds; sid=requested_session_id or str(uuid.uuid4())
        ok=await self.redis.eval(self._LUA,1,f"playback:sessions:{entitlement_id}",now,expiry,settings.max_concurrent_playback_sessions,sid)
        if not ok: raise SessionLimitExceeded
        return SessionLease(sid,expiry)
    async def release(self, entitlement_id, session_id): await self.redis.zrem(f"playback:sessions:{entitlement_id}",session_id)
    async def release_all(self, entitlement_id): await self.redis.delete(f"playback:sessions:{entitlement_id}")
session_registry=InMemorySessionRegistry() if settings.mux_stub_mode else RedisSessionRegistry()
