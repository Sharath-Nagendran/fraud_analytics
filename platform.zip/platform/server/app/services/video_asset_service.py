import uuid

from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings

from app.models.video_asset import (
    VideoAsset,
    VideoAssetStatus,
    VideoAssetVisibility,
)

from app.schemas.video_asset import (
    CreateVideoAssetRequest,
    UpdateVideoAssetRequest,
)


class VideoAssetService:

    async def create(
        self,
        db: AsyncSession,
        artist_id: str,
        payload: CreateVideoAssetRequest,
    ) -> VideoAsset:

        asset = VideoAsset(
            artist_id=artist_id,
            source_live_event_id=(
                payload.source_live_event_id
            ),
            title=payload.title,
            description=payload.description,
            asset_type=payload.asset_type,
            video_provider=settings.video_provider,
            video_asset_provider_id=None,
            storage_url=payload.storage_url,
            thumbnail_url=payload.thumbnail_url,
            duration_seconds=(
                payload.duration_seconds
            ),
            visibility=payload.visibility,
            price_cents=payload.price_cents,
            currency=payload.currency.upper(),
            status=VideoAssetStatus.PROCESSING,
        )

        db.add(asset)

        await db.commit()
        await db.refresh(asset)

        return asset

    async def get_public(
        self,
        db: AsyncSession,
        asset_id: str,
    ) -> VideoAsset:

        asset = await self._get_by_id(
            db=db,
            asset_id=asset_id,
        )

        if asset.status != VideoAssetStatus.READY:
            raise HTTPException(
                status_code=404,
                detail="Video asset not found",
            )

        return asset

    async def get_for_artist(
        self,
        db: AsyncSession,
        asset_id: str,
        artist_id: str,
    ) -> VideoAsset:

        asset = await self._get_by_id(
            db=db,
            asset_id=asset_id,
        )

        self._verify_artist_ownership(
            asset=asset,
            artist_id=artist_id,
        )

        return asset

    async def list_public_catalog(
        self,
        db: AsyncSession,
    ) -> list[VideoAsset]:

        result = await db.execute(
            select(VideoAsset)
            .where(
                VideoAsset.status
                == VideoAssetStatus.READY,
                VideoAsset.visibility.in_(
                    [
                        VideoAssetVisibility.PUBLIC,
                        VideoAssetVisibility.PPV,
                        VideoAssetVisibility.SUBSCRIPTION,
                    ]
                ),
            )
            .order_by(
                VideoAsset.published_at.desc().nullslast(),
                VideoAsset.created_at.desc(),
            )
        )

        return list(
            result.scalars().all()
        )

    async def list_for_artist(
        self,
        db: AsyncSession,
        artist_id: str,
    ) -> list[VideoAsset]:

        result = await db.execute(
            select(VideoAsset)
            .where(
                VideoAsset.artist_id == artist_id
            )
            .order_by(
                VideoAsset.created_at.desc()
            )
        )

        return list(
            result.scalars().all()
        )

    async def update(
        self,
        db: AsyncSession,
        asset_id: str,
        artist_id: str,
        payload: UpdateVideoAssetRequest,
    ) -> VideoAsset:

        asset = await self._get_by_id(
            db=db,
            asset_id=asset_id,
            lock=True,
        )

        self._verify_artist_ownership(
            asset=asset,
            artist_id=artist_id,
        )

        if asset.status == VideoAssetStatus.ARCHIVED:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Archived video assets "
                    "cannot be updated"
                ),
            )

        changes = payload.model_dump(
            exclude_unset=True
        )

        effective_visibility = changes.get(
            "visibility",
            asset.visibility,
        )

        effective_price = changes.get(
            "price_cents",
            asset.price_cents,
        )

        if (
            effective_visibility
            == VideoAssetVisibility.PPV
            and (
                effective_price is None
                or effective_price <= 0
            )
        ):
            raise HTTPException(
                status_code=422,
                detail=(
                    "price_cents must be greater "
                    "than zero for PPV video assets"
                ),
            )

        if (
            effective_visibility
            != VideoAssetVisibility.PPV
            and effective_price is not None
        ):
            raise HTTPException(
                status_code=422,
                detail=(
                    "price_cents is only supported "
                    "for PPV video assets"
                ),
            )

        if "currency" in changes:
            changes["currency"] = (
                changes["currency"].upper()
            )

        for field_name, value in changes.items():
            setattr(
                asset,
                field_name,
                value,
            )

        asset.updated_at = datetime.now(
            timezone.utc
        )

        await db.commit()
        await db.refresh(asset)

        return asset

    async def publish(
        self,
        db: AsyncSession,
        asset_id: str,
        artist_id: str,
    ) -> VideoAsset:

        asset = await self._get_by_id(
            db=db,
            asset_id=asset_id,
            lock=True,
        )

        self._verify_artist_ownership(
            asset=asset,
            artist_id=artist_id,
        )

        if asset.status == VideoAssetStatus.ARCHIVED:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Archived video assets "
                    "cannot be published"
                ),
            )

        if asset.status == VideoAssetStatus.FAILED:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Failed video assets "
                    "cannot be published"
                ),
            )

        if not asset.storage_url:
            raise HTTPException(
                status_code=409,
                detail=(
                    "A storage URL is required "
                    "before publishing"
                ),
            )

        if (
            asset.visibility
            == VideoAssetVisibility.PPV
            and (
                asset.price_cents is None
                or asset.price_cents <= 0
            )
        ):
            raise HTTPException(
                status_code=409,
                detail=(
                    "A positive price is required "
                    "before publishing a PPV asset"
                ),
            )

        now = datetime.now(timezone.utc)

        asset.status = VideoAssetStatus.READY
        asset.published_at = (
            asset.published_at or now
        )
        asset.updated_at = now

        await db.commit()
        await db.refresh(asset)

        return asset

    async def _get_by_id(
        self,
        db: AsyncSession,
        asset_id: str,
        lock: bool = False,
    ) -> VideoAsset:

        asset_key = self._parse_asset_id(
            asset_id
        )

        statement = select(
            VideoAsset
        ).where(
            VideoAsset.id == asset_key
        )

        if lock:
            statement = statement.with_for_update()

        asset = (
            await db.execute(statement)
        ).scalar_one_or_none()

        if not asset:
            raise HTTPException(
                status_code=404,
                detail="Video asset not found",
            )

        return asset

    @staticmethod
    def _verify_artist_ownership(
        asset: VideoAsset,
        artist_id: str,
    ) -> None:

        if asset.artist_id != artist_id:
            raise HTTPException(
                status_code=403,
                detail=(
                    "You do not own this "
                    "video asset"
                ),
            )

    @staticmethod
    def _parse_asset_id(
        asset_id: str,
    ) -> uuid.UUID:

        try:
            return uuid.UUID(
                str(asset_id)
            )

        except ValueError as exc:
            raise HTTPException(
                status_code=404,
                detail="Video asset not found",
            ) from exc


video_asset_service = VideoAssetService()