from datetime import timedelta
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entitlement import Entitlement, EntitlementStatus
from app.models.live_event import LiveEvent, LiveEventStatus
from app.models.ticket import TicketPurchase, TicketStatus
from app.models.ticket_tier import TicketTier
from app.services.payment_provider import payment_provider

class TicketTierService:
    async def create(self, db: AsyncSession, artist_id: str, event_id, payload):
        event = await db.get(LiveEvent, event_id)
        if not event or event.artist_id != artist_id:
            raise HTTPException(404, "Event not found")
        if event.status not in (LiveEventStatus.DRAFT, LiveEventStatus.SCHEDULED):
            raise HTTPException(409, "Ticket tiers can only be changed before the event goes live")
        tier = TicketTier(
            event_id=event.id, code=payload.code, name=payload.name,
            description=payload.description, price_cents=payload.price_cents,
            capacity=payload.capacity, early_access_seconds=payload.early_access_seconds,
            content_access=",".join(payload.content_access), is_active=True,
        )
        db.add(tier)
        try:
            await db.commit(); await db.refresh(tier)
        except IntegrityError:
            await db.rollback()
            raise HTTPException(409, "A tier with this code already exists for the event")
        return self._response(tier)

    async def list_for_event(self, db: AsyncSession, event_id):
        rows = (await db.execute(select(TicketTier).where(
            TicketTier.event_id == event_id, TicketTier.is_active.is_(True)
        ).order_by(TicketTier.price_cents))).scalars().all()
        return [self._response(row) for row in rows]

    async def purchase(self, db: AsyncSession, event_id, payload):
        event = await db.get(LiveEvent, event_id)
        tier = await db.get(TicketTier, payload.tier_id)
        if not event or not tier or tier.event_id != event.id or not tier.is_active:
            raise HTTPException(404, "Event or ticket tier not found")
        if event.status in (LiveEventStatus.CANCELLED, LiveEventStatus.ENDED):
            raise HTTPException(409, "Event is not available for this ticket tier")
        existing = (await db.execute(select(TicketPurchase).where(
            TicketPurchase.event_id == event.id, TicketPurchase.fan_id == payload.fan_id
        ))).scalar_one_or_none()
        if existing:
            return self._purchase_response(existing, tier)
        # Row lock makes capacity enforcement safe across concurrent purchases.
        tier = (await db.execute(select(TicketTier).where(TicketTier.id == tier.id).with_for_update())).scalar_one()
        if tier.capacity is not None and tier.sold_count >= tier.capacity:
            raise HTTPException(409, "Ticket tier is sold out")
        payment = await payment_provider.charge(
            amount_cents=tier.price_cents, currency=event.currency,
            idempotency_key=payload.idempotency_key,
        )
        if not payment.paid:
            raise HTTPException(402, "Payment was not completed")
        valid_from = event.scheduled_start - timedelta(seconds=tier.early_access_seconds)
        entitlement = Entitlement(
            fan_id=payload.fan_id, event_id=event.id, source=f"{payment.provider}:{tier.code}",
            status=EntitlementStatus.ACTIVE, valid_from=valid_from,
        )
        db.add(entitlement); await db.flush()
        ticket = TicketPurchase(
            event_id=event.id, fan_id=payload.fan_id, entitlement_id=entitlement.id,
            provider=payment.provider, provider_payment_id=payment.payment_id,
            amount_cents=tier.price_cents, currency=event.currency,
            status=TicketStatus.PAID, tier_id=tier.id,
        )
        tier.sold_count += 1
        db.add(ticket)
        try:
            await db.commit(); await db.refresh(ticket)
        except IntegrityError:
            await db.rollback()
            raise HTTPException(409, "Ticket purchase already exists")
        return self._purchase_response(ticket, tier)

    @staticmethod
    def _response(tier):
        return {
            "id": tier.id, "event_id": tier.event_id, "code": tier.code, "name": tier.name,
            "description": tier.description, "price_cents": tier.price_cents,
            "capacity": tier.capacity, "sold_count": tier.sold_count,
            "early_access_seconds": tier.early_access_seconds,
            "content_access": [x for x in tier.content_access.split(",") if x],
            "is_active": tier.is_active,
        }

    @staticmethod
    def _purchase_response(ticket, tier):
        return {
            "ticket_id": str(ticket.id), "payment_id": ticket.provider_payment_id,
            "event_id": str(ticket.event_id), "fan_id": ticket.fan_id,
            "status": ticket.status.value, "tier_id": str(tier.id), "tier_code": tier.code,
            "amount_cents": ticket.amount_cents, "currency": ticket.currency,
            "early_access_seconds": tier.early_access_seconds,
            "content_access": [x for x in tier.content_access.split(",") if x],
        }

ticket_tier_service = TicketTierService()
