import uuid
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.chat import (
    ChatParticipant,
    ChatParticipantStatus,
    ChatParticipantType,
    ChatRoom,
    ChatRoomStatus,
    ChatRoomType,
)
from app.models.entitlement import Entitlement, EntitlementStatus


class ChatWebSocketService:
    async def authorize(
        self,
        db: AsyncSession,
        room_id: str,
        participant_type: str,
        participant_id: str,
    ) -> tuple[ChatRoom, ChatParticipant]:
        room_key = self._uuid(room_id)

        room = await db.get(ChatRoom, room_key)
        if not room or room.status != ChatRoomStatus.OPEN:
            raise HTTPException(404, "Chat room not found")

        try:
            normalized_type = ChatParticipantType(
                participant_type.strip().upper()
            )
        except ValueError as exc:
            raise HTTPException(
                400,
                "participant_type must be ARTIST or FAN",
            ) from exc

        if normalized_type not in {
            ChatParticipantType.ARTIST,
            ChatParticipantType.FAN,
        }:
            raise HTTPException(
                400,
                "participant_type must be ARTIST or FAN",
            )

        if normalized_type == ChatParticipantType.ARTIST:
            if room.artist_id != participant_id:
                raise HTTPException(403, "Chat access denied")
        else:
            await self._authorize_fan(
                db,
                room,
                participant_id,
            )

        participant = (
            await db.execute(
                select(ChatParticipant).where(
                    ChatParticipant.chat_room_id == room.id,
                    ChatParticipant.participant_type == normalized_type,
                    ChatParticipant.participant_id == participant_id,
                )
            )
        ).scalar_one_or_none()

        if not participant:
            raise HTTPException(
                409,
                "Join the chat room before connecting",
            )

        if participant.status in {
            ChatParticipantStatus.SUSPENDED,
            ChatParticipantStatus.REMOVED,
        }:
            raise HTTPException(
                403,
                "Chat participation is not permitted",
            )

        return room, participant

    async def _authorize_fan(
        self,
        db: AsyncSession,
        room: ChatRoom,
        fan_id: str,
    ) -> None:
        if (
            room.room_type != ChatRoomType.LIVE_EVENT
            or not room.live_event_id
        ):
            raise HTTPException(
                409,
                "This chat room is not a live-event room",
            )

        now = datetime.now(timezone.utc)
        entitlement = (
            await db.execute(
                select(Entitlement).where(
                    Entitlement.event_id == room.live_event_id,
                    Entitlement.fan_id == fan_id,
                    Entitlement.status == EntitlementStatus.ACTIVE,
                    Entitlement.valid_from <= now,
                    or_(
                        Entitlement.valid_until.is_(None),
                        Entitlement.valid_until > now,
                    ),
                )
            )
        ).scalars().first()

        if not entitlement:
            raise HTTPException(
                403,
                "An active live-event entitlement is required for chat",
            )

    @staticmethod
    def _uuid(value: str) -> uuid.UUID:
        try:
            return uuid.UUID(str(value))
        except ValueError as exc:
            raise HTTPException(
                404,
                "Chat room not found",
            ) from exc


chat_websocket_service = ChatWebSocketService()
