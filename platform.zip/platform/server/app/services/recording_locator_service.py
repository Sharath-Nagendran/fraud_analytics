import uuid
from datetime import datetime
from urllib.parse import urljoin

import httpx
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.live_event import LiveEvent
from app.models.live_recording import (
    LiveRecording,
    LiveRecordingSpan,
    LiveRecordingSpanStatus,
)


class RecordingLocatorService:
    async def discover(
        self,
        db: AsyncSession,
        artist_id: str,
        event_id: str,
    ) -> dict:
        event_key = self._parse_uuid(event_id)

        event = await db.get(LiveEvent, event_key)
        if not event or event.artist_id != artist_id:
            raise HTTPException(404, "Event not found")

        if event.finalized_at is None:
            raise HTTPException(
                409,
                "The performance must be finalized before recordings are discovered",
            )

        recording = (
            await db.execute(
                select(LiveRecording).where(
                    LiveRecording.live_event_id == event.id
                )
            )
        ).scalar_one_or_none()

        if not recording:
            raise HTTPException(
                409,
                "The finalized event has no recording lifecycle record",
            )

        entries = await self._list_mediamtx_spans(recording.stream_path)

        discovered = 0
        existing = 0

        for entry in entries:
            started_at = self._parse_start(entry)
            duration_milliseconds = self._duration_milliseconds(entry)
            source_url = self._source_url(entry)

            prior = (
                await db.execute(
                    select(LiveRecordingSpan).where(
                        LiveRecordingSpan.live_recording_id == recording.id,
                        LiveRecordingSpan.started_at == started_at,
                    )
                )
            ).scalar_one_or_none()

            if prior:
                existing += 1
                continue

            db.add(
                LiveRecordingSpan(
                    live_recording_id=recording.id,
                    source_url=source_url,
                    started_at=started_at,
                    duration_milliseconds=duration_milliseconds,
                    status=LiveRecordingSpanStatus.DISCOVERED,
                )
            )
            discovered += 1

        try:
            await db.commit()
        except IntegrityError:
            await db.rollback()
            return await self._summary(db, recording, len(entries))

        return await self._summary(
            db,
            recording,
            len(entries),
            discovered=discovered,
            existing=existing,
        )

    async def _list_mediamtx_spans(self, stream_path: str) -> list[dict]:
        base_url = settings.selfhosted_playback_api_base_url.rstrip("/")
        list_url = f"{base_url}/list"

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(
                    list_url,
                    params={"path": stream_path},
                )
        except httpx.RequestError as exc:
            raise HTTPException(
                503,
                "MediaMTX playback API is unavailable",
            ) from exc

        if response.status_code == 404:
            return []

        if not response.is_success:
            raise HTTPException(
                502,
                f"MediaMTX recording discovery failed with status {response.status_code}",
            )

        payload = response.json()
        if not isinstance(payload, list):
            raise HTTPException(
                502,
                "MediaMTX recording discovery returned an invalid response",
            )

        return payload

    async def _summary(
        self,
        db: AsyncSession,
        recording: LiveRecording,
        provider_span_count: int,
        discovered: int = 0,
        existing: int = 0,
    ) -> dict:
        spans = (
            await db.execute(
                select(LiveRecordingSpan)
                .where(LiveRecordingSpan.live_recording_id == recording.id)
                .order_by(LiveRecordingSpan.started_at.asc())
            )
        ).scalars().all()

        return {
            "recording_id": recording.id,
            "event_id": recording.live_event_id,
            "stream_path": recording.stream_path,
            "recording_status": recording.status.value,
            "provider_span_count": provider_span_count,
            "discovered": discovered,
            "existing": existing,
            "total_persisted": len(spans),
            "spans": spans,
        }

    def _source_url(self, entry: dict) -> str:
        value = entry.get("url")
        if not isinstance(value, str) or not value.strip():
            raise HTTPException(502, "MediaMTX recording span has no URL")

        return urljoin(
            f"{settings.selfhosted_playback_api_base_url.rstrip('/')}/",
            value,
        )

    @staticmethod
    def _parse_start(entry: dict) -> datetime:
        value = entry.get("start")
        if not isinstance(value, str):
            raise HTTPException(502, "MediaMTX recording span has no start time")

        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as exc:
            raise HTTPException(502, "MediaMTX recording span has an invalid start time") from exc

        if parsed.tzinfo is None:
            raise HTTPException(502, "MediaMTX recording span start time has no timezone")

        return parsed

    @staticmethod
    def _duration_milliseconds(entry: dict) -> int:
        value = entry.get("duration")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise HTTPException(502, "MediaMTX recording span has an invalid duration")

        milliseconds = round(float(value) * 1000)
        if milliseconds <= 0:
            raise HTTPException(502, "MediaMTX recording span duration must be positive")

        return milliseconds

    @staticmethod
    def _parse_uuid(value: str) -> uuid.UUID:
        try:
            return uuid.UUID(str(value))
        except ValueError as exc:
            raise HTTPException(404, "Event not found") from exc


recording_locator_service = RecordingLocatorService()