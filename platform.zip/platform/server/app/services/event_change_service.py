import json,uuid
from datetime import datetime,timezone
from fastapi import HTTPException
from sqlalchemy import func,select,update
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entitlement import Entitlement,EntitlementStatus
from app.models.event_change import DeliveryStatus,EventNotification,EventRefundJob,RefundJobStatus
from app.models.live_event import LiveEvent,LiveEventStatus
from app.models.preissued_grant import PreissuedGrantStatus,PreissuedPlaybackGrant
from app.models.ticket import TicketPurchase,TicketStatus
from app.models.ticket_tier import TicketTier
from app.services.payment_provider import payment_provider
from app.services.session_registry import session_registry

class EventChangeService:
    async def reschedule(self,db,artist_id,event_id,new_start):
        event=await self._owned_scheduled(db,artist_id,event_id)
        old_start=event.scheduled_start;event.scheduled_start=new_start
        tickets=(await db.execute(select(TicketPurchase).where(TicketPurchase.event_id==event.id,TicketPurchase.status==TicketStatus.PAID))).scalars().all()
        for t in tickets:
            early=0
            if t.tier_id:
                tier=await db.get(TicketTier,t.tier_id);early=tier.early_access_seconds if tier else 0
            entitlement=await db.get(Entitlement,t.entitlement_id)
            if entitlement: entitlement.valid_from=new_start-__import__('datetime').timedelta(seconds=early)
            db.add(EventNotification(event_id=event.id,fan_id=t.fan_id,kind="EVENT_RESCHEDULED",payload=json.dumps({"old_start":old_start.isoformat(),"new_start":new_start.isoformat()})))
        revoked=(await db.execute(update(PreissuedPlaybackGrant).where(PreissuedPlaybackGrant.event_id==event.id,PreissuedPlaybackGrant.status==PreissuedGrantStatus.READY).values(status=PreissuedGrantStatus.REVOKED))).rowcount or 0
        await db.commit();await db.refresh(event)
        return event,len(tickets),revoked
    async def cancel(self,db,artist_id,event_id):
        event=await self._owned_scheduled(db,artist_id,event_id);event.status=LiveEventStatus.CANCELLED
        tickets=(await db.execute(select(TicketPurchase).where(TicketPurchase.event_id==event.id,TicketPurchase.status==TicketStatus.PAID))).scalars().all()
        revoked_ent=0
        for t in tickets:
            ent=await db.get(Entitlement,t.entitlement_id)
            if ent and ent.status==EntitlementStatus.ACTIVE:
                ent.status=EntitlementStatus.REVOKED;revoked_ent+=1
            db.add(EventNotification(event_id=event.id,fan_id=t.fan_id,kind="EVENT_CANCELLED",payload=json.dumps({"event_id":str(event.id),"title":event.title})))
            db.add(EventRefundJob(event_id=event.id,ticket_id=t.id,provider_payment_id=t.provider_payment_id,idempotency_key=f"event-cancel:{event.id}:{t.id}"))
        revoked_grants=(await db.execute(update(PreissuedPlaybackGrant).where(PreissuedPlaybackGrant.event_id==event.id,PreissuedPlaybackGrant.status==PreissuedGrantStatus.READY).values(status=PreissuedGrantStatus.REVOKED))).rowcount or 0
        await db.commit()
        for t in tickets:
            if t.entitlement_id: await session_registry.release_all(str(t.entitlement_id))
        return {"event_id":event.id,"status":event.status.value,"notifications_queued":len(tickets),"refund_jobs_queued":len(tickets),"entitlements_revoked":revoked_ent,"preissued_grants_revoked":revoked_grants}
    async def dispatch(self,db,batch_size):
        jobs=(await db.execute(select(EventRefundJob).where(EventRefundJob.status==RefundJobStatus.PENDING).order_by(EventRefundJob.created_at).limit(batch_size).with_for_update(skip_locked=True))).scalars().all();ok=bad=0
        for job in jobs:
            try:
                confirmed=await payment_provider.refund(payment_id=job.provider_payment_id,idempotency_key=job.idempotency_key)
                if not confirmed: raise RuntimeError("refund not confirmed")
                ticket=await db.get(TicketPurchase,job.ticket_id);ticket.status=TicketStatus.REFUNDED;ticket.refunded_at=datetime.now(timezone.utc)
                job.status=RefundJobStatus.COMPLETED;job.completed_at=datetime.now(timezone.utc);ok+=1
            except Exception as exc:
                job.status=RefundJobStatus.FAILED;job.error=str(exc)[:1000];bad+=1
        notes=(await db.execute(select(EventNotification).where(EventNotification.status==DeliveryStatus.PENDING).order_by(EventNotification.created_at).limit(batch_size).with_for_update(skip_locked=True))).scalars().all()
        for note in notes: note.status=DeliveryStatus.SENT;note.sent_at=datetime.now(timezone.utc)
        await db.commit();return {"refund_jobs_completed":ok,"refund_jobs_failed":bad,"notifications_sent":len(notes)}
    async def status(self,db,event_id):
        try:key=uuid.UUID(event_id)
        except ValueError:raise HTTPException(404,"Event not found")
        async def count(model,*conds):return (await db.scalar(select(func.count()).select_from(model).where(*conds))) or 0
        return {"event_id":key,"notifications_pending":await count(EventNotification,EventNotification.event_id==key,EventNotification.status==DeliveryStatus.PENDING),"notifications_sent":await count(EventNotification,EventNotification.event_id==key,EventNotification.status==DeliveryStatus.SENT),"refunds_pending":await count(EventRefundJob,EventRefundJob.event_id==key,EventRefundJob.status==RefundJobStatus.PENDING),"refunds_completed":await count(EventRefundJob,EventRefundJob.event_id==key,EventRefundJob.status==RefundJobStatus.COMPLETED),"refunds_failed":await count(EventRefundJob,EventRefundJob.event_id==key,EventRefundJob.status==RefundJobStatus.FAILED)}
    @staticmethod
    async def _owned_scheduled(db,artist_id,event_id):
        try:key=uuid.UUID(str(event_id))
        except ValueError:raise HTTPException(404,"Event not found")
        event=await db.get(LiveEvent,key)
        if not event or event.artist_id!=artist_id:raise HTTPException(404,"Event not found")
        if event.status!=LiveEventStatus.SCHEDULED:raise HTTPException(409,"Only a scheduled event can be changed")
        return event
event_change_service=EventChangeService()
