from datetime import (
    datetime,
    timezone
)

from sqlalchemy import update

from app.models.drm_session import (
    DrmSession,
    DrmSessionStatus
)


class DrmLifecycleService:
    async def revoke_entitlement(self, db, entitlement_id):
        await db.execute(
            update(DrmSession)
            .where(DrmSession.entitlement_id==entitlement_id)
            .values(status=DrmSessionStatus.REVOKED)
        )
        await db.commit()
    async def expire_sessions(self, db):
        now = datetime.now(timezone.utc)
        result = await db.execute(
                update(DrmSession)
                .where(DrmSession.status==DrmSessionStatus.ACTIVE, DrmSession.expires_at < now)
                .values(status=DrmSessionStatus.EXPIRED)
            )
        await db.commit()
        return {
            "expired":
            result.rowcount
        }


drm_lifecycle_service = (
    DrmLifecycleService()
)