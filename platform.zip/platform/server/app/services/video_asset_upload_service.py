import os
import uuid
from pathlib import Path

from fastapi import HTTPException, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.video_asset import (
    VideoAsset,
    VideoAssetType,
    VideoAssetVisibility,
)
from app.services.video_asset_ingestion_service import (
    VideoAssetIngestionRequest,
    video_asset_ingestion_service,
)


class VideoAssetUploadService:
    _ALLOWED_CONTENT_TYPES = {
        "video/mp4",
        "application/mp4",
        "application/octet-stream",
    }

    async def upload(
        self,
        db: AsyncSession,
        artist_id: str,
        file: UploadFile,
        title: str,
        description: str | None,
        visibility: VideoAssetVisibility,
        price_cents: int | None,
        currency: str,
    ) -> VideoAsset:
        normalized_title = title.strip()
        normalized_currency = currency.strip().upper()

        self._validate_metadata(
            title=normalized_title,
            visibility=visibility,
            price_cents=price_cents,
            currency=normalized_currency,
        )

        original_name = Path(file.filename or "upload.mp4").name
        extension = Path(original_name).suffix.lower()
        content_type = (file.content_type or "").lower().strip()

        if extension != ".mp4":
            raise HTTPException(
                status_code=415,
                detail="Only MP4 uploads are currently supported",
            )

        if content_type and content_type not in self._ALLOWED_CONTENT_TYPES:
            raise HTTPException(
                status_code=415,
                detail=f"Unsupported upload content type: {content_type}",
            )

        upload_id = uuid.uuid4()
        temp_root = Path(settings.video_upload_temp_root).resolve()
        temp_root.mkdir(parents=True, exist_ok=True)
        temp_path = temp_root / f"{upload_id}.mp4.part"

        object_key = (
            f"artist-uploads/{artist_id}/"
            f"{upload_id}.mp4"
        )

        size_bytes = 0
        maximum_bytes = settings.video_upload_max_bytes

        try:
            with temp_path.open("wb") as output:
                while True:
                    chunk = await file.read(
                        settings.video_upload_chunk_bytes
                    )
                    if not chunk:
                        break

                    size_bytes += len(chunk)
                    if size_bytes > maximum_bytes:
                        raise HTTPException(
                            status_code=413,
                            detail=(
                                "Uploaded video exceeds the configured "
                                "maximum size"
                            ),
                        )

                    output.write(chunk)

            if size_bytes <= 0:
                raise HTTPException(
                    status_code=400,
                    detail="Uploaded video is empty",
                )

            self._validate_mp4_signature(temp_path)

            asset = await video_asset_ingestion_service.ingest(
                db=db,
                request=VideoAssetIngestionRequest(
                    artist_id=artist_id,
                    title=normalized_title,
                    description=(
                        description.strip()
                        if description and description.strip()
                        else None
                    ),
                    source_path=temp_path,
                    object_key=object_key,
                    asset_type=VideoAssetType.UPLOAD,
                    visibility=visibility,
                    price_cents=price_cents,
                    currency=normalized_currency,
                    content_type="video/mp4",
                    publish_immediately=True,
                ),
            )

            return asset

        finally:
            await file.close()
            if temp_path.exists():
                try:
                    os.remove(temp_path)
                except OSError:
                    pass

    @staticmethod
    def _validate_metadata(
        title: str,
        visibility: VideoAssetVisibility,
        price_cents: int | None,
        currency: str,
    ) -> None:
        if not title:
            raise HTTPException(422, "title is required")

        if len(title) > 300:
            raise HTTPException(422, "title cannot exceed 300 characters")

        if len(currency) != 3:
            raise HTTPException(422, "currency must contain exactly three characters")

        if visibility == VideoAssetVisibility.PPV:
            if price_cents is None or price_cents <= 0:
                raise HTTPException(
                    422,
                    "A positive price_cents value is required for PPV uploads",
                )
        elif price_cents is not None:
            raise HTTPException(
                422,
                "price_cents is only supported for PPV uploads",
            )

    @staticmethod
    def _validate_mp4_signature(path: Path) -> None:
        with path.open("rb") as source:
            header = source.read(32)

        if len(header) < 12 or b"ftyp" not in header[4:16]:
            raise HTTPException(
                status_code=415,
                detail="The uploaded file does not have a valid MP4 signature",
            )


video_asset_upload_service = VideoAssetUploadService()
