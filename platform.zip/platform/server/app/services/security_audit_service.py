import uuid
from fastapi import HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.live_event import LiveEvent
from app.schemas.live_event import LiveEventPublic

FORBIDDEN_PUBLIC_FIELDS = {
    "mux_live_stream_id",
    "mux_stream_key",
    "mux_playback_id",
    "mux_asset_id",
    "mux_vod_playback_id",
    "stream_key",
    "rtmp_ingest_url",
    "playback_url",
    "manifest_url",
    "download_url",
}

class SecurityAuditService:
    async def audit_event(self, db: AsyncSession, event_id: str) -> dict:
        try:
            key = uuid.UUID(event_id)
        except ValueError:
            raise HTTPException(404, "Event not found")

        event = await db.get(LiveEvent, key)
        if not event:
            raise HTTPException(404, "Event not found")

        public_fields = set(LiveEventPublic.model_json_schema().get("properties", {}).keys())
        violations = sorted(public_fields.intersection(FORBIDDEN_PUBLIC_FIELDS))

        signed_status = "MOCK_SIMULATED" if settings.mux_stub_mode else (
            "CONFIGURED" if settings.mux_signing_key_id and settings.mux_signing_private_key else "MISSING_CONFIGURATION"
        )

        if settings.mux_stub_mode:
            drm_status = "NOT_VERIFIABLE_IN_MOCK"
            encryption_status = "NOT_VERIFIABLE_IN_MOCK"
        elif settings.drm_enabled and settings.drm_configuration_id:
            drm_status = "CONFIGURED_REQUIRES_PROVIDER_QA"
            encryption_status = "PROVIDER_VERIFICATION_REQUIRED"
        else:
            drm_status = "NOT_CONFIGURED"
            encryption_status = "PROVIDER_VERIFICATION_REQUIRED"

        restriction_status = "NOT_CONFIGURED" if not settings.playback_restriction_id else "CONFIGURED"

        checks = [
            {
                "name": "signed_playback",
                "status": signed_status,
                "detail": "Playback access is issued through short-lived server-side tokens.",
            },
            {
                "name": "token_response_cache_control",
                "status": "CONFIGURED",
                "detail": "Playback and replay token responses are marked no-store and private.",
            },
            {
                "name": "public_api_media_exposure",
                "status": "PASS" if not violations else "FAIL",
                "detail": "Public event schema contains no media credential or direct playback URL fields." if not violations else "Forbidden fields exist in LiveEventPublic.",
            },
            {
                "name": "drm",
                "status": drm_status,
                "detail": "Widevine, FairPlay and PlayReady require real-provider configuration and device QA.",
            },
            {
                "name": "segment_encryption",
                "status": encryption_status,
                "detail": "Segment encryption cannot be verified against fabricated mock media.",
            },
            {
                "name": "playback_restrictions",
                "status": restriction_status,
                "detail": "Optional provider restriction ID for domain and user-agent controls.",
            },
            {
                "name": "drm_provider",

                "status":
                    "MOCK"
                    if not settings.drm_enabled
                    else "CONFIGURED",

                "detail":
                    settings.drm_provider
            },
        ]

        failing = {"FAIL", "MISSING_CONFIGURATION", "NOT_CONFIGURED"}
        overall = "ACTION_REQUIRED" if any(c["status"] in failing for c in checks) else (
            "MOCK_VALIDATED" if settings.mux_stub_mode else "READY_FOR_PROVIDER_QA"
        )

        return {
            "event_id": event.id,
            "mode": "mock" if settings.mux_stub_mode else "real",
            "overall_status": overall,
            "checks": checks,
            "public_schema_violations": violations,
        }

security_audit_service = SecurityAuditService()
