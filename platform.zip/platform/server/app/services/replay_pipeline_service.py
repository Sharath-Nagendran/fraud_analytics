import uuid

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.live_event import LiveEvent
from app.models.live_recording import LiveRecording
from app.services.recording_download_service import (recording_download_service,)
from app.services.recording_locator_service import (recording_locator_service,)
from app.services.replay_assembly_service import (replay_assembly_service,)
from app.schemas.live_recording import (RecordingDiscoveryResponse,RecordingDownloadResponse,ReplayAssemblyResponse,)

class ReplayPipelineService:
    async def process(
        self,
        db: AsyncSession,
        artist_id: str,
        event_id: str,
    ) -> dict:
        event_key = self._parse_uuid(event_id)

        event = await db.get(LiveEvent, event_key)
        if not event or event.artist_id != artist_id:
            raise HTTPException(404, "Event not found")

        if event.finalized_at is None:
            raise HTTPException(409,"The performance must be finalized before replay processing",)

        recording = (await db.execute(select(LiveRecording).where(LiveRecording.live_event_id == event.id))
        ).scalar_one_or_none()

        if not recording:
            raise HTTPException(409,"The finalized event has no recording lifecycle record",)

        discovery = await recording_locator_service.discover(db=db,artist_id=artist_id,event_id=event_id,)

        if discovery["total_persisted"] <= 0:
            raise HTTPException(409,"MediaMTX has no recording spans for this finalized event",)

        download = await recording_download_service.download(db=db,artist_id=artist_id,event_id=event_id,)

        if download["failed"] > 0:
            raise HTTPException(409,"One or more recording spans could not be downloaded",)

        assembly = await replay_assembly_service.assemble(db=db,artist_id=artist_id,event_id=event_id,)

        discovery_response = (RecordingDiscoveryResponse.model_validate(discovery))
        download_response = (RecordingDownloadResponse.model_validate(download))
        assembly_response = (ReplayAssemblyResponse.model_validate(assembly))

        return {
            "event_id": event.id,
            "recording_id": recording.id,
            "discovery": (discovery_response.model_dump(mode="json")),
            "download": (download_response.model_dump(mode="json")),
            "assembly": (assembly_response.model_dump(mode="json")),
        }


    @staticmethod
    def _parse_uuid(value: str) -> uuid.UUID:
        try:
            return uuid.UUID(str(value))
        except ValueError as exc:
            raise HTTPException(404, "Event not found") from exc


replay_pipeline_service = ReplayPipelineService()