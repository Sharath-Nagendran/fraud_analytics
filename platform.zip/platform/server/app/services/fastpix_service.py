import requests
from app.core.config import settings

class FastPixService:

    BASE_URL = "https://api.fastpix.com/v1"

    def __init__(self):
        self.auth = (
            settings.fastpix_token_id,
            settings.fastpix_secret_key
        )

    def create_live_stream(
        self,
        passthrough_id,
        options
    ):

        response = requests.post(
            f"{self.BASE_URL}/live/streams",
            auth=self.auth,
            json={
                "playbackSettings": {},
                "inputMediaSettings": {}
            },
            timeout=30
        )

        if not response.ok:
            raise RuntimeError(
                f"FastPix create stream failed: "
                f"{response.status_code} {response.text}"
            )

        data = response.json()["data"]

        playback_id = data["playbackIds"][0]["id"]

        return {
            "mux_live_stream_id":
                data["streamId"],

            "mux_stream_key":
                data["streamKey"],

            "mux_playback_id":
                playback_id,

            "rtmp_ingest_url":
                "rtmps://live.fastpix.com:443/live"
        }

    def complete_live_stream(
        self,
        stream_id
    ):
        pass

    def delete_live_stream(
        self,
        stream_id
    ):
        pass

    def get_asset_playback_id(
        self,
        asset_id
    ):
        return None