import asyncio
import uuid
from datetime import datetime, timezone
from pathlib import Path
import subprocess

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.live_event import LiveEvent
from app.models.live_recording import (LiveRecording,LiveRecordingSpan,LiveRecordingSpanStatus,LiveRecordingStatus,)
from app.models.video_asset import (VideoAsset,VideoAssetStatus,VideoAssetType,VideoAssetVisibility,)
from app.services.video_asset_ingestion_service import (VideoAssetIngestionRequest,video_asset_ingestion_service,)


class ReplayAssemblyService:
    async def assemble(self, db: AsyncSession, artist_id: str, event_id: str,) -> dict:
        event_key = self._parse_uuid(event_id)

        event = await db.get(LiveEvent, event_key)
        if not event or event.artist_id != artist_id:
            raise HTTPException(404, "Event not found")

        if event.finalized_at is None:
            raise HTTPException(
                409,
                "The performance must be finalized before replay assembly",
            )

        recording = (
            await db.execute(
                select(LiveRecording)
                .where(LiveRecording.live_event_id == event.id)
                .with_for_update()
            )
        ).scalar_one_or_none()

        if not recording:
            raise HTTPException(
                409,
                "The finalized event has no recording lifecycle record",
            )

        if recording.video_asset_id is not None:
            existing_asset = await db.get(VideoAsset, recording.video_asset_id)
            if existing_asset:
                return self._response(recording, existing_asset, reused=True)

        existing_asset = (
            await db.execute(
                select(VideoAsset)
                .where(
                    VideoAsset.asset_type == VideoAssetType.LIVE_RECORDING,
                    VideoAsset.source_live_event_id == event.id,
                )
                .order_by(VideoAsset.created_at.desc())
            )
        ).scalars().first()

        if existing_asset:
            recording.video_asset_id = existing_asset.id
            recording.storage_provider = existing_asset.storage_provider
            recording.storage_object_key = existing_asset.storage_object_key
            recording.status = LiveRecordingStatus.READY
            recording.finalized_at = recording.finalized_at or datetime.now(timezone.utc)
            recording.failure_reason = None
            recording.updated_at = datetime.now(timezone.utc)
            await db.commit()
            await db.refresh(recording)
            return self._response(recording, existing_asset, reused=True)

        spans = (
            await db.execute(
                select(LiveRecordingSpan)
                .where(LiveRecordingSpan.live_recording_id == recording.id)
                .order_by(LiveRecordingSpan.started_at.asc())
            )
        ).scalars().all()

        if not spans:
            raise HTTPException(409, "No recording spans have been discovered")

        invalid_spans = [
            span
            for span in spans
            if span.status not in {
                LiveRecordingSpanStatus.DOWNLOADED,
                LiveRecordingSpanStatus.MERGED,
            }
            or not span.local_path
            or not Path(span.local_path).is_file()
        ]

        if invalid_spans:
            raise HTTPException(
                409,
                "All recording spans must be downloaded before replay assembly",
            )

        work_directory = Path(settings.replay_work_root).resolve() / str(recording.id)
        work_directory.mkdir(parents=True, exist_ok=True)

        concat_file = work_directory / "concat.txt"
        output_file = work_directory / "replay.mp4"

        recording.status = LiveRecordingStatus.FINALIZING
        recording.failure_reason = None
        recording.updated_at = datetime.now(timezone.utc)
        await db.commit()

        try:
            self._write_concat_file(
                concat_file=concat_file,
                spans=spans,
            )

            if output_file.exists():
                output_file.unlink()

            await self._run_ffmpeg(
                concat_file=concat_file,
                output_file=output_file,
            )

            if not output_file.is_file() or output_file.stat().st_size <= 0:
                raise RuntimeError("FFmpeg did not produce a valid replay file")

            visibility = VideoAssetVisibility.PPV

            price_cents = event.ticket_price_cents

            asset = await video_asset_ingestion_service.ingest(
                db=db,
                request=VideoAssetIngestionRequest(
                    artist_id=event.artist_id,
                    title=f"{event.title} Replay",
                    description=event.description,
                    source_path=output_file,
                    object_key=(
                        f"live-recordings/{event.id}/replay.mp4"
                    ),
                    asset_type=VideoAssetType.LIVE_RECORDING,
                    source_live_event_id=event.id,
                    visibility=visibility,
                    price_cents=price_cents,
                    currency=event.currency,
                    content_type="video/mp4",
                    publish_immediately=settings.replay_auto_publish,
                ),
            )

            asset.status = VideoAssetStatus.READY

            if asset.published_at is None:
                asset.published_at = datetime.now(timezone.utc)

            asset.updated_at = datetime.now(timezone.utc)

            await db.commit()
            await db.refresh(asset)

            recording = await db.get(LiveRecording, recording.id)
            if not recording:
                raise RuntimeError("Live recording disappeared during replay assembly")

            recording.video_asset_id = asset.id
            recording.storage_provider = asset.storage_provider
            recording.storage_object_key = asset.storage_object_key
            recording.status = LiveRecordingStatus.READY
            recording.finalized_at = datetime.now(timezone.utc)
            recording.failure_reason = None
            recording.updated_at = datetime.now(timezone.utc)

            refreshed_spans = (
                await db.execute(
                    select(LiveRecordingSpan).where(
                        LiveRecordingSpan.live_recording_id == recording.id
                    )
                )
            ).scalars().all()

            for span in refreshed_spans:
                span.status = LiveRecordingSpanStatus.MERGED
                span.failure_reason = None

            await db.commit()
            await db.refresh(recording)
            await db.refresh(asset)

            return self._response(recording, asset, reused=False)

        except HTTPException:
            await self._mark_failed(db, recording.id, "Replay assembly failed")
            raise
        except Exception as exc:
            error_detail = (f"{type(exc).__name__}: {exc!r}")

            await self._mark_failed(db, recording.id, error_detail,)

            raise HTTPException(status_code=500, detail=("Replay assembly failed: "
                    f"{error_detail}"),) from exc

    async def _run_ffmpeg(self, concat_file: Path, output_file: Path,) -> None:

        command = [
            settings.ffmpeg_path,
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(concat_file),
            "-c",
            "copy",
            "-movflags",
            "+faststart",
            str(output_file),
        ]

        try:
            result = await asyncio.to_thread(
                subprocess.run,
                command,
                capture_output=True,
                text=True,
                timeout=(
                    settings
                    .replay_assembly_timeout_seconds
                ),
                check=False,
            )

        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(
                "FFmpeg replay assembly timed out"
            ) from exc

        except FileNotFoundError as exc:
            raise RuntimeError(
                "FFmpeg executable was not found at: "
                f"{settings.ffmpeg_path}"
            ) from exc

        except OSError as exc:
            raise RuntimeError(
                "FFmpeg could not be started: "
                f"{exc}"
            ) from exc

        if result.returncode != 0:
            detail = (
                result.stderr
                or result.stdout
                or "No FFmpeg error output"
            ).strip()

            raise RuntimeError(
                "FFmpeg exited with code "
                f"{result.returncode}: "
                f"{detail[:4000]}"
            )

    @staticmethod
    def _write_concat_file(
        concat_file: Path,
        spans: list[LiveRecordingSpan],
    ) -> None:
        lines: list[str] = []

        for span in spans:
            path = Path(span.local_path or "").resolve().as_posix()
            escaped = path.replace("'", "'\\''")
            lines.append(f"file '{escaped}'")

        concat_file.write_text(
            "\n".join(lines) + "\n",
            encoding="utf-8",
        )

    @staticmethod
    async def _mark_failed(
        db: AsyncSession,
        recording_id: uuid.UUID,
        reason: str,
    ) -> None:
        await db.rollback()
        recording = await db.get(LiveRecording, recording_id)
        if recording:
            recording.status = LiveRecordingStatus.FAILED
            recording.failure_reason = reason[:4000]
            recording.updated_at = datetime.now(timezone.utc)
            await db.commit()

    @staticmethod
    def _response(
        recording: LiveRecording,
        asset: VideoAsset,
        reused: bool,
    ) -> dict:
        return {
            "recording_id": recording.id,
            "event_id": recording.live_event_id,
            "recording_status": recording.status.value,
            "video_asset_id": asset.id,
            "video_asset_status": asset.status.value,
            "storage_provider": asset.storage_provider,
            "storage_object_key": asset.storage_object_key,
            "storage_url": asset.storage_url,
            "reused": reused,
        }

    @staticmethod
    def _parse_uuid(value: str) -> uuid.UUID:
        try:
            return uuid.UUID(str(value))
        except ValueError as exc:
            raise HTTPException(404, "Event not found") from exc


replay_assembly_service = ReplayAssemblyService()
