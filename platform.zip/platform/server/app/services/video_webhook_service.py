from sqlalchemy import select

from app.models.live_event import (
    LiveEvent,
    LiveEventStatus,
)


class VideoWebhookService:
    async def process_fastpix_event(
        self,
        db,
        payload: dict,
    ):
        """
        Simple lifecycle processor for FastPix events.

        Supported:
        - video.live_stream.active
        - video.live_stream.idle
        - video.media.ready
        """

        event_type = payload.get("type")

        data = payload.get("data", {})

        stream_id = data.get("streamId")

        if not stream_id:
            return {
                "processed": False,
                "reason": "missing streamId",
            }

        result = await db.execute(
            select(LiveEvent).where(
                LiveEvent.video_provider == "fastpix",
                LiveEvent.video_stream_id == stream_id,
            )
        )

        live_event = result.scalar_one_or_none()

        if not live_event:
            return {
                "processed": False,
                "reason": "event not found",
            }

        #
        # STREAM ACTIVE
        #
        if event_type == "video.live_stream.active":
            live_event.status = LiveEventStatus.LIVE

        #
        # STREAM IDLE
        #
        elif event_type == "video.live_stream.idle":
            live_event.status = LiveEventStatus.ENDED

        #
        # RECORDING READY
        #
        elif event_type == "video.media.ready":
            live_event.status = LiveEventStatus.ARCHIVED

        else:
            return {
                "processed": False,
                "reason": f"unsupported event {event_type}",
            }

        await db.commit()

        return {
            "processed": True,
            "event_id": str(live_event.id),
            "status": live_event.status.value,
            "event_type": event_type,
        }


video_webhook_service = VideoWebhookService()