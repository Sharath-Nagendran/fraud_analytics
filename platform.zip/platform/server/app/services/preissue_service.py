import uuid
from datetime import datetime, timezone
from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.entitlement import Entitlement, EntitlementStatus
from app.models.live_event import LiveEvent, LiveEventStatus
from app.models.preissued_grant import PreissuedGrantStatus, PreissuedPlaybackGrant
from app.services.playback_service import MockPlaybackTokenProvider, RealPlaybackTokenProvider
from app.services.session_registry import SessionLimitExceeded, session_registry

class PreissueService:
    async def run_for_event(self, db: AsyncSession, event_id: str, batch_size: int = 500) -> dict:
        event = await self._event(db, event_id)
        if event.status != LiveEventStatus.SCHEDULED:
            raise HTTPException(409, "Only a scheduled event can be pre-issued")
        if not event.mux_playback_id:
            raise HTTPException(409, "Playback is not available for this event")

        now = datetime.now(timezone.utc)
        seconds_until = int((event.scheduled_start - now).total_seconds())
        if seconds_until < 0 or seconds_until > settings.preissue_window_seconds:
            return self._result(event.id, 0, 0, 0, 0, 0, "OUTSIDE_WINDOW")

        entitlements = (
            await db.execute(
                select(Entitlement).where(
                    Entitlement.event_id == event.id,
                    Entitlement.status == EntitlementStatus.ACTIVE,
                )
                .order_by(Entitlement.created_at).limit(batch_size)
        )).scalars().all()

        provider = MockPlaybackTokenProvider() if settings.mux_stub_mode else RealPlaybackTokenProvider()
        created = refreshed = skipped = failed = 0

        for entitlement in entitlements:
            existing = (await db.execute(select(PreissuedPlaybackGrant).where(
                PreissuedPlaybackGrant.event_id == event.id,
                PreissuedPlaybackGrant.entitlement_id == entitlement.id,
            ))).scalar_one_or_none()

            if existing and existing.status == PreissuedGrantStatus.CONSUMED:
                skipped += 1
                continue
            if existing and existing.status == PreissuedGrantStatus.READY and existing.expires_at > now:
                skipped += 1
                continue

            try:
                session_id = existing.session_id if existing else str(uuid.uuid4())
                grant = provider.issue(event.mux_playback_id, session_id, settings.playback_token_ttl_seconds)
                if existing:
                    existing.session_id = session_id
                    existing.playback_id = event.mux_playback_id
                    existing.token = grant.token
                    existing.expires_at = grant.expires_at
                    existing.status = PreissuedGrantStatus.READY
                    existing.consumed_at = None
                    refreshed += 1
                else:
                    db.add(PreissuedPlaybackGrant(
                        event_id=event.id, entitlement_id=entitlement.id, fan_id=entitlement.fan_id,
                        session_id=session_id, playback_id=event.mux_playback_id,
                        token=grant.token, expires_at=grant.expires_at,
                        status=PreissuedGrantStatus.READY,
                    ))
                    created += 1
            except Exception:
                failed += 1

        try:
            await db.commit()
        except IntegrityError:
            await db.rollback()
            raise HTTPException(409, "Another pre-issuance worker processed this event concurrently")

        return self._result(event.id, len(entitlements), created, refreshed, skipped, failed, "COMPLETED")

    async def claim(self, db: AsyncSession, event_id: str, fan_id: str) -> dict | None:
        event = await self._event(db, event_id)
        now = datetime.now(timezone.utc)
        row = (await db.execute(
            select(PreissuedPlaybackGrant).where(
                PreissuedPlaybackGrant.event_id == event.id,
                PreissuedPlaybackGrant.fan_id == fan_id,
                PreissuedPlaybackGrant.status == PreissuedGrantStatus.READY,
                PreissuedPlaybackGrant.expires_at > now,
            ).with_for_update(skip_locked=True)
        )).scalar_one_or_none()
        if not row:
            return None

        entitlement = await db.get(Entitlement, row.entitlement_id)
        if not entitlement or entitlement.status != EntitlementStatus.ACTIVE:
            row.status = PreissuedGrantStatus.REVOKED
            await db.commit()
            return None

        if entitlement.valid_from and entitlement.valid_from > now:
            raise HTTPException(
                409,
                "Playback window has not opened yet"
            )

        try:
            await session_registry.acquire(str(entitlement.id), row.session_id)
        except SessionLimitExceeded:
            raise HTTPException(409, "Concurrent playback session limit reached")

        row.status = PreissuedGrantStatus.CONSUMED
        row.consumed_at = now
        await db.commit()
        return {
            "event_id": str(event.id), "playback_id": row.playback_id,
            "token": row.token, "expires_at": row.expires_at,
            "refresh_after_seconds": settings.playback_token_refresh_seconds,
            "session_id": row.session_id, "mode": "mock" if settings.mux_stub_mode else "real",
            "preissued": True,
        }

    async def status(self, db: AsyncSession, event_id: str) -> dict:
        event = await self._event(db, event_id)
        now = datetime.now(timezone.utc)
        await db.execute(
            PreissuedPlaybackGrant.__table__.update().where(
                PreissuedPlaybackGrant.event_id == event.id,
                PreissuedPlaybackGrant.status == PreissuedGrantStatus.READY,
                PreissuedPlaybackGrant.expires_at <= now,
            ).values(status=PreissuedGrantStatus.EXPIRED)
        )
        await db.commit()
        counts = dict((await db.execute(
            select(PreissuedPlaybackGrant.status, func.count()).where(
                PreissuedPlaybackGrant.event_id == event.id
            ).group_by(PreissuedPlaybackGrant.status)
        )).all())
        return {
            "event_id": event.id,
            "ready": counts.get(PreissuedGrantStatus.READY, 0),
            "consumed": counts.get(PreissuedGrantStatus.CONSUMED, 0),
            "expired": counts.get(PreissuedGrantStatus.EXPIRED, 0),
            "revoked": counts.get(PreissuedGrantStatus.REVOKED, 0),
        }

    async def revoke(self, db: AsyncSession, event_id: str, fan_id: str) -> None:
        event = await self._event(db, event_id)
        await db.execute(
            PreissuedPlaybackGrant.__table__.update().where(
                PreissuedPlaybackGrant.event_id == event.id,
                PreissuedPlaybackGrant.fan_id == fan_id,
                PreissuedPlaybackGrant.status == PreissuedGrantStatus.READY,
            ).values(status=PreissuedGrantStatus.REVOKED)
        )
        await db.commit()

    @staticmethod
    async def _event(db: AsyncSession, event_id: str) -> LiveEvent:
        try:
            key = uuid.UUID(event_id)
        except ValueError:
            raise HTTPException(404, "Event not found")
        event = await db.get(LiveEvent, key)
        if not event:
            raise HTTPException(404, "Event not found")
        return event

    @staticmethod
    def _result(event_id, eligible, created, refreshed, skipped, failed, status):
        return {"event_id": event_id, "eligible": eligible, "created": created,
                "refreshed": refreshed, "skipped": skipped, "failed": failed, "status": status}

preissue_service = PreissueService()
