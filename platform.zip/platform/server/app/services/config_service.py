"""
DB-backed runtime configuration: currencies + tunable settings.

Reads go through a small in-process snapshot cache (TTL from
SETTINGS_CACHE_TTL_SECONDS). Writes commit, write an audit row, and drop the
local cache immediately; other instances pick the change up within the TTL.
"""
import asyncio
import re
import time
from dataclasses import dataclass
from typing import Any

from fastapi import HTTPException
from sqlalchemy import exists, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.setting_registry import REGISTRY, SettingValidationError, get_def
from app.db.base import AsyncSessionLocal
from app.models.config import AppSetting, ConfigAuditLog, Currency
from app.models.live_event import LiveEvent

CODE_RE = re.compile(r"^[A-Z]{3}$")
SEED_HINT = "Run `alembic upgrade head` and then `python -m app.db.seed`."


class ConfigError(RuntimeError):
    """Required configuration is missing or invalid in the database."""


@dataclass(frozen=True)
class CurrencyInfo:
    code: str
    name: str
    minor_unit: int
    is_active: bool
    is_default: bool


@dataclass(frozen=True)
class _Snapshot:
    settings: dict[str, Any]
    currencies: dict[str, CurrencyInfo]
    loaded_at: float


def _info(row: Currency) -> CurrencyInfo:
    return CurrencyInfo(row.code, row.name, row.minor_unit, row.is_active, row.is_default)


def _dict(c: Currency) -> dict:
    return {
        "code": c.code,
        "name": c.name,
        "minor_unit": c.minor_unit,
        "is_active": c.is_active,
        "is_default": c.is_default,
    }


class ConfigService:
    def __init__(self, session_factory=None) -> None:
        self._session_factory = session_factory or AsyncSessionLocal
        self._snap: _Snapshot | None = None
        self._lock = asyncio.Lock()

    # ---- reading (cached) -------------------------------------------------

    def invalidate(self) -> None:
        self._snap = None

    def _fresh(self, snap: _Snapshot | None) -> bool:
        ttl = settings.settings_cache_ttl_seconds
        return snap is not None and ttl > 0 and (time.monotonic() - snap.loaded_at) < ttl

    async def _load(self) -> _Snapshot:
        async with self._session_factory() as db:
            setting_rows = (await db.execute(select(AppSetting))).scalars().all()
            currency_rows = (await db.execute(select(Currency))).scalars().all()
        return _Snapshot(
            settings={r.key: r.value for r in setting_rows},
            currencies={r.code: _info(r) for r in currency_rows},
            loaded_at=time.monotonic(),
        )

    async def _snapshot(self) -> _Snapshot:
        if self._fresh(self._snap):
            return self._snap  # type: ignore[return-value]
        async with self._lock:
            if self._fresh(self._snap):
                return self._snap  # type: ignore[return-value]
            self._snap = await self._load()
            return self._snap

    async def get_setting(self, key: str) -> Any:
        try:
            get_def(key)
        except SettingValidationError as exc:
            raise ConfigError(str(exc)) from exc
        snap = await self._snapshot()
        if key not in snap.settings:
            raise ConfigError(f"Setting '{key}' is missing from the database. {SEED_HINT}")
        return snap.settings[key]

    async def list_currencies(self, active_only: bool = False) -> list[CurrencyInfo]:
        snap = await self._snapshot()
        rows = sorted(snap.currencies.values(), key=lambda c: c.code)
        return [c for c in rows if c.is_active] if active_only else rows

    async def default_currency(self) -> CurrencyInfo:
        for c in (await self._snapshot()).currencies.values():
            if c.is_default:
                return c
        raise ConfigError(f"No default currency is configured. {SEED_HINT}")

    async def resolve_currency(self, code: str | None) -> CurrencyInfo:
        """None -> the default currency; otherwise the code must be active."""
        if code is None:
            return await self.default_currency()
        snap = await self._snapshot()
        found = snap.currencies.get(code.strip().upper())
        if not found or not found.is_active:
            active = ", ".join(c.code for c in snap.currencies.values() if c.is_active)
            raise HTTPException(422, f"Unsupported currency '{code}'. Active currencies: {active}")
        return found

    async def validate_startup(self) -> None:
        """Fail fast, at boot, if required configuration is absent or invalid."""
        self.invalidate()
        try:
            snap = await self._snapshot()
        except Exception as exc:  # tables missing, DB unreachable, ...
            raise ConfigError(f"Could not load runtime config from the database: {exc}. {SEED_HINT}") from exc

        problems = []
        for key, definition in REGISTRY.items():
            if key not in snap.settings:
                problems.append(f"missing setting '{key}'")
                continue
            try:
                definition.validate(snap.settings[key])
            except SettingValidationError as exc:
                problems.append(str(exc))
        defaults = [c for c in snap.currencies.values() if c.is_default]
        if len(defaults) != 1:
            problems.append("exactly one default currency is required")
        if problems:
            raise ConfigError("; ".join(problems) + f". {SEED_HINT}")

    # ---- admin writes -------------------------------------------------------

    @staticmethod
    def _audit(db: AsyncSession, entity: str, key: str, action: str, old, new, actor: str) -> None:
        db.add(
            ConfigAuditLog(
                entity=entity,
                entity_key=key,
                action=action,
                old_value=old,
                new_value=new,
                changed_by=actor,
            )
        )

    async def create_currency(
        self,
        db: AsyncSession,
        actor: str,
        *,
        code: str,
        name: str,
        minor_unit: int,
        is_active: bool,
        is_default: bool,
    ) -> Currency:
        code = code.strip().upper()
        if not CODE_RE.match(code):
            raise HTTPException(422, "Currency code must be 3 letters (ISO 4217)")
        if is_default and not is_active:
            raise HTTPException(422, "The default currency must be active")
        if await db.get(Currency, code):
            raise HTTPException(409, f"Currency {code} already exists")

        if is_default:
            await self._clear_default(db)
        row = Currency(
            code=code, name=name, minor_unit=minor_unit, is_active=is_active, is_default=is_default
        )
        db.add(row)
        await db.flush()
        self._audit(db, "currency", code, "create", None, _dict(row), actor)
        await db.commit()
        self.invalidate()
        return row

    async def update_currency(
        self,
        db: AsyncSession,
        actor: str,
        code: str,
        *,
        name: str | None = None,
        minor_unit: int | None = None,
        is_active: bool | None = None,
        is_default: bool | None = None,
    ) -> Currency:
        row = (
            await db.execute(
                select(Currency).where(Currency.code == code.strip().upper()).with_for_update()
            )
        ).scalar_one_or_none()
        if not row:
            raise HTTPException(404, "Currency not found")
        old = _dict(row)

        if minor_unit is not None and minor_unit != row.minor_unit:
            in_use = await db.scalar(select(exists().where(LiveEvent.currency == row.code)))
            if in_use:
                raise HTTPException(
                    409, "minor_unit cannot change: existing events are priced in this currency"
                )
            row.minor_unit = minor_unit
        if name is not None:
            row.name = name

        new_active = row.is_active if is_active is None else is_active
        if is_default is False and row.is_default:
            raise HTTPException(409, "Make another currency the default instead of unsetting this one")
        if not new_active and row.is_default and is_default is not True:
            raise HTTPException(409, "Cannot deactivate the default currency; change the default first")
        if is_default is True and not new_active:
            raise HTTPException(422, "The default currency must be active")

        if is_default is True and not row.is_default:
            await self._clear_default(db)
            row.is_default = True
        row.is_active = new_active

        await db.flush()
        self._audit(db, "currency", row.code, "update", old, _dict(row), actor)
        await db.commit()
        self.invalidate()
        return row

    @staticmethod
    async def _clear_default(db: AsyncSession) -> None:
        current = (
            await db.execute(select(Currency).where(Currency.is_default).with_for_update())
        ).scalar_one_or_none()
        if current:
            current.is_default = False
            await db.flush()  # must hit the DB before the new default, or the unique index trips

    async def list_settings(self, db: AsyncSession) -> list[dict]:
        rows = {r.key: r for r in (await db.execute(select(AppSetting))).scalars().all()}
        out = []
        for key, d in REGISTRY.items():
            r = rows.get(key)
            out.append(
                {
                    "key": key,
                    "kind": d.kind,
                    "description": d.description,
                    "value": r.value if r else None,
                    "updated_at": r.updated_at if r else None,
                    "updated_by": r.updated_by if r else None,
                }
            )
        return out

    async def update_setting(self, db: AsyncSession, actor: str, key: str, value: Any) -> dict:
        try:
            definition = get_def(key)
        except SettingValidationError:
            raise HTTPException(404, f"Unknown setting '{key}'") from None
        try:
            value = definition.validate(value)
        except SettingValidationError as exc:
            raise HTTPException(422, str(exc)) from exc

        row = await db.get(AppSetting, key, with_for_update=True)
        old = row.value if row else None
        if row:
            row.value = value
            row.updated_by = actor
        else:
            row = AppSetting(key=key, value=value, updated_by=actor)
            db.add(row)
        self._audit(db, "setting", key, "update" if old is not None else "create", old, value, actor)
        await db.commit()
        await db.refresh(row)
        self.invalidate()
        return {
            "key": key,
            "kind": definition.kind,
            "description": definition.description,
            "value": row.value,
            "updated_at": row.updated_at,
            "updated_by": row.updated_by,
        }


config_service = ConfigService()
