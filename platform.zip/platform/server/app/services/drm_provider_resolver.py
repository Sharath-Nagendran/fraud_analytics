from sqlalchemy import select

from app.models.drm_config import (
    DrmConfig
)

from app.services.drm_service import (
    MockDrmProvider,
    RealDrmProvider
)


class DrmProviderResolver:

    async def resolve(
        self,
        db
    ):

        row = (
            await db.execute(
                select(
                    DrmConfig
                )
            )
        ).scalar_one_or_none()

        if not row:

            return MockDrmProvider()

        if (
            row.enabled
            and
            row.provider == "real"
        ):
            return RealDrmProvider()

        return MockDrmProvider()


drm_provider_resolver = (
    DrmProviderResolver()
)