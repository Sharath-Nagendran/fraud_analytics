import asyncio
import logging

from app.core.config import settings
from app.db.base import AsyncSessionLocal
from app.services.video_reconciliation_service import (
    video_reconciliation_service,
)


logger = logging.getLogger(__name__)


class VideoReconciliationRunner:
    def __init__(self):
        self._task: asyncio.Task | None = None
        self._stop_event: asyncio.Event | None = None
        self._run_lock = asyncio.Lock()

    async def start(self) -> None:
        if not settings.video_reconciliation_enabled:
            logger.warning(
                "Video reconciliation batch is disabled"
            )
            return

        if (
            self._task is not None
            and not self._task.done()
        ):
            return

        self._stop_event = asyncio.Event()

        self._task = asyncio.create_task(
            self._run_loop(),
            name="video-reconciliation-runner",
        )

        logger.info(
            "Video reconciliation batch started; "
            "interval=%s seconds, "
            "idle_grace=%s seconds",
            settings
            .video_reconciliation_interval_seconds,
            settings.video_idle_grace_seconds,
        )

    async def stop(self) -> None:
        if self._task is None:
            return

        if self._stop_event is not None:
            self._stop_event.set()

        self._task.cancel()

        try:
            await self._task
        except asyncio.CancelledError:
            pass
        finally:
            self._task = None
            self._stop_event = None

        logger.info(
            "Video reconciliation batch stopped"
        )

    async def run_once(self) -> dict | None:
        if self._run_lock.locked():
            logger.warning(
                "Video reconciliation skipped because "
                "the previous run is still active"
            )
            return None

        async with self._run_lock:
            async with AsyncSessionLocal() as db:
                result = (
                    await video_reconciliation_service
                    .reconcile_open_events(db)
                )

            logger.info(
                "Video reconciliation completed; "
                "checked=%s changed=%s "
                "failed=%s ended=%s",
                result["checked"],
                result["changed"],
                result["failed"],
                result["ended"],
            )

            return result

    async def _run_loop(self) -> None:
        # Run immediately at application startup.
        while True:
            try:
                await self.run_once()

            except asyncio.CancelledError:
                raise

            except Exception:
                logger.exception(
                    "Video reconciliation batch failed"
                )

            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=(
                        settings
                        .video_reconciliation_interval_seconds
                    ),
                )

                # stop_event was set.
                break

            except asyncio.TimeoutError:
                # The interval elapsed. Run again.
                continue


video_reconciliation_runner = (
    VideoReconciliationRunner()
)