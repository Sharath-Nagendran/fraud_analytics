import base64
import secrets
import time
import uuid

from dataclasses import dataclass
from datetime import datetime, timezone

import jwt

from fastapi import HTTPException
from sqlalchemy import or_, select

from app.core.config import settings
from app.models.entitlement import (
    Entitlement,
    EntitlementStatus,
)
from app.models.live_event import (
    LiveEvent,
    LiveEventStatus,
)
from app.models.ticket import (
    TicketPurchase,
    TicketStatus,
)
from app.models.ticket_tier import TicketTier
from app.services.metrics_service import metrics_service
from app.services.session_registry import (
    SessionLimitExceeded,
    session_registry,
)


@dataclass(frozen=True)
class PlaybackProviderGrant:
    token: str | None
    expires_at: datetime
    mode: str


class MuxPlaybackTokenProvider:
    """
    Issues a signed Mux playback token.

    This provider must only be called for an event whose
    video_provider is 'mux'.
    """

    def issue(
        self,
        playback_id: str,
        session_id: str,
        ttl: int,
    ) -> PlaybackProviderGrant:
        if not settings.mux_signing_key_id:
            raise HTTPException(
                500,
                "MUX_SIGNING_KEY_ID is not configured",
            )

        if not settings.mux_signing_private_key:
            raise HTTPException(
                500,
                "MUX_SIGNING_PRIVATE_KEY is not configured",
            )

        now = int(time.time())
        expires_at_epoch = now + ttl

        token = jwt.encode(
            {
                "sub": playback_id,
                "aud": "v",
                "exp": expires_at_epoch,
                "iat": now,
                "sid": session_id,
            },
            base64.b64decode(
                settings.mux_signing_private_key
            ),
            algorithm="RS256",
            headers={
                "kid": settings.mux_signing_key_id,
                "typ": "JWT",
            },
        )

        return PlaybackProviderGrant(
            token=token,
            expires_at=datetime.fromtimestamp(
                expires_at_epoch,
                timezone.utc,
            ),
            mode="signed",
        )


class FastPixPublicPlaybackProvider:
    """
    Returns a public FastPix playback grant.

    The current FastPix stream was created with public playback.
    Therefore no FastPix token is required for this POC.

    This is not sufficient for a paid production stream because
    anyone with the public manifest URL can play it.
    """

    def issue(
        self,
        playback_id: str,
        session_id: str,
        ttl: int,
    ) -> PlaybackProviderGrant:
        del playback_id
        del session_id

        expires_at_epoch = int(time.time()) + ttl

        return PlaybackProviderGrant(
            token=None,
            expires_at=datetime.fromtimestamp(
                expires_at_epoch,
                timezone.utc,
            ),
            mode="public",
        )

class SelfHostedPlaybackProvider:

    def issue(
        self,
        playback_id: str,
        session_id: str,
        ttl: int,
    ) -> PlaybackProviderGrant:

        expires_at_epoch = (
            int(time.time()) + ttl
        )

        return PlaybackProviderGrant(
            token=None,
            expires_at=datetime.fromtimestamp(
                expires_at_epoch,
                timezone.utc,
            ),
            mode="public",
        )

class MockPlaybackTokenProvider:
    def issue(
        self,
        playback_id: str,
        session_id: str,
        ttl: int,
    ) -> PlaybackProviderGrant:
        del playback_id
        del session_id

        expires_at_epoch = int(time.time()) + ttl

        return PlaybackProviderGrant(
            token=(
                "mock-playback-token-"
                f"{secrets.token_urlsafe(24)}"
            ),
            expires_at=datetime.fromtimestamp(
                expires_at_epoch,
                timezone.utc,
            ),
            mode="mock",
        )


# Compatibility alias.
#
# Other existing modules, including preissue_service.py, may still
# import RealPlaybackTokenProvider. Keep the alias temporarily so
# those imports do not break during this sprint.
RealPlaybackTokenProvider = MuxPlaybackTokenProvider


class PlaybackService:
    def __init__(
        self,
        provider=None,
        registry=None,
    ):
        # An explicitly supplied provider is retained for existing
        # unit tests and temporary compatibility.
        self.provider = provider

        self.registry = registry or session_registry

        self._mock_provider = MockPlaybackTokenProvider()
        self._mux_provider = MuxPlaybackTokenProvider()
        self._fastpix_provider = (FastPixPublicPlaybackProvider())
        self._selfhosted_provider = (SelfHostedPlaybackProvider())

    async def entitlement(
        self,
        db,
        fan_id,
        event_id,
        access: str,
    ):
        now = datetime.now(timezone.utc)

        rows = (
            await db.execute(
                select(
                    Entitlement,
                    TicketPurchase,
                    TicketTier,
                )
                .join(
                    TicketPurchase,
                    TicketPurchase.entitlement_id
                    == Entitlement.id,
                )
                .outerjoin(
                    TicketTier,
                    TicketTier.id
                    == TicketPurchase.tier_id,
                )
                .where(
                    Entitlement.fan_id == fan_id,
                    Entitlement.event_id == event_id,
                    Entitlement.status
                    == EntitlementStatus.ACTIVE,
                    Entitlement.valid_from <= now,
                    or_(
                        Entitlement.valid_until.is_(None),
                        Entitlement.valid_until > now,
                    ),
                    TicketPurchase.status
                    == TicketStatus.PAID,
                )
                .order_by(
                    Entitlement.created_at.desc()
                )
            )
        ).all()

        for entitlement, ticket, tier in rows:
            if tier:
                allowed = {
                    item.strip().upper()
                    for item in tier.content_access.split(",")
                    if item.strip()
                }
            else:
                allowed = {
                    "LIVE",
                    "REPLAY",
                }

            source = (
                entitlement.source or ""
            ).upper()

            if (
                access == "LIVE"
                and "REPLAY" in source
                and source.endswith(":REPLAY")
            ):
                continue

            if access in allowed:
                return entitlement

        metrics_service.counters["denied"] += 1

        if access == "REPLAY":
            detail = (
                "A valid replay ticket is required"
            )
        else:
            detail = (
                "A valid ticket or subscription is required"
            )

        raise HTTPException(
            status_code=403,
            detail=detail,
        )

    async def issue_token(
        self,
        db,
        fan_id,
        event_id,
        requested_session_id=None,
    ):
        try:
            event_key = uuid.UUID(str(event_id))
        except ValueError:
            raise HTTPException(
                status_code=404,
                detail="Event not found",
            )

        event = await db.get(
            LiveEvent,
            event_key,
        )

        if not event:
            raise HTTPException(
                status_code=404,
                detail="Event not found",
            )

        if event.status in (
            LiveEventStatus.DRAFT,
            LiveEventStatus.CANCELLED,
            LiveEventStatus.ARCHIVED,
        ):
            raise HTTPException(
                status_code=404,
                detail="Event not found",
            )

        if event.status != LiveEventStatus.LIVE:
            raise HTTPException(
                status_code=409,
                detail="The event is not live",
            )

        provider_name = (
            event.video_provider
            or self._legacy_provider_name(event)
        )

        playback_id = (
            event.video_playback_id
            or event.mux_playback_id
        )

        if not playback_id:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Playback is not available "
                    "for this event"
                ),
            )

        entitlement = await self.entitlement(
            db,
            fan_id,
            event.id,
            "LIVE",
        )

        try:
            lease = await self.registry.acquire(
                str(entitlement.id),
                requested_session_id,
            )
        except SessionLimitExceeded:
            metrics_service.counters["denied"] += 1

            raise HTTPException(
                status_code=409,
                detail=(
                    "Concurrent playback session "
                    "limit reached"
                ),
            )

        try:
            token_provider = (
                self.provider
                or self._resolve_token_provider(
                    provider_name
                )
            )

            provider_grant = token_provider.issue(
                playback_id,
                lease.session_id,
                settings.playback_token_ttl_seconds,
            )
        except Exception:
            # Avoid consuming a playback-session slot when
            # provider token generation fails.
            await self.registry.release(
                str(entitlement.id),
                lease.session_id,
            )
            raise

        playback_url = (
            event.video_playback_url
            or self._build_playback_url(
                provider_name,
                playback_id,
            )
        )

        metrics_service.counters["issued"] += 1

        return {
            "event_id": str(event.id),
            "provider": provider_name,
            "playback_id": playback_id,
            "playback_url": playback_url,
            "token": provider_grant.token,
            "expires_at": (
                provider_grant.expires_at
            ),
            "refresh_after_seconds": (
                settings.playback_token_refresh_seconds
            ),
            "session_id": lease.session_id,
            "mode": provider_grant.mode,
        }

    async def release_session(
        self,
        db,
        fan_id,
        event_id,
        session_id,
    ):
        try:
            event_key = uuid.UUID(str(event_id))
        except ValueError:
            raise HTTPException(
                status_code=404,
                detail="Event not found",
            )

        entitlement = await self.entitlement(
            db,
            fan_id,
            event_key,
            "LIVE",
        )

        await self.registry.release(
            str(entitlement.id),
            session_id,
        )

    def _resolve_token_provider(
        self,
        provider_name: str,
    ):
        provider_key = provider_name.strip().lower()

        if provider_key == "mock":
            return self._mock_provider

        if provider_key == "mux":
            return self._mux_provider

        if provider_key == "fastpix":
            return self._fastpix_provider

        if provider_key == "selfhosted":
            return self._selfhosted_provider

        raise HTTPException(
            status_code=500,
            detail=(
                "Unsupported video provider: "
                f"{provider_name}"
            ),
        )

    @staticmethod
    def _legacy_provider_name(
        event: LiveEvent,
    ) -> str:
        """
        Compatibility fallback for events created before the
        provider-neutral migration.
        """

        stream_id = (
            event.video_stream_id
            or event.mux_live_stream_id
            or ""
        )

        if stream_id.startswith("fake-"):
            return "mock"

        return "mux"

    @staticmethod
    def _build_playback_url(
        provider_name: str,
        playback_id: str,
    ) -> str | None:
        provider_key = provider_name.strip().lower()

        if provider_key == "fastpix":
            base_url = (
                settings.fastpix_playback_base_url
                .rstrip("/")
            )

            return (
                f"{base_url}/"
                f"{playback_id}.m3u8"
            )

        if provider_key == "mux":
            return (
                "https://stream.mux.com/"
                f"{playback_id}.m3u8"
            )

        if provider_key == "mock":
            return f"mock://{playback_id}"

        if provider_key == "selfhosted":
            return (
                f"{settings.selfhosted_hls_base_url}"
                f"/{playback_id}"
                f"/index.m3u8"
            )

        return None


playback_service = PlaybackService()