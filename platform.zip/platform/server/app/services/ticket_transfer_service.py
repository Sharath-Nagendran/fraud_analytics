import uuid
from datetime import datetime, timedelta, timezone
from fastapi import HTTPException
from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.entitlement import Entitlement, EntitlementStatus
from app.models.live_event import LiveEvent, LiveEventStatus
from app.models.preissued_grant import PreissuedGrantStatus, PreissuedPlaybackGrant
from app.models.ticket import TicketPurchase, TicketStatus
from app.models.ticket_ownership import TicketOwnership, TicketOwnershipAudit, TicketOwnershipStatus, TicketTransfer, TicketTransferStatus
from app.services.session_registry import session_registry

class TicketTransferService:
    TRANSFER_TTL_HOURS = 48

    async def initiate(self, db: AsyncSession, ticket_id: str, sender: str, recipient: str, idempotency_key: str, message: str | None):
        ticket = await self._ticket(db, ticket_id, True)
        event = await db.get(LiveEvent, ticket.event_id)
        self._require_transferable(ticket, event)
        owner = await self._owner(db, ticket, True)
        existing = (await db.execute(select(TicketTransfer).where(TicketTransfer.idempotency_key == idempotency_key))).scalar_one_or_none()
        if existing:
            if existing.ticket_id == ticket.id and existing.from_fan_id == sender and existing.to_fan_id == recipient:
                return existing
            raise HTTPException(409, "Idempotency key was already used for a different transfer")
        if owner.owner_fan_id != sender or owner.status != TicketOwnershipStatus.ACTIVE:
            raise HTTPException(403, "Only the active ticket owner can transfer this ticket")
        if recipient == sender:
            raise HTTPException(422, "Recipient must differ from the current owner")
        pending = (await db.execute(select(TicketTransfer).where(TicketTransfer.ticket_id == ticket.id, TicketTransfer.status == TicketTransferStatus.PENDING))).scalar_one_or_none()
        if pending:
            raise HTTPException(409, "This ticket already has a pending transfer")
        now = datetime.now(timezone.utc)
        transfer = TicketTransfer(ticket_id=ticket.id, from_fan_id=sender, to_fan_id=recipient,
            idempotency_key=idempotency_key, message=message, status=TicketTransferStatus.PENDING,
            created_at=now, expires_at=min(event.scheduled_start, now + timedelta(hours=self.TRANSFER_TTL_HOURS)))
        owner.status = TicketOwnershipStatus.TRANSFER_PENDING
        db.add(transfer); await db.flush()
        db.add(TicketOwnershipAudit(ticket_id=ticket.id, transfer_id=transfer.id, action="TRANSFER_INITIATED",
            actor_fan_id=sender, from_fan_id=sender, to_fan_id=recipient))
        try:
            await db.commit()
        except IntegrityError:
            await db.rollback(); raise HTTPException(409, "Transfer was processed concurrently")
        await db.refresh(transfer); return transfer

    async def accept(self, db: AsyncSession, transfer_id: str, recipient: str):
        transfer = await self._transfer(db, transfer_id, True)
        if transfer.to_fan_id != recipient: raise HTTPException(403, "Only the intended recipient can accept")
        if transfer.status == TicketTransferStatus.ACCEPTED: return transfer
        if transfer.status != TicketTransferStatus.PENDING: raise HTTPException(409, f"Transfer is {transfer.status.value}")
        now = datetime.now(timezone.utc)
        owner = await self._owner_by_ticket(db, transfer.ticket_id, True)
        if transfer.expires_at <= now:
            transfer.status = TicketTransferStatus.EXPIRED; owner.status = TicketOwnershipStatus.ACTIVE
            await db.commit(); raise HTTPException(409, "Transfer has expired")
        ticket = await self._ticket(db, str(transfer.ticket_id), True)
        event = await db.get(LiveEvent, ticket.event_id); self._require_transferable(ticket, event)
        if owner.owner_fan_id != transfer.from_fan_id or owner.status != TicketOwnershipStatus.TRANSFER_PENDING:
            raise HTTPException(409, "Ticket ownership changed before acceptance")
        entitlement = await db.get(Entitlement, ticket.entitlement_id)
        if not entitlement or entitlement.status != EntitlementStatus.ACTIVE:
            raise HTTPException(409, "Ticket has no transferable active entitlement")
        old_owner = owner.owner_fan_id
        entitlement.fan_id = recipient

        ticket.fan_id = recipient
        owner.owner_fan_id = recipient; owner.status = TicketOwnershipStatus.ACTIVE
        owner.ownership_version += 1; owner.acquired_at = now; owner.transferred_at = now
        transfer.status = TicketTransferStatus.ACCEPTED; transfer.accepted_at = now
        await db.execute(update(PreissuedPlaybackGrant).where(
            PreissuedPlaybackGrant.entitlement_id == entitlement.id,
            PreissuedPlaybackGrant.status.in_([PreissuedGrantStatus.READY, PreissuedGrantStatus.CONSUMED])
        ).values(status=PreissuedGrantStatus.REVOKED))
        db.add(TicketOwnershipAudit(ticket_id=ticket.id, transfer_id=transfer.id, action="TRANSFER_ACCEPTED",
            actor_fan_id=recipient, from_fan_id=old_owner, to_fan_id=recipient))
        await db.commit(); await session_registry.release_all(str(entitlement.id)); await db.refresh(transfer)
        return transfer

    async def cancel(self, db, transfer_id, sender):
        transfer = await self._transfer(db, transfer_id, True)
        if transfer.from_fan_id != sender: raise HTTPException(403, "Only the sender can cancel")
        if transfer.status == TicketTransferStatus.CANCELLED: return transfer
        if transfer.status != TicketTransferStatus.PENDING: raise HTTPException(409, f"Transfer is {transfer.status.value}")
        owner = await self._owner_by_ticket(db, transfer.ticket_id, True)
        transfer.status = TicketTransferStatus.CANCELLED; transfer.cancelled_at = datetime.now(timezone.utc); owner.status = TicketOwnershipStatus.ACTIVE
        db.add(TicketOwnershipAudit(ticket_id=transfer.ticket_id, transfer_id=transfer.id, action="TRANSFER_CANCELLED", actor_fan_id=sender, from_fan_id=sender, to_fan_id=transfer.to_fan_id))
        await db.commit(); await db.refresh(transfer); return transfer

    async def decline(self, db, transfer_id, recipient):
        transfer = await self._transfer(db, transfer_id, True)
        if transfer.to_fan_id != recipient: raise HTTPException(403, "Only the recipient can decline")
        if transfer.status == TicketTransferStatus.DECLINED: return transfer
        if transfer.status != TicketTransferStatus.PENDING: raise HTTPException(409, f"Transfer is {transfer.status.value}")
        owner = await self._owner_by_ticket(db, transfer.ticket_id, True)
        transfer.status = TicketTransferStatus.DECLINED; owner.status = TicketOwnershipStatus.ACTIVE
        db.add(TicketOwnershipAudit(ticket_id=transfer.ticket_id, transfer_id=transfer.id, action="TRANSFER_DECLINED", actor_fan_id=recipient, from_fan_id=transfer.from_fan_id, to_fan_id=recipient))
        await db.commit(); await db.refresh(transfer); return transfer

    async def my_tickets(self, db, fan_id):
        rows = (await db.execute(select(TicketOwnership, TicketPurchase).join(TicketPurchase, TicketPurchase.id == TicketOwnership.ticket_id).where(TicketOwnership.owner_fan_id == fan_id).order_by(TicketOwnership.acquired_at.desc()))).all()
        return [{"ticket_id":t.id,"event_id":t.event_id,"purchaser_fan_id":t.fan_id,"owner_fan_id":o.owner_fan_id,
            "ownership_status":o.status.value,"ticket_status":t.status.value,"entitlement_id":t.entitlement_id,
            "tier_id":t.tier_id,"amount_cents":t.amount_cents,"currency":t.currency} for o,t in rows]

    async def transfers(self, db, fan_id):
        return (await db.execute(select(TicketTransfer).where((TicketTransfer.from_fan_id == fan_id) | (TicketTransfer.to_fan_id == fan_id)).order_by(TicketTransfer.created_at.desc()))).scalars().all()

    @staticmethod
    def _require_transferable(ticket, event):
        if not event: raise HTTPException(404, "Event not found")
        if ticket.status != TicketStatus.PAID: raise HTTPException(409, "Only a paid ticket can be transferred")
        if event.status != LiveEventStatus.SCHEDULED: raise HTTPException(409, "Transfers close when the event goes live")
        if event.scheduled_start <= datetime.now(timezone.utc): raise HTTPException(409, "Transfer window has closed")

    async def _owner(self, db, ticket, lock=False):
        stmt = select(TicketOwnership).where(TicketOwnership.ticket_id == ticket.id)
        if lock: stmt = stmt.with_for_update()
        row = (await db.execute(stmt)).scalar_one_or_none()
        if not row:
            row = TicketOwnership(ticket_id=ticket.id, owner_fan_id=ticket.fan_id); db.add(row); await db.flush()
        return row

    async def _owner_by_ticket(self, db, ticket_id, lock=False):
        ticket = await db.get(TicketPurchase, ticket_id)
        if not ticket: raise HTTPException(404, "Ticket not found")
        return await self._owner(db, ticket, lock)

    @staticmethod
    async def _ticket(db, ticket_id, lock=False):
        try: key = uuid.UUID(ticket_id)
        except ValueError: raise HTTPException(404, "Ticket not found")
        stmt = select(TicketPurchase).where(TicketPurchase.id == key)
        if lock: stmt = stmt.with_for_update()
        row = (await db.execute(stmt)).scalar_one_or_none()
        if not row: raise HTTPException(404, "Ticket not found")
        return row

    @staticmethod
    async def _transfer(db, transfer_id, lock=False):
        try: key = uuid.UUID(transfer_id)
        except ValueError: raise HTTPException(404, "Transfer not found")
        stmt = select(TicketTransfer).where(TicketTransfer.id == key)
        if lock: stmt = stmt.with_for_update()
        row = (await db.execute(stmt)).scalar_one_or_none()
        if not row: raise HTTPException(404, "Transfer not found")
        return row

ticket_transfer_service = TicketTransferService()
