import socket
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.live_event import LiveEvent
from app.models.live_recording import LiveRecording
from app.models.replay_job import ReplayJob, ReplayJobStatus
from app.services.replay_pipeline_service import replay_pipeline_service


class ReplayJobService:
    async def enqueue(self, db: AsyncSession, event: LiveEvent, recording: LiveRecording) -> ReplayJob:
        existing = (
            await db.execute(select(ReplayJob).where(ReplayJob.live_event_id == event.id))
        ).scalar_one_or_none()
        if existing:
            return existing

        job = ReplayJob(
            live_event_id=event.id,
            live_recording_id=recording.id,
            status=ReplayJobStatus.PENDING,
            next_attempt_at=(
                datetime.now(timezone.utc)
                + timedelta(seconds=settings.replay_job_initial_delay_seconds)
            ),
            max_attempts=settings.replay_job_max_attempts,
        )
        db.add(job)
        await db.flush()
        return job

    async def get_for_artist(
        self, db: AsyncSession, artist_id: str, event_id: str
    ) -> ReplayJob:
        event_key = self._parse_uuid(event_id)
        event = await db.get(LiveEvent, event_key)
        if not event or event.artist_id != artist_id:
            raise HTTPException(404, "Event not found")

        job = (
            await db.execute(select(ReplayJob).where(ReplayJob.live_event_id == event.id))
        ).scalar_one_or_none()
        if not job:
            raise HTTPException(404, "Replay job not found")
        return job

    async def dispatch_one(self, db: AsyncSession, worker_id: str | None = None) -> dict | None:
        now = datetime.now(timezone.utc)
        worker = worker_id or socket.gethostname()

        job = (
            await db.execute(
                select(ReplayJob)
                .where(
                    ReplayJob.status.in_([ReplayJobStatus.PENDING, ReplayJobStatus.RETRY]),
                    ReplayJob.next_attempt_at <= now,
                )
                .order_by(ReplayJob.created_at.asc())
                .with_for_update(skip_locked=True)
                .limit(1)
            )
        ).scalar_one_or_none()

        if not job:
            await db.rollback()
            return None

        job.status = ReplayJobStatus.PROCESSING
        job.attempts += 1
        job.locked_at = now
        job.locked_by = worker
        job.updated_at = now
        await db.commit()

        event = await db.get(LiveEvent, job.live_event_id)
        if not event:
            await self._fail(db, job.id, "Live event not found")
            return {"job_id": job.id, "status": "FAILED"}

        try:
            result = await replay_pipeline_service.process(
                db=db,
                artist_id=event.artist_id,
                event_id=str(event.id),
            )
            assembly = result["assembly"]

            refreshed = await db.get(ReplayJob, job.id)
            if not refreshed:
                raise RuntimeError("Replay job disappeared during processing")
            refreshed.status = ReplayJobStatus.COMPLETED
            refreshed.video_asset_id = uuid.UUID(str(assembly["video_asset_id"]))
            refreshed.completed_at = datetime.now(timezone.utc)
            refreshed.locked_at = None
            refreshed.locked_by = None
            refreshed.last_error = None
            refreshed.updated_at = datetime.now(timezone.utc)
            await db.commit()
            return {"job_id": refreshed.id, "status": refreshed.status.value}

        except Exception as exc:
            await db.rollback()
            refreshed = await db.get(ReplayJob, job.id)
            if not refreshed:
                raise

            error = f"{type(exc).__name__}: {exc!r}"[:4000]
            refreshed.last_error = error
            refreshed.locked_at = None
            refreshed.locked_by = None
            refreshed.updated_at = datetime.now(timezone.utc)

            if refreshed.attempts >= refreshed.max_attempts:
                refreshed.status = ReplayJobStatus.FAILED
            else:
                refreshed.status = ReplayJobStatus.RETRY
                delay_seconds = min(300, 15 * (2 ** (refreshed.attempts - 1)))
                refreshed.next_attempt_at = datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)

            await db.commit()
            return {"job_id": refreshed.id, "status": refreshed.status.value, "error": error}

    async def recover_stale(self, db: AsyncSession, stale_after_seconds: int = 1800) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=stale_after_seconds)
        jobs = (
            await db.execute(
                select(ReplayJob).where(
                    ReplayJob.status == ReplayJobStatus.PROCESSING,
                    ReplayJob.locked_at < cutoff,
                )
            )
        ).scalars().all()
        for job in jobs:
            job.status = ReplayJobStatus.RETRY
            job.next_attempt_at = datetime.now(timezone.utc)
            job.locked_at = None
            job.locked_by = None
            job.last_error = "Recovered stale PROCESSING job"
        await db.commit()
        return len(jobs)

    @staticmethod
    async def _fail(db: AsyncSession, job_id: uuid.UUID, error: str) -> None:
        job = await db.get(ReplayJob, job_id)
        if job:
            job.status = ReplayJobStatus.FAILED
            job.last_error = error
            job.locked_at = None
            job.locked_by = None
            job.updated_at = datetime.now(timezone.utc)
            await db.commit()

    @staticmethod
    def _parse_uuid(value: str) -> uuid.UUID:
        try:
            return uuid.UUID(str(value))
        except ValueError as exc:
            raise HTTPException(404, "Event not found") from exc


replay_job_service = ReplayJobService()