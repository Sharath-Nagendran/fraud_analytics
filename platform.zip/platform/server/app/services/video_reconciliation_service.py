import logging

from datetime import (
    datetime,
    timedelta,
    timezone,
)

from sqlalchemy import select

from app.core.config import settings
from app.models.live_event import (
    LiveEvent,
    LiveEventStatus,
)
from app.video.resolver import (
    video_provider_resolver,
)


logger = logging.getLogger(__name__)


ACTIVE_PROVIDER_STATUSES = {
    "active",
}

TRANSITIONAL_PROVIDER_STATUSES = {
    "preparing",
    "connected",
}

IDLE_PROVIDER_STATUSES = {
    "idle",
    "disconnected",
}

DISABLED_PROVIDER_STATUSES = {
    "disabled",
}


class VideoReconciliationService:
    async def reconcile_open_events(
        self,
        db,
    ) -> dict:
        now = datetime.now(timezone.utc)

        idle_cutoff = now - timedelta(
            seconds=settings.video_idle_grace_seconds
        )

        events = (
            await db.execute(
                select(LiveEvent)
                .where(
                    LiveEvent.video_provider.is_not(
                        None
                    ),
                    LiveEvent.video_provider
                    != "mock",
                    LiveEvent.video_stream_id.is_not(
                        None
                    ),
                    LiveEvent.status.in_(
                        [
                            LiveEventStatus.SCHEDULED,
                            LiveEventStatus.LIVE,
                            LiveEventStatus.ENDED,
                        ]
                    ),
                )
                .order_by(
                    LiveEvent.created_at
                )
            )
        ).scalars().all()

        checked = 0
        changed = 0
        unchanged = 0
        failed = 0
        active = 0
        idle = 0
        ended = 0

        results: list[dict] = []

        for event in events:
            checked += 1

            before_status = event.status.value
            before_idle_since = (
                event.provider_idle_since
            )

            try:
                provider = (
                    video_provider_resolver.resolve(
                        event.video_provider
                    )
                )

                remote = (
                    await provider
                    .get_live_stream_status(
                        event.video_stream_id
                    )
                )

                remote_status = (
                    remote.status
                    .strip()
                    .lower()
                )

                action = "NONE"

                #
                # ACTIVE
                #
                if (
                    remote_status
                    in ACTIVE_PROVIDER_STATUSES
                ):
                    active += 1

                    # An active stream clears any pending
                    # idle observation.
                    event.provider_idle_since = None

                    if (event.status!= LiveEventStatus.LIVE):
                        event.status = (LiveEventStatus.LIVE)

                        event.provider_idle_since = None

                        action = "MARKED_LIVE"
                    elif before_idle_since is not None:
                        action = "CLEARED_IDLE_TIMER"
                    else:
                        action = "ALREADY_LIVE"

                #
                # PREPARING / CONNECTED
                #
                elif (
                    remote_status
                    in TRANSITIONAL_PROVIDER_STATUSES
                ):
                    # The provider is progressing toward
                    # ACTIVE, so do not start an idle timer.
                    event.provider_idle_since = None

                    action = "WAITING_FOR_ACTIVE"

                #
                # IDLE / DISCONNECTED
                #
                elif (
                    remote_status
                    in IDLE_PROVIDER_STATUSES
                ):
                    idle += 1

                    if (
                        event.status
                        == LiveEventStatus.SCHEDULED
                    ):
                        # A stream that has never become LIVE
                        # should remain scheduled.
                        event.provider_idle_since = None

                        action = "STILL_SCHEDULED"

                    elif (
                        event.status
                        == LiveEventStatus.LIVE
                    ):
                        if (
                            event.provider_idle_since
                            is None
                        ):
                            # First idle observation.
                            event.provider_idle_since = now

                            action = (
                                "IDLE_GRACE_STARTED"
                            )

                        elif (
                            event.provider_idle_since
                            <= idle_cutoff
                        ):
                            # The stream remained idle for the
                            # configured application grace
                            # period.
                            event.status = (
                                LiveEventStatus.ENDED
                            )

                            event.ended_at = now
                            event.provider_idle_since = None

                            ended += 1

                            action = (
                                "MARKED_ENDED_AFTER_GRACE"
                            )

                        else:
                            elapsed_seconds = int(
                                (
                                    now
                                    - event.provider_idle_since
                                ).total_seconds()
                            )

                            action = (
                                "WAITING_IN_IDLE_GRACE_"
                                f"{elapsed_seconds}_SECONDS"
                            )

                #
                # DISABLED
                #
                elif (
                    remote_status
                    in DISABLED_PROVIDER_STATUSES
                ):
                    if (
                        event.status
                        == LiveEventStatus.LIVE
                    ):
                        if (
                            event.provider_idle_since
                            is None
                        ):
                            event.provider_idle_since = now

                        action = (
                            "PROVIDER_DISABLED_"
                            "IDLE_GRACE_STARTED"
                        )
                    else:
                        action = (
                            "PROVIDER_DISABLED"
                        )

                #
                # UNKNOWN
                #
                else:
                    action = (
                        "UNKNOWN_PROVIDER_STATUS"
                    )

                after_status = event.status.value

                if (
                    after_status != before_status
                    or event.provider_idle_since
                    != before_idle_since
                ):
                    changed += 1
                else:
                    unchanged += 1

                results.append(
                    {
                        "event_id": str(event.id),
                        "provider": (
                            event.video_provider
                        ),
                        "stream_id": (
                            event.video_stream_id
                        ),
                        "provider_status": (
                            remote_status
                        ),
                        "before_status": (
                            before_status
                        ),
                        "after_status": (
                            after_status
                        ),
                        "provider_idle_since": (
                            event.provider_idle_since
                            .isoformat()
                            if event.provider_idle_since
                            else None
                        ),
                        "action": action,
                    }
                )

            except Exception as exc:
                failed += 1

                logger.exception(
                    "Video reconciliation failed "
                    "for event %s",
                    event.id,
                )

                results.append(
                    {
                        "event_id": str(event.id),
                        "provider": (
                            event.video_provider
                        ),
                        "stream_id": (
                            event.video_stream_id
                        ),
                        "provider_status": None,
                        "before_status": (
                            before_status
                        ),
                        "after_status": (
                            before_status
                        ),
                        "provider_idle_since": (
                            before_idle_since
                            .isoformat()
                            if before_idle_since
                            else None
                        ),
                        "action": "FAILED",
                        "error": str(exc)[:1000],
                    }
                )

        await db.commit()

        return {
            "run_at": now.isoformat(),
            "interval_seconds": (
                settings
                .video_reconciliation_interval_seconds
            ),
            "idle_grace_seconds": (
                settings.video_idle_grace_seconds
            ),
            "checked": checked,
            "changed": changed,
            "unchanged": unchanged,
            "failed": failed,
            "active": active,
            "idle": idle,
            "ended": ended,
            "results": results,
        }


video_reconciliation_service = (
    VideoReconciliationService()
)