import secrets

from app.core.config import settings

from app.models.drm_session import (
    DrmSession,
    DrmSessionStatus
)

from datetime import (
    datetime,
    timedelta,
    timezone
)

class MockDrmProvider:

    async def issue_license(
        self,
        db,
        event_id,
        fan_id,
        entitlement_id,
        playback_session_id
    ):

        watermark_id = (
            f"wm-{secrets.token_hex(8)}"
        )

        license_token = (
            f"mock-license-{secrets.token_hex(16)}"
        )

        session = DrmSession(
            event_id=event_id,
            fan_id=fan_id,
            entitlement_id=entitlement_id,
            playback_session_id=playback_session_id,
            drm_mode="mock",
            watermark_id=watermark_id,
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=15),
            status=DrmSessionStatus.ACTIVE
        )

        db.add(session)

        await db.commit()

        return {
            "drm_mode": "mock",
            "widevine": True,
            "fairplay": True,
            "playready": True,
            "watermark_id": watermark_id,
            "license_token": license_token
        }


class RealDrmProvider:

    async def issue_license(
        self,
        db,
        event_id,
        fan_id,
        entitlement_id,
        playback_session_id
    ):
        watermark_id = (
            f"wm-{secrets.token_hex(8)}"
        )

        session = DrmSession(
            event_id=event_id,
            fan_id=fan_id,
            entitlement_id=entitlement_id,
            playback_session_id=playback_session_id,
            drm_mode="real",
            watermark_id=watermark_id,
            expires_at=datetime.now(timezone.utc)
                       + timedelta(minutes=15),
            status=DrmSessionStatus.ACTIVE
        )

        db.add(session)

        await db.commit()

        return {
            "drm_mode": "real",

            "widevine": True,

            "fairplay": True,

            "playready": True,

            "watermark_id":
                watermark_id,

            "widevine_url":
                settings.widevine_license_url,

            "fairplay_url":
                settings.fairplay_license_url,

            "playready_url":
                settings.playready_license_url,
        }


drm_provider = (
    MockDrmProvider()
    if not settings.drm_enabled
    else RealDrmProvider()
)