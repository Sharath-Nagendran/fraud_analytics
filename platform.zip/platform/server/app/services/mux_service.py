import logging, uuid
from dataclasses import dataclass
import mux_python
from fastapi import HTTPException
from mux_python.rest import ApiException
from app.core.config import settings
from app.services.fastpix_service import FastPixService

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class StreamOptions:
    reconnect_window_seconds: int
    reduced_latency: bool
    playback_policy: str
    rtmp_ingest_url: str


class MuxService:
    def __init__(self):
        configuration = mux_python.Configuration()
        configuration.username = settings.mux_token_id
        configuration.password = settings.mux_token_secret
        api_client = mux_python.ApiClient(configuration)
        self.live_streams_api = mux_python.LiveStreamsApi(api_client)
        self.assets_api = mux_python.AssetsApi(api_client)

    def create_live_stream(self, passthrough_id, options):
        policy = [mux_python.PlaybackPolicy(options.playback_policy)]
        request = mux_python.CreateLiveStreamRequest(
            playback_policy=policy,
            new_asset_settings=mux_python.CreateAssetRequest(playback_policy=policy),
            passthrough=passthrough_id, reconnect_window=options.reconnect_window_seconds,
            reduced_latency=options.reduced_latency,
        )
        try: response = self.live_streams_api.create_live_stream(request)
        except ApiException as err:
            raise HTTPException(502, f"Mux error ({err.status}): {err.body}") from err
        stream = response.data
        playback_id = stream.playback_ids[0].id if stream.playback_ids else None
        if not stream.stream_key or not playback_id: raise RuntimeError("Mux did not return a stream key or playback ID")
        return {"mux_live_stream_id": stream.id, "mux_stream_key": stream.stream_key,
                "mux_playback_id": playback_id, "rtmp_ingest_url": options.rtmp_ingest_url}

    def get_asset_playback_id(self, asset_id):
        try: asset = self.assets_api.get_asset(asset_id).data
        except ApiException as err:
            raise HTTPException(502, f"Mux asset error ({err.status}): {err.body}") from err
        playback_id = asset.playback_ids[0].id if asset.playback_ids else None
        if not playback_id: raise RuntimeError("Mux asset has no playback ID")
        return playback_id

    def complete_live_stream(self, stream_id):
        try: self.live_streams_api.signal_live_stream_complete(stream_id)
        except ApiException as err: logger.warning("complete_live_stream failed: %s", err)

    def delete_live_stream(self, stream_id):
        try: self.live_streams_api.delete_live_stream(stream_id)
        except ApiException as err: raise HTTPException(502, f"Mux error ({err.status}): {err.body}") from err


class FakeMuxService:
    def create_live_stream(self, passthrough_id, options):
        fake_id = f"fake-{uuid.uuid4()}"
        return {"mux_live_stream_id": fake_id, "mux_stream_key": f"fake-stream-key-{fake_id}",
                "mux_playback_id": f"fake-playback-{fake_id}", "rtmp_ingest_url": options.rtmp_ingest_url}
    def get_asset_playback_id(self, asset_id): return f"mock-vod-playback-{asset_id}"
    def complete_live_stream(self, stream_id): logger.warning("Pretending to complete %s", stream_id)
    def delete_live_stream(self, stream_id): logger.warning("Pretending to delete %s", stream_id)


if settings.video_provider == "fastpix":
    mux_service = FastPixService()

elif settings.mux_stub_mode:
    mux_service = FakeMuxService()

else:
    mux_service = MuxService()