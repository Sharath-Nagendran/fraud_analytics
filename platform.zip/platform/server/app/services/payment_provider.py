import uuid
from dataclasses import dataclass
from app.core.config import settings

@dataclass(frozen=True)
class PaymentResult:
    payment_id: str
    provider: str
    paid: bool

class PaymentProvider:
    async def charge(self, *, amount_cents: int, currency: str, idempotency_key: str) -> PaymentResult:
        raise NotImplementedError
    async def refund(self, *, payment_id: str, idempotency_key: str) -> bool:
        raise NotImplementedError

class MockPaymentProvider(PaymentProvider):
    async def charge(self, *, amount_cents: int, currency: str, idempotency_key: str) -> PaymentResult:
        # Deterministic ID makes client retries safe.
        return PaymentResult(f"mock_pay_{uuid.uuid5(uuid.NAMESPACE_URL, idempotency_key).hex}", "MOCK", True)
    async def refund(self, *, payment_id: str, idempotency_key: str) -> bool:
        return True

class UnconfiguredRealPaymentProvider(PaymentProvider):
    async def charge(self, **kwargs):
        raise RuntimeError("Real payment provider is not configured")
    async def refund(self, **kwargs):
        raise RuntimeError("Real payment provider is not configured")

payment_provider = MockPaymentProvider() if settings.payment_stub_mode else UnconfiguredRealPaymentProvider()
