import uuid
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.live_event import LiveEvent, LiveEventStatus
from app.models.operational_alert import (
    AlertDelivery,
    AlertDeliveryStatus,
    AlertSeverity,
    AlertStatus,
    OperationalAlert,
)


class OperationalAlertService:
    PLAYBACK_ERROR_CRITICAL_PERCENT = 20.0

    async def raise_alert(
        self,
        db: AsyncSession,
        event_id: str,
        alert_type: str,
        severity: AlertSeverity,
        summary: str,
        details: str | None = None,
    ) -> OperationalAlert:
        event = await self._event(db, event_id)
        if event.status != LiveEventStatus.LIVE:
            raise HTTPException(409, "Operational alerts can only be raised for a live event")

        fingerprint = f"{event.id}:{alert_type}"
        alert = (await db.execute(select(OperationalAlert).where(
            OperationalAlert.fingerprint == fingerprint
        ).with_for_update())).scalar_one_or_none()
        now = datetime.now(timezone.utc)

        if alert and alert.status != AlertStatus.RESOLVED:
            alert.occurrence_count += 1
            alert.last_seen_at = now
            alert.severity = severity
            alert.details = details
            await db.commit()
            await db.refresh(alert)
            return alert

        if alert and alert.status == AlertStatus.RESOLVED:
            # Keep the previous alert as immutable history by creating a new fingerprint generation.
            fingerprint = f"{fingerprint}:{int(now.timestamp())}:{uuid.uuid4().hex[:8]}"

        alert = OperationalAlert(
            event_id=event.id,
            alert_type=alert_type,
            fingerprint=fingerprint,
            severity=severity,
            status=AlertStatus.FIRING,
            summary=summary,
            details=details,
            first_seen_at=now,
            last_seen_at=now,
        )
        db.add(alert)
        await db.flush()
        db.add(AlertDelivery(alert_id=alert.id, channel="MOCK", status=AlertDeliveryStatus.PENDING))
        await db.commit()
        await db.refresh(alert)
        return alert

    async def signal_ingest_failure(self, db: AsyncSession, event_id: str, details: str | None):
        return await self.raise_alert(
            db, event_id, "INGEST_FAILURE", AlertSeverity.CRITICAL,
            "Live ingest has failed", details,
        )

    async def signal_playback_errors(self, db: AsyncSession, event_id: str, error_rate: float, details: str | None):
        severity = AlertSeverity.CRITICAL if error_rate >= self.PLAYBACK_ERROR_CRITICAL_PERCENT else AlertSeverity.WARNING
        return await self.raise_alert(
            db, event_id, "ELEVATED_PLAYBACK_ERRORS", severity,
            f"Playback error rate is {error_rate:.2f}%", details,
        )

    async def acknowledge(self, db: AsyncSession, alert_id: str, operator_id: str, note: str | None):
        alert = await self._alert(db, alert_id)
        if alert.status == AlertStatus.RESOLVED:
            raise HTTPException(409, "Resolved alerts cannot be acknowledged")
        alert.status = AlertStatus.ACKNOWLEDGED
        alert.acknowledged_at = datetime.now(timezone.utc)
        alert.acknowledged_by = operator_id
        if note:
            alert.details = f"{alert.details or ''}\nACK: {note}".strip()
        await db.commit(); await db.refresh(alert)
        return alert

    async def resolve(self, db: AsyncSession, alert_id: str, operator_id: str, note: str | None):
        alert = await self._alert(db, alert_id)
        if alert.status == AlertStatus.RESOLVED:
            return alert
        alert.status = AlertStatus.RESOLVED
        alert.resolved_at = datetime.now(timezone.utc)
        alert.resolution_note = note or f"Resolved by {operator_id}"
        await db.commit(); await db.refresh(alert)
        return alert

    async def list_alerts(self, db: AsyncSession, event_id: str | None, status: AlertStatus | None):
        stmt = select(OperationalAlert)
        if event_id:
            try: event_key = uuid.UUID(event_id)
            except ValueError: raise HTTPException(404, "Event not found")
            stmt = stmt.where(OperationalAlert.event_id == event_key)
        if status:
            stmt = stmt.where(OperationalAlert.status == status)
        return (await db.execute(stmt.order_by(OperationalAlert.last_seen_at.desc()))).scalars().all()

    async def dispatch(self, db: AsyncSession, batch_size: int):
        rows = (await db.execute(select(AlertDelivery).where(
            AlertDelivery.status == AlertDeliveryStatus.PENDING
        ).order_by(AlertDelivery.created_at).limit(batch_size).with_for_update(skip_locked=True))).scalars().all()
        sent = failed = 0
        for row in rows:
            try:
                row.attempt_count += 1
                row.status = AlertDeliveryStatus.SENT
                row.sent_at = datetime.now(timezone.utc)
                sent += 1
            except Exception as exc:
                row.status = AlertDeliveryStatus.FAILED
                row.last_error = str(exc)[:1000]
                failed += 1
        await db.commit()
        return {"sent": sent, "failed": failed}

    async def summary(self, db: AsyncSession):
        async def count_status(status):
            return (await db.scalar(select(func.count()).select_from(OperationalAlert).where(
                OperationalAlert.status == status
            ))) or 0
        pending = (await db.scalar(select(func.count()).select_from(AlertDelivery).where(
            AlertDelivery.status == AlertDeliveryStatus.PENDING
        ))) or 0
        return {
            "firing": await count_status(AlertStatus.FIRING),
            "acknowledged": await count_status(AlertStatus.ACKNOWLEDGED),
            "resolved": await count_status(AlertStatus.RESOLVED),
            "pending_deliveries": pending,
        }

    @staticmethod
    async def _event(db: AsyncSession, event_id: str):
        try: key = uuid.UUID(event_id)
        except ValueError: raise HTTPException(404, "Event not found")
        event = await db.get(LiveEvent, key)
        if not event: raise HTTPException(404, "Event not found")
        return event

    @staticmethod
    async def _alert(db: AsyncSession, alert_id: str):
        try: key = uuid.UUID(alert_id)
        except ValueError: raise HTTPException(404, "Alert not found")
        alert = await db.get(OperationalAlert, key)
        if not alert: raise HTTPException(404, "Alert not found")
        return alert


operational_alert_service = OperationalAlertService()
