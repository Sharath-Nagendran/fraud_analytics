import uuid

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.video_asset import (
    VideoAsset,
    VideoAssetStatus,
    VideoAssetType,
    VideoAssetVisibility,
)
from app.storage import (
    StoredObject,
    get_storage_provider,
)


@dataclass(frozen=True)
class VideoAssetIngestionRequest:
    artist_id: str
    title: str

    source_path: Path
    object_key: str

    asset_type: VideoAssetType

    description: str | None = None
    source_live_event_id: uuid.UUID | None = None

    thumbnail_url: str | None = None
    duration_seconds: int | None = None

    visibility: VideoAssetVisibility = VideoAssetVisibility.PRIVATE
    price_cents: int | None = None
    currency: str = "GBP"

    content_type: str | None = None
    publish_immediately: bool = False


class VideoAssetIngestionService:
    async def ingest(
        self,
        db: AsyncSession,
        request: VideoAssetIngestionRequest,
    ) -> VideoAsset:
        self._validate_request(request)

        existing = await self._find_existing_asset(
            db=db,
            request=request,
        )

        if existing:
            return existing

        storage = get_storage_provider()

        stored = await storage.put_file(
            source_path=request.source_path,
            object_key=request.object_key,
            content_type=request.content_type,
        )

        try:
            asset = self._build_asset(
                request=request,
                stored=stored,
            )

            db.add(asset)
            await db.commit()
            await db.refresh(asset)

            return asset

        except Exception:
            await db.rollback()

            try:
                await storage.delete(stored.object_key)
            except Exception:
                pass

            raise

    async def _find_existing_asset(
        self,
        db: AsyncSession,
        request: VideoAssetIngestionRequest,
    ) -> VideoAsset | None:
        if (
            request.asset_type == VideoAssetType.LIVE_RECORDING
            and request.source_live_event_id is not None
        ):
            result = await db.execute(
                select(VideoAsset)
                .where(
                    VideoAsset.asset_type
                    == VideoAssetType.LIVE_RECORDING,
                    VideoAsset.source_live_event_id
                    == request.source_live_event_id,
                )
                .order_by(VideoAsset.created_at.desc())
            )

            return result.scalars().first()

        return None

    @staticmethod
    def _build_asset(
        request: VideoAssetIngestionRequest,
        stored: StoredObject,
    ) -> VideoAsset:
        now = datetime.now(timezone.utc)

        return VideoAsset(
            artist_id=request.artist_id,
            source_live_event_id=request.source_live_event_id,
            title=request.title.strip(),
            description=request.description,
            asset_type=request.asset_type,
            video_provider="selfhosted",
            video_asset_provider_id=None,
            storage_provider=stored.provider,
            storage_object_key=stored.object_key,
            storage_url=stored.storage_url,
            thumbnail_url=request.thumbnail_url,
            duration_seconds=request.duration_seconds,
            visibility=request.visibility,
            price_cents=request.price_cents,
            currency=request.currency.upper(),
            status=(
                VideoAssetStatus.READY
                if request.publish_immediately
                else VideoAssetStatus.PROCESSING
            ),
            published_at=(
                now
                if request.publish_immediately
                else None
            ),
            created_at=now,
            updated_at=now,
        )

    @staticmethod
    def _validate_request(
        request: VideoAssetIngestionRequest,
    ) -> None:
        if not request.artist_id.strip():
            raise ValueError("artist_id is required")

        if not request.title.strip():
            raise ValueError("title is required")

        if not request.object_key.strip():
            raise ValueError("object_key is required")

        if not request.source_path:
            raise ValueError("source_path is required")

        if request.duration_seconds is not None and request.duration_seconds < 0:
            raise ValueError("duration_seconds cannot be negative")

        if len(request.currency.strip()) != 3:
            raise ValueError("currency must contain exactly three characters")

        if (
            request.asset_type == VideoAssetType.LIVE_RECORDING
            and request.source_live_event_id is None
        ):
            raise ValueError(
                "source_live_event_id is required for LIVE_RECORDING assets"
            )

        if (
            request.asset_type == VideoAssetType.UPLOAD
            and request.source_live_event_id is not None
        ):
            raise ValueError(
                "source_live_event_id cannot be set for uploaded assets"
            )

        if (
            request.visibility == VideoAssetVisibility.PPV
            and (
                request.price_cents is None
                or request.price_cents <= 0
            )
        ):
            raise ValueError(
                "A positive price is required for PPV assets"
            )

        if (
            request.visibility != VideoAssetVisibility.PPV
            and request.price_cents is not None
        ):
            raise ValueError(
                "price_cents is only supported for PPV assets"
            )


video_asset_ingestion_service = VideoAssetIngestionService()
