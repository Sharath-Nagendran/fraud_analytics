import time
import uuid
from datetime import datetime, timezone, timedelta

from fastapi import HTTPException
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.chat import (ChatMessage, ChatMessageStatus, ChatMessageType, ChatParticipant, ChatParticipantStatus, ChatParticipantType,
    ChatRoom, ChatRoomStatus, ChatRoomType, ModerationDecision, ModerationDecisionType)

from app.core.config import settings
from app.models.entitlement import Entitlement, EntitlementStatus
from app.models.live_event import LiveEvent
from app.moderation import ModerationRequest, get_moderation_provider
from app.models.chat import ModerationIncident, ModerationIncidentType, ModerationAction, ModerationIncidentStatus, ModerationDecisionType
from app.chat.connection_manager import (chat_connection_manager,)

class ChatService:
    async def create_live_event_room(
        self,
        db: AsyncSession,
        artist_id: str,
        event_id: str,
    ) -> ChatRoom:
        event_key = self._uuid(event_id, "Event not found")
        event = await db.get(LiveEvent, event_key)
        if not event or event.artist_id != artist_id:
            raise HTTPException(404, "Event not found")

        existing = (
            await db.execute(
                select(ChatRoom).where(ChatRoom.live_event_id == event.id)
            )
        ).scalar_one_or_none()
        if existing:
            return existing

        room = ChatRoom(
            room_type=ChatRoomType.LIVE_EVENT,
            live_event_id=event.id,
            artist_id=artist_id,
            status=ChatRoomStatus.OPEN,
            moderation_enabled=True,
            moderation_policy_version="chat-policy-v1",
        )
        db.add(room)

        try:
            await db.commit()
            await db.refresh(room)
            return room
        except IntegrityError:
            await db.rollback()
            existing = (
                await db.execute(
                    select(ChatRoom).where(ChatRoom.live_event_id == event.id)
                )
            ).scalar_one_or_none()
            if existing:
                return existing
            raise

    async def join_artist(
        self,
        db: AsyncSession,
        room_id: str,
        artist_id: str,
    ) -> ChatParticipant:
        room = await self._room(db, room_id)
        if room.artist_id != artist_id:
            raise HTTPException(404, "Chat room not found")
        return await self._join(
            db,
            room,
            ChatParticipantType.ARTIST,
            artist_id,
        )

    async def join_fan(
        self,
        db: AsyncSession,
        room_id: str,
        fan_id: str,
    ) -> ChatParticipant:
        room = await self._room(db, room_id)
        await self._authorize_fan(db, room, fan_id)
        return await self._join(
            db,
            room,
            ChatParticipantType.FAN,
            fan_id,
        )

    async def send_artist_message(
        self,
        db: AsyncSession,
        room_id: str,
        artist_id: str,
        client_message_id: str,
        body: str,
    ) -> dict:
        room = await self._room(db, room_id, lock=True)
        if room.artist_id != artist_id:
            raise HTTPException(404, "Chat room not found")
        participant = await self._active_participant(
            db,
            room.id,
            ChatParticipantType.ARTIST,
            artist_id,
        )
        return await self._send(
            db, room, participant, client_message_id, body
        )

    async def send_fan_message(
        self,
        db: AsyncSession,
        room_id: str,
        fan_id: str,
        client_message_id: str,
        body: str,
    ) -> dict:
        room = await self._room(db, room_id, lock=True)
        await self._authorize_fan(db, room, fan_id)
        participant = await self._active_participant(
            db,
            room.id,
            ChatParticipantType.FAN,
            fan_id,
        )
        return await self._send(
            db, room, participant, client_message_id, body
        )

    async def list_for_artist(
        self,
        db: AsyncSession,
        room_id: str,
        artist_id: str,
        after_sequence: int | None,
        limit: int,
    ) -> dict:
        room = await self._room(db, room_id)
        if room.artist_id != artist_id:
            raise HTTPException(404, "Chat room not found")
        return await self._list(db, room, after_sequence, limit)

    async def list_for_fan(
        self,
        db: AsyncSession,
        room_id: str,
        fan_id: str,
        after_sequence: int | None,
        limit: int,
    ) -> dict:
        room = await self._room(db, room_id)
        await self._authorize_fan(db, room, fan_id)
        await self._active_participant(
            db,
            room.id,
            ChatParticipantType.FAN,
            fan_id,
        )
        return await self._list(db, room, after_sequence, limit)

    async def _send(self, db: AsyncSession, room: ChatRoom, participant: ChatParticipant,
        client_message_id: str, body: str,) -> dict:
        normalized_body = body.strip()
        if not normalized_body:
            raise HTTPException(422, "Message body cannot be blank")

        existing = (
            await db.execute(
                select(ChatMessage).where(
                    ChatMessage.chat_room_id == room.id,
                    ChatMessage.client_message_id == client_message_id,
                    )
            )
        ).scalar_one_or_none()
        if existing:
            return await self._message_response(db, existing)

        next_sequence = (
                            await db.scalar(
                                select(func.coalesce(func.max(ChatMessage.sequence_number), 0))
                                .where(ChatMessage.chat_room_id == room.id)
                            )
                        ) + 1

        message = ChatMessage(chat_room_id=room.id, sender_participant_id=participant.id, sequence_number=next_sequence,
                              message_type=ChatMessageType.TEXT, body=normalized_body, status=ChatMessageStatus.PENDING,
                              client_message_id=client_message_id, moderation_required=room.moderation_enabled,)
        db.add(message)
        await db.flush()

        started = time.perf_counter()
        provider = get_moderation_provider()
        result = await provider.evaluate(
            ModerationRequest(
                text=normalized_body,
                room_id=str(room.id),
                sender_type=participant.participant_type,
                sender_id=participant.participant_id,
                warning_count=participant.warning_count,
                policy_version=room.moderation_policy_version,
            )
        )
        processing_ms = round((time.perf_counter() - started) * 1000)

        decision = ModerationDecision(
            chat_message_id=message.id,
            moderation_provider=result.provider,
            moderation_model_version=result.model_version,
            policy_version=room.moderation_policy_version,
            decision=result.decision,
            categories=result.categories,
            severity=result.severity,
            confidence=result.confidence,
            reason_code=result.reason_code,
            policy_rule=result.policy_rule,
            provider_request_id=result.provider_request_id,
            provider_payload=result.provider_payload,
            processing_milliseconds=processing_ms,
        )
        db.add(decision)

        if result.decision != (ModerationDecisionType.ALLOW):
            incident = ModerationIncident(
                chat_room_id=room.id, participant_id=participant.id, chat_message_id=message.id,
                incident_type=(ModerationIncidentType.ABUSE),
                action=(ModerationAction.WARNING),
                status=(ModerationIncidentStatus.OPEN),
                evidence_snapshot=message.body,
                reason_code=result.reason_code,
            )
            db.add(incident)

            if (participant.warning_count >= settings.chat_warning_threshold):
                participant.status = (ChatParticipantStatus.MUTED)
                participant.muted_until = (datetime.now(timezone.utc) + timedelta(minutes=settings.chat_mute_minutes))
                mute_incident = ModerationIncident(
                    chat_room_id=room.id,
                    participant_id=participant.id,
                    chat_message_id=message.id,
                    incident_type=ModerationIncidentType.ABUSE,
                    action=ModerationAction.TEMPORARY_MUTE,
                    status=ModerationIncidentStatus.OPEN,
                    evidence_snapshot=message.body,
                    reason_code="WARNING_THRESHOLD_REACHED",
                    warning_number=participant.warning_count + 1,
                )
                participant.warning_count += 1
                db.add(mute_incident)

        if result.decision == ModerationDecisionType.ALLOW:
            message.status = ChatMessageStatus.VISIBLE
        else:
            message.status = ChatMessageStatus.BLOCKED

        participant.last_seen_at = datetime.now(timezone.utc)

        await db.commit()
        await db.refresh(message)

        response = await self._message_response(
            db,
            message,
        )

        if message.status == ChatMessageStatus.VISIBLE:
            delivered = await chat_connection_manager.broadcast(room_id=str(room.id),
                event={"type": "message.created", "room_id": str(room.id), "sequence_number": message.sequence_number,
                    "message": response,},)

            print("CHAT BROADCAST:", str(room.id), "delivered=", delivered,)

        return response

    async def _list(self, db: AsyncSession, room: ChatRoom, after_sequence: int | None,
        limit: int,) -> dict:
        query = (
            select(ChatMessage)
            .where(
                ChatMessage.chat_room_id == room.id,
                ChatMessage.status == ChatMessageStatus.VISIBLE,
            )
            .order_by(ChatMessage.sequence_number.asc())
            .limit(limit)
        )
        if after_sequence is not None:
            query = query.where(
                ChatMessage.sequence_number > after_sequence
            )

        rows = (await db.execute(query)).scalars().all()
        messages = [
            await self._message_response(db, row)
            for row in rows
        ]
        return {
            "room_id": room.id,
            "messages": messages,
            "next_after_sequence": (
                rows[-1].sequence_number if rows else after_sequence
            ),
        }

    async def _join(
        self,
        db: AsyncSession,
        room: ChatRoom,
        participant_type: ChatParticipantType,
        participant_id: str,
    ) -> ChatParticipant:
        existing = (
            await db.execute(
                select(ChatParticipant).where(
                    ChatParticipant.chat_room_id == room.id,
                    ChatParticipant.participant_type == participant_type,
                    ChatParticipant.participant_id == participant_id,
                )
            )
        ).scalar_one_or_none()

        if existing:
            if existing.status in {
                ChatParticipantStatus.SUSPENDED,
                ChatParticipantStatus.REMOVED,
            }:
                raise HTTPException(403, "Chat participation is not permitted")
            existing.status = ChatParticipantStatus.ACTIVE
            existing.last_seen_at = datetime.now(timezone.utc)
            await db.commit()
            await db.refresh(existing)
            return existing

        participant = ChatParticipant(
            chat_room_id=room.id,
            participant_type=participant_type,
            participant_id=participant_id,
            status=ChatParticipantStatus.ACTIVE,
            last_seen_at=datetime.now(timezone.utc),
        )
        db.add(participant)
        await db.commit()
        await db.refresh(participant)
        return participant

    async def _authorize_fan(
        self,
        db: AsyncSession,
        room: ChatRoom,
        fan_id: str,
    ) -> None:
        if room.room_type != ChatRoomType.LIVE_EVENT or not room.live_event_id:
            raise HTTPException(409, "This chat room is not a live-event room")

        now = datetime.now(timezone.utc)
        entitlement = (
            await db.execute(
                select(Entitlement).where(
                    Entitlement.event_id == room.live_event_id,
                    Entitlement.fan_id == fan_id,
                    Entitlement.status == EntitlementStatus.ACTIVE,
                    Entitlement.valid_from <= now,
                    or_(
                        Entitlement.valid_until.is_(None),
                        Entitlement.valid_until > now,
                    ),
                )
            )
        ).scalars().first()
        if not entitlement:
            raise HTTPException(
                403,
                "An active live-event entitlement is required for chat",
            )

    async def _active_participant(self, db: AsyncSession, room_id: uuid.UUID, participant_type: ChatParticipantType, participant_id: str,) -> ChatParticipant:
        participant = (await db.execute(select(ChatParticipant).where(ChatParticipant.chat_room_id == room_id,
                    ChatParticipant.participant_type == participant_type, ChatParticipant.participant_id == participant_id,))
        ).scalar_one_or_none()

        if not participant:
            raise HTTPException(409, "Join the chat room before posting")

        if participant.status == ChatParticipantStatus.MUTED:
            now = datetime.now(timezone.utc)
            if (participant.muted_until and now >= participant.muted_until):
                participant.status = (ChatParticipantStatus.ACTIVE)

                participant.muted_until = None

                await db.commit()
                await db.refresh(participant)

            else:
                raise HTTPException(403, "Chat participant is muted")

        if participant.status == ChatParticipantStatus.REMOVED:
            raise HTTPException(403, "Chat participant was removed")

        if participant.status == ChatParticipantStatus.SUSPENDED:
            raise HTTPException(403, "Chat participant is suspended")

        if participant.status != ChatParticipantStatus.ACTIVE:
            raise HTTPException(403, "Chat participation is not active")

        return participant

    async def _room(self, db: AsyncSession, room_id: str, lock: bool = False,) -> ChatRoom:
        room_key = self._uuid(room_id, "Chat room not found")
        query = select(ChatRoom).where(ChatRoom.id == room_key)
        if lock:
            query = query.with_for_update()
        room = (await db.execute(query)).scalar_one_or_none()
        if not room:
            raise HTTPException(404, "Chat room not found")
        if room.status != ChatRoomStatus.OPEN:
            raise HTTPException(409, "Chat room is not open")
        return room

    async def _message_response(
        self,
        db: AsyncSession,
        message: ChatMessage,
    ) -> dict:
        participant = await db.get(
            ChatParticipant,
            message.sender_participant_id,
        )
        decision = (
            await db.execute(
                select(ModerationDecision).where(
                    ModerationDecision.chat_message_id == message.id
                )
            )
        ).scalar_one_or_none()
        if not participant or not decision:
            raise HTTPException(500, "Chat message metadata is incomplete")

        return {
            "id": message.id,
            "chat_room_id": message.chat_room_id,
            "sender_participant_id": message.sender_participant_id,
            "sender_type": participant.participant_type.value,
            "sender_id": participant.participant_id,
            "sequence_number": message.sequence_number,
            "message_type": message.message_type.value,
            "body": message.body,
            "status": message.status.value,
            "client_message_id": message.client_message_id,
            "created_at": message.created_at,
            "moderation_decision": decision.decision.value,
        }

    async def get_live_event_room(self, db: AsyncSession, artist_id: str, event_id: str,) -> ChatRoom:
        event_key = self._uuid(event_id, "Event not found",)
        event = await db.get(LiveEvent, event_key,)
        if (not event or event.artist_id != artist_id):
            raise HTTPException(404, "Event not found",)

        room = (await db.execute(select(ChatRoom).where(ChatRoom.live_event_id == event.id))).scalar_one_or_none()

        if room:
            return room

        return await self.create_live_event_room(db=db, artist_id=artist_id, event_id=event_id,)

    async def get_live_event_room_for_fan(self, db: AsyncSession, fan_id: str, event_id: str,) -> ChatRoom:
        event_key = self._uuid(event_id, "Event not found")
        event = await db.get(LiveEvent, event_key)
        if not event:
            raise HTTPException(404, "Event not found")

        room = (await db.execute(select(ChatRoom).where(ChatRoom.live_event_id == event.id))
        ).scalar_one_or_none()

        if not room:
            raise HTTPException(404, "Chat room not found")

        await self._authorize_fan(db, room, fan_id)
        return room

    @staticmethod
    def _uuid(value: str, detail: str) -> uuid.UUID:
        try:
            return uuid.UUID(str(value))
        except ValueError as exc:
            raise HTTPException(404, detail) from exc

chat_service = ChatService()
