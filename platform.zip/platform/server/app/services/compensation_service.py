import json
import uuid
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.compensation import (
    CompensationAudit,
    CompensationCase,
    CompensationStatus,
    CompensationType,
)
from app.models.entitlement import Entitlement, EntitlementStatus
from app.models.event_change import DeliveryStatus, EventNotification
from app.models.incident import (
    IncidentStatus,
    RefundCandidate,
    RefundCandidateStatus,
    StreamIncident,
)
from app.models.ticket import TicketPurchase, TicketStatus
from app.services.payment_provider import payment_provider
from app.services.session_registry import session_registry


class CompensationService:
    async def approve_incident(self, db: AsyncSession, incident_id: str, operator_id: str) -> dict:
        incident = await self._incident(db, incident_id)
        if incident.status not in (IncidentStatus.REVIEW_REQUIRED, IncidentStatus.RECOVERED):
            raise HTTPException(409, "Incident is not eligible for compensation approval")

        candidates = (await db.execute(
            select(RefundCandidate).where(
                RefundCandidate.incident_id == incident.id,
                RefundCandidate.status.in_([
                    RefundCandidateStatus.PENDING_REVIEW,
                    RefundCandidateStatus.APPROVED,
                ]),
            ).with_for_update()
        )).scalars().all()

        approved = skipped = queued = 0
        for candidate in candidates:
            existing = (await db.execute(select(CompensationCase).where(
                CompensationCase.candidate_id == candidate.id
            ))).scalar_one_or_none()
            if existing:
                skipped += 1
                continue

            ticket = await db.get(TicketPurchase, candidate.ticket_id)
            if not ticket or ticket.status != TicketStatus.PAID:
                skipped += 1
                continue

            candidate.status = RefundCandidateStatus.APPROVED
            case = CompensationCase(
                incident_id=incident.id,
                candidate_id=candidate.id,
                ticket_id=ticket.id,
                event_id=ticket.event_id,
                fan_id=ticket.fan_id,
                compensation_type=CompensationType.REFUND,
                amount_cents=ticket.amount_cents,
                currency=ticket.currency,
                idempotency_key=f"outage-compensation:{incident.id}:{ticket.id}",
                status=CompensationStatus.QUEUED,
                approved_by=operator_id,
            )
            db.add(case)
            await db.flush()
            db.add(CompensationAudit(
                compensation_case_id=case.id,
                action="APPROVED_AND_QUEUED",
                actor=operator_id,
                details=json.dumps({"incident_id": str(incident.id), "ticket_id": str(ticket.id)}),
            ))
            approved += 1
            queued += 1

        try:
            await db.commit()
        except IntegrityError:
            await db.rollback()
            raise HTTPException(409, "Compensation approval was processed concurrently")

        return {"incident_id": incident.id, "approved": approved, "skipped": skipped, "queued": queued}

    async def reject_incident(self, db: AsyncSession, incident_id: str, operator_id: str, reason: str) -> dict:
        incident = await self._incident(db, incident_id)
        result = await db.execute(select(RefundCandidate).where(
            RefundCandidate.incident_id == incident.id,
            RefundCandidate.status == RefundCandidateStatus.PENDING_REVIEW,
        ).with_for_update())
        candidates = result.scalars().all()
        for candidate in candidates:
            candidate.status = RefundCandidateStatus.REJECTED
        incident.status = IncidentStatus.CLOSED
        await db.commit()
        return {"incident_id": str(incident.id), "rejected": len(candidates), "operator_id": operator_id, "reason": reason}

    async def dispatch(self, db: AsyncSession, batch_size: int) -> dict:
        cases = (await db.execute(select(CompensationCase).where(
            CompensationCase.status.in_([CompensationStatus.QUEUED, CompensationStatus.FAILED])
        ).order_by(CompensationCase.approved_at).limit(batch_size).with_for_update(skip_locked=True))).scalars().all()

        completed = failed = skipped = 0
        for case in cases:
            ticket = await db.get(TicketPurchase, case.ticket_id)
            candidate = await db.get(RefundCandidate, case.candidate_id)
            if not ticket or not candidate:
                case.status = CompensationStatus.MANUAL_REVIEW
                case.failure_reason = "Ticket or refund candidate not found"
                skipped += 1
                continue

            if ticket.status == TicketStatus.REFUNDED:
                case.status = CompensationStatus.COMPLETED
                case.completed_at = case.completed_at or datetime.now(timezone.utc)
                candidate.status = RefundCandidateStatus.REFUNDED
                skipped += 1
                continue

            case.status = CompensationStatus.PROCESSING
            await db.flush()
            try:
                confirmed = await payment_provider.refund(
                    payment_id=ticket.provider_payment_id,
                    idempotency_key=case.idempotency_key,
                )
                if not confirmed:
                    raise RuntimeError("Payment provider did not confirm compensation refund")

                ticket.status = TicketStatus.REFUNDED
                ticket.refunded_at = datetime.now(timezone.utc)
                candidate.status = RefundCandidateStatus.REFUNDED
                case.status = CompensationStatus.COMPLETED
                case.provider_reference = ticket.provider_payment_id
                case.completed_at = datetime.now(timezone.utc)
                case.failure_reason = None

                entitlement = await db.get(Entitlement, ticket.entitlement_id)
                if entitlement and entitlement.status == EntitlementStatus.ACTIVE:
                    entitlement.status = EntitlementStatus.REVOKED
                if ticket.entitlement_id:
                    await session_registry.release_all(str(ticket.entitlement_id))

                db.add(EventNotification(
                    event_id=ticket.event_id,
                    fan_id=ticket.fan_id,
                    kind="OUTAGE_COMPENSATION_COMPLETED",
                    payload=json.dumps({
                        "incident_id": str(case.incident_id),
                        "ticket_id": str(ticket.id),
                        "amount_cents": case.amount_cents,
                        "currency": case.currency,
                    }),
                    status=DeliveryStatus.PENDING,
                ))
                db.add(CompensationAudit(
                    compensation_case_id=case.id,
                    action="REFUND_COMPLETED",
                    actor="compensation-dispatcher",
                    details=json.dumps({"provider_payment_id": ticket.provider_payment_id}),
                ))
                completed += 1
            except Exception as exc:
                case.status = CompensationStatus.FAILED
                case.failure_reason = str(exc)[:2000]
                db.add(CompensationAudit(
                    compensation_case_id=case.id,
                    action="REFUND_FAILED",
                    actor="compensation-dispatcher",
                    details=case.failure_reason,
                ))
                failed += 1

        await db.commit()
        return {"completed": completed, "failed": failed, "skipped": skipped}

    async def reconcile(self, db: AsyncSession, batch_size: int) -> dict:
        cases = (await db.execute(select(CompensationCase).where(
            CompensationCase.status.in_([
                CompensationStatus.PROCESSING,
                CompensationStatus.FAILED,
                CompensationStatus.COMPLETED,
            ])
        ).order_by(CompensationCase.approved_at).limit(batch_size).with_for_update(skip_locked=True))).scalars().all()

        examined = corrected = manual_review = 0
        for case in cases:
            examined += 1
            case.reconciliation_attempts += 1
            ticket = await db.get(TicketPurchase, case.ticket_id)
            candidate = await db.get(RefundCandidate, case.candidate_id)
            if not ticket or not candidate:
                case.status = CompensationStatus.MANUAL_REVIEW
                case.failure_reason = "Reconciliation could not locate ticket/candidate"
                manual_review += 1
                continue

            if ticket.status == TicketStatus.REFUNDED:
                changed = case.status != CompensationStatus.COMPLETED or candidate.status != RefundCandidateStatus.REFUNDED
                case.status = CompensationStatus.COMPLETED
                case.completed_at = case.completed_at or ticket.refunded_at or datetime.now(timezone.utc)
                candidate.status = RefundCandidateStatus.REFUNDED
                if changed:
                    corrected += 1
            elif case.status == CompensationStatus.COMPLETED:
                case.status = CompensationStatus.MANUAL_REVIEW
                case.failure_reason = "Case says completed but ticket is not refunded"
                manual_review += 1

            db.add(CompensationAudit(
                compensation_case_id=case.id,
                action="RECONCILED",
                actor="compensation-reconciler",
                details=json.dumps({"ticket_status": ticket.status.value, "case_status": case.status.value}),
            ))

        await db.commit()
        return {"examined": examined, "corrected": corrected, "manual_review": manual_review}

    async def list_cases(self, db: AsyncSession, incident_id: str):
        incident = await self._incident(db, incident_id)
        return (await db.execute(select(CompensationCase).where(
            CompensationCase.incident_id == incident.id
        ).order_by(CompensationCase.approved_at))).scalars().all()

    async def summary(self, db: AsyncSession, incident_id: str) -> dict:
        incident = await self._incident(db, incident_id)

        async def candidate_count(status):
            return (await db.scalar(select(func.count()).select_from(RefundCandidate).where(
                RefundCandidate.incident_id == incident.id,
                RefundCandidate.status == status,
            ))) or 0

        async def case_count(status):
            return (await db.scalar(select(func.count()).select_from(CompensationCase).where(
                CompensationCase.incident_id == incident.id,
                CompensationCase.status == status,
            ))) or 0

        return {
            "incident_id": incident.id,
            "candidates_pending": await candidate_count(RefundCandidateStatus.PENDING_REVIEW),
            "candidates_approved": await candidate_count(RefundCandidateStatus.APPROVED),
            "candidates_rejected": await candidate_count(RefundCandidateStatus.REJECTED),
            "candidates_refunded": await candidate_count(RefundCandidateStatus.REFUNDED),
            "cases_queued": await case_count(CompensationStatus.QUEUED),
            "cases_completed": await case_count(CompensationStatus.COMPLETED),
            "cases_failed": await case_count(CompensationStatus.FAILED),
            "cases_manual_review": await case_count(CompensationStatus.MANUAL_REVIEW),
        }

    @staticmethod
    async def _incident(db: AsyncSession, incident_id: str) -> StreamIncident:
        try:
            key = uuid.UUID(incident_id)
        except ValueError:
            raise HTTPException(404, "Incident not found")
        incident = await db.get(StreamIncident, key)
        if not incident:
            raise HTTPException(404, "Incident not found")
        return incident


compensation_service = CompensationService()
