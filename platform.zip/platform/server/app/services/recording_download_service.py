import os
import uuid
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import httpx
from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.live_event import LiveEvent
from app.models.live_recording import (
    LiveRecording,
    LiveRecordingSpan,
    LiveRecordingSpanStatus,
)


class RecordingDownloadService:
    async def download(
        self,
        db: AsyncSession,
        artist_id: str,
        event_id: str,
    ) -> dict:
        event_key = self._parse_uuid(event_id)

        event = await db.get(LiveEvent, event_key)
        if not event or event.artist_id != artist_id:
            raise HTTPException(404, "Event not found")

        if event.finalized_at is None:
            raise HTTPException(
                409,
                "The performance must be finalized before recordings are downloaded",
            )

        recording = (
            await db.execute(
                select(LiveRecording).where(
                    LiveRecording.live_event_id == event.id
                )
            )
        ).scalar_one_or_none()

        if not recording:
            raise HTTPException(
                409,
                "The finalized event has no recording lifecycle record",
            )

        spans = (
            await db.execute(
                select(LiveRecordingSpan)
                .where(LiveRecordingSpan.live_recording_id == recording.id)
                .order_by(LiveRecordingSpan.started_at.asc())
            )
        ).scalars().all()

        if not spans:
            raise HTTPException(
                409,
                "No recording spans have been discovered",
            )

        work_root = Path(settings.replay_work_root).resolve()
        recording_directory = work_root / str(recording.id)
        recording_directory.mkdir(parents=True, exist_ok=True)

        downloaded = 0
        existing = 0
        failed = 0
        failures: list[dict] = []

        async with httpx.AsyncClient(
            timeout=httpx.Timeout(
                connect=30.0,
                read=settings.replay_download_timeout_seconds,
                write=30.0,
                pool=30.0,
            ),
            follow_redirects=True,
        ) as client:
            for index, span in enumerate(spans, start=1):
                destination = recording_directory / self._file_name(index, span)

                if (
                    span.status in {
                        LiveRecordingSpanStatus.DOWNLOADED,
                        LiveRecordingSpanStatus.MERGED,
                    }
                    and span.local_path
                    and Path(span.local_path).is_file()
                ):
                    existing += 1
                    continue

                span.status = LiveRecordingSpanStatus.DOWNLOADING
                span.failure_reason = None
                await db.commit()

                try:
                    await self._download_span(
                        client=client,
                        source_url=span.source_url,
                        destination=destination,
                    )

                    span.local_path = str(destination)
                    span.status = LiveRecordingSpanStatus.DOWNLOADED
                    span.failure_reason = None
                    await db.commit()
                    downloaded += 1

                except Exception as exc:
                    await db.rollback()

                    refreshed_span = await db.get(LiveRecordingSpan, span.id)
                    if refreshed_span:
                        refreshed_span.status = LiveRecordingSpanStatus.FAILED
                        refreshed_span.failure_reason = str(exc)[:4000]
                        await db.commit()

                    failed += 1
                    failures.append(
                        {
                            "span_id": str(span.id),
                            "error": str(exc),
                        }
                    )

        return {
            "recording_id": recording.id,
            "event_id": recording.live_event_id,
            "stream_path": recording.stream_path,
            "total_spans": len(spans),
            "downloaded": downloaded,
            "existing": existing,
            "failed": failed,
            "work_directory": str(recording_directory),
            "failures": failures,
        }

    async def _download_span(
        self,
        client: httpx.AsyncClient,
        source_url: str,
        destination: Path,
    ) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(destination.suffix + ".part")

        if temporary.exists():
            temporary.unlink()

        download_url = self._standard_mp4_url(source_url)

        try:
            async with client.stream("GET", download_url) as response:
                if not response.is_success:
                    body = (await response.aread()).decode(
                        "utf-8",
                        errors="replace",
                    )
                    raise RuntimeError(
                        "MediaMTX span download failed with status "
                        f"{response.status_code}: {body[:500]}"
                    )

                content_type = response.headers.get("content-type", "")
                if content_type and not (
                    content_type.startswith("video/")
                    or content_type.startswith("application/octet-stream")
                ):
                    raise RuntimeError(
                        "MediaMTX returned an unexpected content type: "
                        f"{content_type}"
                    )

                with temporary.open("wb") as output:
                    async for chunk in response.aiter_bytes(1024 * 1024):
                        output.write(chunk)

            if not temporary.exists() or temporary.stat().st_size <= 0:
                raise RuntimeError("Downloaded recording span is empty")

            os.replace(temporary, destination)

        except Exception:
            if temporary.exists():
                temporary.unlink()
            raise

    @staticmethod
    def _standard_mp4_url(source_url: str) -> str:
        parsed = urlsplit(source_url)
        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
        query["format"] = "mp4"

        return urlunsplit(
            (
                parsed.scheme,
                parsed.netloc,
                parsed.path,
                urlencode(query),
                parsed.fragment,
            )
        )

    @staticmethod
    def _file_name(index: int, span: LiveRecordingSpan) -> str:
        timestamp = span.started_at.strftime("%Y%m%dT%H%M%S_%fZ")
        return f"{index:04d}_{timestamp}.mp4"

    @staticmethod
    def _parse_uuid(value: str) -> uuid.UUID:
        try:
            return uuid.UUID(str(value))
        except ValueError as exc:
            raise HTTPException(404, "Event not found") from exc


recording_download_service = RecordingDownloadService()
