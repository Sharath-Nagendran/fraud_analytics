import uuid
from datetime import datetime, timezone, timedelta
from fastapi import HTTPException
from sqlalchemy import func, select
from app.models.incident import IncidentStatus, RefundCandidate, RefundCandidateStatus, StreamIncident
from app.models.live_event import LiveEvent, LiveEventStatus
from app.models.ticket import TicketPurchase, TicketStatus
from app.services.session_registry import session_registry
class HealthService:
    OUTAGE_REVIEW_THRESHOLD_SECONDS=300
    AFFECTED_REVIEW_THRESHOLD_PERCENT=20
    async def health(self,db,event_id):
        event=await self._event(db,event_id)
        open_count=(await db.scalar(select(func.count()).where(StreamIncident.event_id==event.id,StreamIncident.status==IncidentStatus.OPEN))) or 0
        last=await db.scalar(select(func.max(StreamIncident.started_at)).where(StreamIncident.event_id==event.id))
        active=await self._active_count()
        health="ARCHIVED" if event.status==LiveEventStatus.ARCHIVED else ("OUTAGE" if open_count else ("GOOD" if event.status==LiveEventStatus.LIVE else "IDLE"))
        return {"event_id":event.id,"event_status":event.status.value,"stream_health":health,"active_sessions":active,"open_incidents":open_count,"last_incident_at":last}
    async def simulate_outage(self,db,event_id,payload):
        event=await self._event(db,event_id)
        if event.status!=LiveEventStatus.LIVE: raise HTTPException(409,"Only a live event can have a simulated outage")
        review=payload.duration_seconds>=self.OUTAGE_REVIEW_THRESHOLD_SECONDS and payload.affected_viewer_percent>=self.AFFECTED_REVIEW_THRESHOLD_PERCENT
        incident=StreamIncident(event_id=event.id,kind="SIMULATED_OUTAGE",status=IncidentStatus.REVIEW_REQUIRED if review else IncidentStatus.RECOVERED,started_at=datetime.now(timezone.utc)-timedelta(seconds=payload.duration_seconds),recovered_at=datetime.now(timezone.utc),duration_seconds=payload.duration_seconds,details=payload.details)
        db.add(incident);await db.flush();count=0
        if review:
            tickets=(await db.execute(select(TicketPurchase).where(TicketPurchase.event_id==event.id,TicketPurchase.status==TicketStatus.PAID))).scalars().all()
            for ticket in tickets:
                db.add(RefundCandidate(incident_id=incident.id,ticket_id=ticket.id));count+=1
        await db.commit()
        return {"incident_id":incident.id,"status":incident.status.value,"refund_review_required":review,"refund_candidates":count}
    async def decide_candidate(self,db,candidate_id,decision):
        try:key=uuid.UUID(candidate_id)
        except ValueError:raise HTTPException(404,"Refund candidate not found")
        candidate=await db.get(RefundCandidate,key)
        if not candidate:raise HTTPException(404,"Refund candidate not found")
        if candidate.status!=RefundCandidateStatus.PENDING_REVIEW:raise HTTPException(409,"Refund candidate was already decided")
        candidate.status=RefundCandidateStatus(decision);await db.commit()
        return {"candidate_id":str(candidate.id),"status":candidate.status.value,"note":"Approval records a decision only; it does not execute a financial refund."}
    async def _active_count(self):
        if hasattr(session_registry,"active_count"):return await session_registry.active_count()
        return sum(len(v) for v in getattr(session_registry,"_sessions",{}).values())
    @staticmethod
    async def _event(db,event_id):
        try:key=uuid.UUID(event_id)
        except ValueError:raise HTTPException(404,"Event not found")
        event=await db.get(LiveEvent,key)
        if not event:raise HTTPException(404,"Event not found")
        return event
health_service=HealthService()
