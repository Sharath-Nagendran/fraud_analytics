import secrets, uuid
from datetime import datetime, timezone
from fastapi import HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.config import settings
from app.models.live_event import LiveEvent, LiveEventStatus
from app.services.playback_service import playback_service
from app.services.session_registry import SessionLimitExceeded, session_registry
from app.services.metrics_service import metrics_service


class ArchiveService:
    async def archive_mock(self, db: AsyncSession, event_id: str) -> LiveEvent:
        if not settings.mux_stub_mode: raise HTTPException(404, "Not found")
        event = await self._event(db, event_id)
        if event.status == LiveEventStatus.ARCHIVED: return event
        if event.status not in (LiveEventStatus.ENDED, LiveEventStatus.LIVE):
            raise HTTPException(409, "Only a live or ended event can be archived")
        suffix = secrets.token_hex(12)
        event.mux_asset_id = event.mux_asset_id or f"mock-vod-asset-{suffix}"
        event.mux_vod_playback_id = event.mux_vod_playback_id or f"mock-vod-playback-{suffix}"
        event.archived_at = datetime.now(timezone.utc)
        event.status = LiveEventStatus.ARCHIVED
        await db.commit(); await db.refresh(event)
        return event

    async def mark_asset_ready(self, db, event_id, asset_id, playback_id):
        event = await self._event(db, event_id)
        if event.status not in (LiveEventStatus.ENDED, LiveEventStatus.ARCHIVED):
            raise HTTPException(409, "Event must be ended before archival completes")
        event.mux_asset_id = asset_id
        event.mux_vod_playback_id = playback_id
        event.archived_at = event.archived_at or datetime.now(timezone.utc)
        event.status = LiveEventStatus.ARCHIVED
        await db.commit(); await db.refresh(event)
        return event

    async def details(self, db, event_id):
        event = await self._event(db, event_id)
        return {"event_id": event.id, "status": event.status.value,
                "available": event.status == LiveEventStatus.ARCHIVED and bool(event.mux_vod_playback_id),
                "archived_at": event.archived_at}

    async def token(self, db, event_id, fan_id, requested_session_id):
        event = await self._event(db, event_id)
        if event.status != LiveEventStatus.ARCHIVED or not event.mux_vod_playback_id:
            raise HTTPException(409, "Replay is not available")
        entitlement = await playback_service.entitlement(db, fan_id, event.id, "REPLAY")
        try:
            lease = await session_registry.acquire(str(entitlement.id), requested_session_id)
        except SessionLimitExceeded:
            metrics_service.counters["denied"] += 1
            raise HTTPException(409, "Concurrent playback session limit reached")
        grant = playback_service.provider.issue(event.mux_vod_playback_id, lease.session_id,
                                                settings.playback_token_ttl_seconds)
        metrics_service.counters["issued"] += 1
        return {"event_id": event.id, "playback_id": event.mux_vod_playback_id,
                "token": grant.token, "expires_at": grant.expires_at,
                "refresh_after_seconds": settings.playback_token_refresh_seconds,
                "session_id": lease.session_id, "mode": grant.mode}

    @staticmethod
    async def _event(db, event_id):
        try: key = uuid.UUID(event_id)
        except ValueError: raise HTTPException(404, "Event not found")
        event = await db.get(LiveEvent, key)
        if not event: raise HTTPException(404, "Event not found")
        return event


archive_service = ArchiveService()
