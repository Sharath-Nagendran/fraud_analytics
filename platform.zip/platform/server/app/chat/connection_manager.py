import asyncio
import uuid
from dataclasses import dataclass
from typing import Any
from fastapi.encoders import jsonable_encoder

from fastapi import WebSocket
from starlette.websockets import WebSocketState


@dataclass(frozen=True)
class ChatConnection:
    connection_id: str
    participant_id: str
    participant_type: str
    websocket: WebSocket


class ChatConnectionManager:
    def __init__(self) -> None:
        self._rooms: dict[str, dict[str, ChatConnection]] = {}
        self._lock = asyncio.Lock()

    async def connect(self, room_id: str, participant_id: str, participant_type: str,
        websocket: WebSocket,) -> ChatConnection:
        await websocket.accept()

        connection = ChatConnection(connection_id=str(uuid.uuid4()), participant_id=participant_id,
            participant_type=participant_type, websocket=websocket,)

        async with self._lock:
            room = self._rooms.setdefault(room_id, {})
            room[connection.connection_id] = connection
            print("CHAT CONNECT:", room_id, participant_id, "connections=", len(self._rooms.get(room_id, {})),
                "manager=", id(self),)
        return connection

    async def disconnect(self, room_id: str, connection_id: str,) -> None:
        async with self._lock:
            room = self._rooms.get(room_id)
            if not room:
                return

            room.pop(connection_id, None)
            if not room:
                self._rooms.pop(room_id, None)

    async def broadcast(self, room_id: str, event: dict[str, Any],) -> int:

        async with self._lock:
            connections = list(self._rooms.get(room_id,{},).values())

        print("CHAT BROADCAST MANAGER:", room_id, "connections=", len(connections), "manager=", id(self),)

        json_event = jsonable_encoder(event)

        delivered = 0
        dead_connection_ids: list[str] = []

        for connection in connections:
            try:
                if (connection.websocket.application_state != WebSocketState.CONNECTED):
                    dead_connection_ids.append(connection.connection_id)
                    continue

                await connection.websocket.send_json(json_event)

                delivered += 1

            except Exception as exc:
                print("CHAT BROADCAST FAILURE:", room_id, connection.participant_id, type(exc).__name__, repr(exc),)
                dead_connection_ids.append(connection.connection_id)

        for connection_id in dead_connection_ids:
            await self.disconnect(room_id, connection_id,)

        print("CHAT BROADCAST COMPLETE:", room_id, "delivered=", delivered, "removed=", len(dead_connection_ids),)

        return delivered

    async def count(self, room_id: str) -> int:
        async with self._lock:
            return len(self._rooms.get(room_id, {}))


chat_connection_manager = ChatConnectionManager()
