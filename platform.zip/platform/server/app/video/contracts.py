from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class CreateStreamCommand:
    event_id: str
    reconnect_window_seconds: int
    low_latency: bool
    playback_policy: str


@dataclass(frozen=True)
class LiveStreamResource:
    provider: str
    stream_id: str
    stream_key: str
    playback_id: str
    ingest_url: str
    playback_url: str


@dataclass(frozen=True)
class StreamStatusResource:
    provider: str
    stream_id: str
    status: str


class VideoProvider(Protocol):
    name: str

    async def create_live_stream(
        self,
        command: CreateStreamCommand,
    ) -> LiveStreamResource:
        ...

    async def complete_live_stream(
        self,
        stream_id: str,
    ) -> None:
        ...

    async def delete_live_stream(
        self,
        stream_id: str,
    ) -> None:
        ...

    async def get_asset_playback_id(
        self,
        asset_id: str,
    ) -> str:
        ...

    async def get_live_stream_status(
        self,
        stream_id: str,
    ) -> StreamStatusResource:
        ...