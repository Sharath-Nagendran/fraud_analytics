import uuid
from app.video.contracts import (CreateStreamCommand,LiveStreamResource,StreamStatusResource,)

class MockVideoProvider:
    name = "mock"

    async def create_live_stream(self, command: CreateStreamCommand) -> LiveStreamResource:
        stream_id = f"fake-{uuid.uuid4()}"
        playback_id = f"fake-playback-{stream_id}"
        return LiveStreamResource(
            provider=self.name,
            stream_id=stream_id,
            stream_key=f"fake-stream-key-{stream_id}",
            playback_id=playback_id,
            ingest_url="rtmps://example.invalid/live",
            playback_url=f"mock://{playback_id}",
        )

    async def complete_live_stream(self, stream_id: str) -> None:
        return None

    async def delete_live_stream(self, stream_id: str) -> None:
        return None

    async def get_asset_playback_id(self, asset_id: str) -> str:
        return f"mock-vod-playback-{asset_id}"

    async def get_live_stream_status(
            self,
            stream_id: str,
    ) -> StreamStatusResource:
        return StreamStatusResource(
            provider=self.name,
            stream_id=stream_id,
            status="idle",
        )
