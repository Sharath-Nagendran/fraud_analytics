import secrets
from urllib.parse import quote

import httpx

from app.core.config import settings
from app.video.contracts import (
    CreateStreamCommand,
    LiveStreamResource,
    StreamStatusResource,
)


class SelfHostVideoProvider:
    name = "selfhosted"

    def _client(self):
        return httpx.AsyncClient(
            timeout=10.0
        )

    async def create_live_stream(
        self,
        command: CreateStreamCommand,
    ) -> LiveStreamResource:

        stream_key = (
            f"live-{secrets.token_urlsafe(24)}"
        )

        playback_url = (
            f"{settings.selfhosted_hls_base_url}"
            f"/{stream_key}/index.m3u8"
        )

        return LiveStreamResource(
            provider=self.name,
            stream_id=stream_key,
            stream_key=stream_key,
            playback_id=stream_key,
            ingest_url=settings.selfhosted_rtmp_ingest_url,
            playback_url=playback_url,
        )

    async def complete_live_stream(
        self,
        stream_id: str,
    ) -> None:
        pass

    async def delete_live_stream(
        self,
        stream_id: str,
    ) -> None:
        pass

    async def get_asset_playback_id(
        self,
        asset_id: str,
    ) -> str:
        return asset_id

    async def get_live_stream_status(
        self,
        stream_id: str,
    ) -> StreamStatusResource:

        encoded = quote(
            stream_id,
            safe=""
        )

        async with self._client() as client:

            response = await client.get(
                f"{settings.selfhosted_api_base_url}"
                f"/v3/paths/get/{encoded}"
            )

        if response.status_code == 404:
            return StreamStatusResource(
                provider=self.name,
                stream_id=stream_id,
                status="idle",
            )

        response.raise_for_status()

        payload = response.json()

        if payload.get("ready"):

            return StreamStatusResource(
                provider=self.name,
                stream_id=stream_id,
                status="active",
            )

        return StreamStatusResource(
            provider=self.name,
            stream_id=stream_id,
            status="idle",
        )