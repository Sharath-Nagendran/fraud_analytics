import asyncio
import mux_python
from fastapi import HTTPException
from mux_python.rest import ApiException
from app.core.config import settings
from app.video.contracts import (CreateStreamCommand,LiveStreamResource,StreamStatusResource,)

class MuxVideoProvider:
    name = "mux"

    def __init__(self):
        configuration = mux_python.Configuration()
        configuration.username = settings.mux_token_id
        configuration.password = settings.mux_token_secret
        client = mux_python.ApiClient(configuration)
        self.live_api = mux_python.LiveStreamsApi(client)
        self.assets_api = mux_python.AssetsApi(client)

    async def create_live_stream(self, command: CreateStreamCommand) -> LiveStreamResource:
        def call():
            policy = [mux_python.PlaybackPolicy(command.playback_policy)]
            request = mux_python.CreateLiveStreamRequest(
                playback_policy=policy,
                new_asset_settings=mux_python.CreateAssetRequest(playback_policy=policy),
                passthrough=command.event_id,
                reconnect_window=command.reconnect_window_seconds,
                reduced_latency=command.low_latency,
            )
            return self.live_api.create_live_stream(request).data
        try:
            stream = await asyncio.to_thread(call)
        except ApiException as exc:
            raise HTTPException(502, f"Mux error ({exc.status}): {exc.body}") from exc
        playback_id = stream.playback_ids[0].id if stream.playback_ids else None
        if not stream.stream_key or not playback_id:
            raise HTTPException(502, "Mux did not return stream key and playback ID")
        return LiveStreamResource(
            provider=self.name,
            stream_id=stream.id,
            stream_key=stream.stream_key,
            playback_id=playback_id,
            ingest_url=settings.mux_ingest_url,
            playback_url=f"https://stream.mux.com/{playback_id}.m3u8",
        )

    async def complete_live_stream(self, stream_id: str) -> None:
        try:
            await asyncio.to_thread(self.live_api.signal_live_stream_complete, stream_id)
        except ApiException as exc:
            raise HTTPException(502, f"Mux completion error ({exc.status}): {exc.body}") from exc

    async def delete_live_stream(self, stream_id: str) -> None:
        try:
            await asyncio.to_thread(self.live_api.delete_live_stream, stream_id)
        except ApiException as exc:
            raise HTTPException(502, f"Mux delete error ({exc.status}): {exc.body}") from exc

    async def get_asset_playback_id(self, asset_id: str) -> str:
        try:
            asset = await asyncio.to_thread(self.assets_api.get_asset, asset_id)
        except ApiException as exc:
            raise HTTPException(502, f"Mux asset error ({exc.status}): {exc.body}") from exc
        playback_id = asset.data.playback_ids[0].id if asset.data.playback_ids else None
        if not playback_id:
            raise HTTPException(502, "Mux asset has no playback ID")
        return playback_id

    async def get_live_stream_status(
            self,
            stream_id: str,
    ) -> StreamStatusResource:
        def call():
            return self.live_api.get_live_stream(
                stream_id
            )

        try:
            response = await asyncio.to_thread(
                call
            )
        except ApiException as exc:
            raise HTTPException(
                status_code=502,
                detail=(
                    "Mux status error "
                    f"({exc.status}): {exc.body}"
                ),
            ) from exc

        stream = response.data

        provider_status = str(
            stream.status
            or "unknown"
        ).strip().lower()

        return StreamStatusResource(
            provider=self.name,
            stream_id=stream_id,
            status=provider_status,
        )
