import ssl
import httpx
from fastapi import HTTPException
from app.core.config import settings
from app.video.contracts import (CreateStreamCommand,LiveStreamResource,StreamStatusResource,)

class FastPixVideoProvider:
    name = "fastpix"

    def _ssl_context(self) -> ssl.SSLContext:
        if settings.fastpix_ca_bundle:
            return ssl.create_default_context(cafile=settings.fastpix_ca_bundle)
        return ssl.create_default_context()

    def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=settings.fastpix_api_base_url.rstrip("/"),
            auth=(settings.fastpix_token_id, settings.fastpix_secret_key),
            timeout=30.0,
            verify=self._ssl_context(),
            trust_env=True,
        )

    @staticmethod
    def _raise(response: httpx.Response, operation: str) -> None:
        if response.is_error:
            raise HTTPException(502, f"FastPix {operation} failed ({response.status_code}): {response.text}")

    async def create_live_stream(self, command: CreateStreamCommand) -> LiveStreamResource:
        payload = {
            "playbackSettings": {},
            "inputMediaSettings": {},
        }
        async with self._client() as client:
            response = await client.post("/live/streams", json=payload)
        self._raise(response, "create stream")
        data = (response.json().get("data") or {})
        playback_ids = data.get("playbackIds") or []
        playback_id = playback_ids[0].get("id") if playback_ids else None
        if not data.get("streamId") or not data.get("streamKey") or not playback_id:
            raise HTTPException(502, "FastPix response omitted streamId, streamKey, or playbackId")
        return LiveStreamResource(
            provider=self.name,
            stream_id=data["streamId"],
            stream_key=data["streamKey"],
            playback_id=playback_id,
            ingest_url=settings.fastpix_ingest_url,
            playback_url=f"{settings.fastpix_playback_base_url.rstrip('/')}/{playback_id}.m3u8",
        )

    async def complete_live_stream(self, stream_id: str) -> None:
        async with self._client() as client:
            response = await client.put(f"/live/streams/{stream_id}/finish")
        self._raise(response, "complete stream")

    async def delete_live_stream(self, stream_id: str) -> None:
        async with self._client() as client:
            response = await client.delete(f"/live/streams/{stream_id}")
        self._raise(response, "delete stream")

    async def get_asset_playback_id(self, asset_id: str) -> str:
        raise HTTPException(501, "FastPix replay mapping is not implemented in this sprint")

    async def get_live_stream_status(
            self,
            stream_id: str,
    ) -> StreamStatusResource:
        async with self._client() as client:
            response = await client.get(
                f"/live/streams/{stream_id}"
            )

        self._raise(
            response,
            "get stream status",
        )

        payload = response.json()
        data = payload.get("data") or {}

        returned_stream_id = (
                data.get("streamId")
                or stream_id
        )

        provider_status = str(
            data.get("status")
            or "unknown"
        ).strip().lower()

        return StreamStatusResource(
            provider=self.name,
            stream_id=str(returned_stream_id),
            status=provider_status,
        )
