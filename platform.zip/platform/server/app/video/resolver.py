from app.core.config import settings
from app.video.providers.fastpix import FastPixVideoProvider
from app.video.providers.mock import MockVideoProvider
from app.video.providers.mux import MuxVideoProvider
from app.video.providers.selfhosted import SelfHostVideoProvider


class VideoProviderResolver:
    def __init__(self):
        self._providers = {}

    def resolve(self, name: str):
        key = name.strip().lower()
        if key not in {"mock", "mux", "fastpix", "selfhosted"}:
            raise RuntimeError(f"Unsupported video provider: {name}")
        if key not in self._providers:
            factory = {
                "mock": MockVideoProvider,
                "mux": MuxVideoProvider,
                "fastpix": FastPixVideoProvider,
                "selfhosted": SelfHostVideoProvider,
            }[key]
            self._providers[key] = factory()
        return self._providers[key]

    def default(self):
        return self.resolve(settings.video_provider)


video_provider_resolver = VideoProviderResolver()
