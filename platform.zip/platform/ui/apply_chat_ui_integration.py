from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parent
if not (ROOT / "src").exists():
    # Expected invocation from the UI project root, with this script copied there.
    ROOT = Path.cwd()

FAN = ROOT / "src" / "pages" / "FanEventPage.tsx"
ARTIST = ROOT / "src" / "pages" / "ArtistControlPage.tsx"
CHAT_PANEL = ROOT / "src" / "components" / "ChatPanel.tsx"
CHAT_API = ROOT / "src" / "lib" / "chatApi.ts"
STYLES = ROOT / "src" / "styles.css"

required = [FAN, ARTIST, CHAT_PANEL, CHAT_API, STYLES]
missing = [str(path) for path in required if not path.exists()]
if missing:
    print("Missing required files:")
    for path in missing:
        print(f"  - {path}")
    sys.exit(1)


def backup(path: Path) -> None:
    backup_path = path.with_suffix(path.suffix + ".before-chat-ui")
    if not backup_path.exists():
        shutil.copy2(path, backup_path)


def apply_once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        print(f"[SKIP] {label}: already applied")
        return text
    if old not in text:
        print(f"[ERROR] {label}: expected anchor not found")
        sys.exit(1)
    print(f"[OK] {label}")
    return text.replace(old, new, 1)


for path in (FAN, ARTIST):
    backup(path)

fan = FAN.read_text(encoding="utf-8").replace("\r\n", "\n")
fan = apply_once(
    fan,
    'import VideoPlayer from "../components/video/VideoPlayer";\n',
    'import VideoPlayer from "../components/video/VideoPlayer";\n'
    'import ChatPanel from "../components/ChatPanel";\n',
    "FanEventPage ChatPanel import",
)

old_fan_player = '''\t\t\t{grant && (\n\t\t\t\t<Card className="player-card">\n\t\t\t\t\t<VideoPlayer\n\t\t\t\t\t\tkey={`${grant.session_id}-${grant.expires_at}`}\n\t\t\t\t\t\tgrant={grant}\n\t\t\t\t\t/>\n\t\t\t\t</Card>\n\t\t\t)}'''

# Also support spaces if the page has been autoformatted.
old_fan_player_spaces = '''            {grant && (\n                <Card className="player-card">\n                    <VideoPlayer\n                        key={`${grant.session_id}-${grant.expires_at}`}\n                        grant={grant}\n                    />\n                </Card>\n            )}'''

new_fan_player = '''            {grant && (\n                <div className="player-chat-layout">\n                    <Card className="player-card">\n                        <VideoPlayer\n                            key={`${grant.session_id}-${grant.expires_at}`}\n                            grant={grant}\n                        />\n                    </Card>\n                    <ChatPanel\n                        eventId={eventId}\n                        participantType="FAN"\n                        participantId={fanId}\n                        enabled={Boolean(grant)}\n                        title="Live chat"\n                    />\n                </div>\n            )}'''

if new_fan_player not in fan:
    if old_fan_player in fan:
        fan = fan.replace(old_fan_player, new_fan_player, 1)
        print("[OK] FanEventPage player/chat layout")
    elif old_fan_player_spaces in fan:
        fan = fan.replace(old_fan_player_spaces, new_fan_player, 1)
        print("[OK] FanEventPage player/chat layout")
    else:
        print("[ERROR] FanEventPage player block not found")
        sys.exit(1)
else:
    print("[SKIP] FanEventPage player/chat layout: already applied")

FAN.write_text(fan, encoding="utf-8", newline="\n")

artist = ARTIST.read_text(encoding="utf-8").replace("\r\n", "\n")
artist = apply_once(
    artist,
    'import { Link } from "react-router-dom";\n',
    'import { Link } from "react-router-dom";\n'
    'import ChatPanel from "../components/ChatPanel";\n',
    "ArtistControlPage ChatPanel import",
)

artist_chat = '''                    <ChatPanel\n                        eventId={eventId}\n                        participantType="ARTIST"\n                        participantId={artistId}\n                        enabled={event.status !== "CANCELLED"}\n                        title="Audience chat"\n                    />\n'''

artist_anchor = '''                    {event.status === "SCHEDULED" && ('''
if artist_chat not in artist:
    if artist_anchor not in artist:
        print("[ERROR] ArtistControlPage schedule anchor not found")
        sys.exit(1)
    artist = artist.replace(
        artist_anchor,
        artist_chat + artist_anchor,
        1,
    )
    print("[OK] ArtistControlPage audience chat panel")
else:
    print("[SKIP] ArtistControlPage audience chat panel: already applied")

ARTIST.write_text(artist, encoding="utf-8", newline="\n")

print("\nChat UI integration applied successfully.")
print("Backups were created with the suffix .before-chat-ui")
print("Next run: npm run build")
