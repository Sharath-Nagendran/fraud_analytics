import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
    plugins: [react()],
    server: { port: 5173, strictPort: true, proxy: { '/api': { target: 'http://localhost:8000', changeOrigin: true, rewrite: function (p) { return p.replace(/^\/api/, ''); } } } },
    build: { outDir: 'dist', sourcemap: true }
});
