export type EventStatus='DRAFT'|'SCHEDULED'|'LIVE'|'ENDED'|'ARCHIVED'|'CANCELLED'
export interface LiveEvent {id:string;title:string;description?:string|null;cover_image_url?:string|null;scheduled_start:string;ticket_price_cents:number;currency:string;capacity?:number|null;status:EventStatus;stream_active?: boolean;rtmp_ingest_url?:string;stream_key?:string;}
export interface ReplayDetails {event_id:string;status:string;available:boolean;archived_at?:string|null}
export interface OrderedTicket {ticket_id:string;entitlement_id:string;owner_fan_id:string;line_number:number}
export interface TicketOrder {order_id:string;event_id:string;buyer_fan_id:string;quantity:number;unit_amount_cents:number;total_amount_cents:number;currency:string;provider:string;provider_payment_id:string;status:string;purchase_type:string;created_at:string;tickets:OrderedTicket[]}
export interface OwnedTicket {ticket_id:string;event_id:string;purchaser_fan_id:string;owner_fan_id:string;ownership_status:string;ticket_status:string;entitlement_id?:string|null;tier_id?:string|null;amount_cents:number;currency:string}
export interface TicketTransfer {id:string;ticket_id:string;from_fan_id:string;to_fan_id:string;status:string;message?:string|null;created_at:string;expires_at:string;accepted_at?:string|null;cancelled_at?:string|null}
export interface PlaybackGrant {
    event_id: string;
    provider: "mock" | "mux" | "fastpix" | "selfhosted";
    playback_id: string;
    playback_url?: string | null;
    token?: string | null;
    expires_at: string;
    refresh_after_seconds: number;
    session_id: string;
    mode: "mock" | "public" | "signed";
}
export interface CompensationSummary {incident_id:string;candidates_pending:number;candidates_approved:number;candidates_rejected:number;candidates_refunded:number;cases_queued:number;cases_completed:number;cases_failed:number;cases_manual_review:number}
export interface CompensationCase {id:string;incident_id:string;candidate_id:string;ticket_id:string;event_id:string;fan_id:string;compensation_type:string;amount_cents:number;currency:string;status:string;provider_reference?:string|null;failure_reason?:string|null;approved_by:string;approved_at:string;completed_at?:string|null;reconciliation_attempts:number}
export interface DrmLicense {drm_mode: string; watermark_id?: string; license_token?: string; widevine?: boolean; fairplay?: boolean; playready?: boolean}

export interface VideoAsset {
    id: string;
    artist_id: string;
    source_live_event_id?: string | null;

    title: string;
    description?: string | null;

    asset_type: "UPLOAD" | "LIVE_RECORDING";

    thumbnail_url?: string | null;
    duration_seconds?: number | null;

    visibility:
        | "PRIVATE"
        | "PPV"
        | "SUBSCRIPTION"
        | "PUBLIC";

    price_cents?: number | null;
    currency: string;

    status:
        | "PROCESSING"
        | "READY"
        | "FAILED"
        | "ARCHIVED";

    published_at?: string | null;
    created_at: string;
    updated_at: string;
}

export interface VideoAssetPurchase {
    purchase_id: string;
    video_asset_id: string;
    fan_id: string;
    entitlement_id: string;

    provider: string;
    provider_payment_id: string;

    amount_cents: number;
    currency: string;

    status: string;
    entitlement_status: string;

    created_at: string;
}

export interface VideoAssetEntitlement {
    id: string;
    video_asset_id: string;
    fan_id: string;

    source: string;
    status: string;

    valid_from: string;
    valid_until?: string | null;
    created_at?: string;
}

export interface VideoAssetPlaybackGrant {
    asset_id: string;
    entitlement_id: string;
    session_id: string;

    provider:
        | "mock"
        | "mux"
        | "fastpix"
        | "selfhosted";

    playback_url: string;
    playback_id?: string | null;
    token?: string | null;

    expires_at: string;
    refresh_after_seconds: number;
}