const base=import.meta.env.VITE_API_BASE||'/api'
export class ApiError extends Error{constructor(public status:number,message:string){super(message)}}
export type RequestOptions=RequestInit&{fanId?:string;artistId?:string}
export async function api<T>(path:string,options:RequestOptions={}):Promise<T>{
 const headers=new Headers(options.headers); if(options.body&&!headers.has('Content-Type'))headers.set('Content-Type','application/json')
 if(options.fanId)headers.set('x-test-fan-id',options.fanId); if(options.artistId)headers.set('x-test-artist-id',options.artistId)
 const response=await fetch(`${base}${path}`,{...options,headers})
 if(!response.ok){let message=`Request failed (${response.status})`;try{const body=await response.json();message=typeof body.detail==='string'?body.detail:JSON.stringify(body.detail??body)}catch{}throw new ApiError(response.status,message)}
 if(response.status===204)return undefined as T
 return response.json() as Promise<T>
}
export const post=<T>(path:string,body:unknown,options:RequestOptions={})=>api<T>(path,{...options,method:'POST',body:JSON.stringify(body)})
export const put=<T>(
    path:string,
    body:unknown,
    options:RequestOptions={}
)=>
    api<T>(
        path,
        {
            ...options,
            method:'PUT',
            body:JSON.stringify(body)
        }
    )
export const patch=<T>(path:string,body:unknown,options:RequestOptions={})=>api<T>(path,{...options,method:'PATCH',body:JSON.stringify(body)})
export const del=<T>(path:string,options:RequestOptions={})=>api<T>(path,{...options,method:'DELETE'})
export const money=(cents:number,currency='GBP')=>new Intl.NumberFormat(undefined,{style:'currency',currency}).format(cents/100)
export const newKey=(prefix:string)=>`${prefix}:${crypto.randomUUID()}`
