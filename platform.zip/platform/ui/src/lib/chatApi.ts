export type ChatParticipantType = "ARTIST" | "FAN";
export type ChatRole = "artist" | "fan";
export type ConnectionState =
    | "idle"
    | "connecting"
    | "connected"
    | "reconnecting"
    | "closed"
    | "error";

export type ChatRoom = {
    id: string;
    room_type: "LIVE_EVENT" | "VIDEO_ASSET" | "DIRECT";
    live_event_id?: string | null;
    video_asset_id?: string | null;
    artist_id: string;
    status: "OPEN" | "CLOSED" | "ARCHIVED";
    moderation_enabled: boolean;
    moderation_policy_version: string;
    created_at: string;
    closed_at?: string | null;
};

export type ChatMessage = {
    id: string;
    chat_room_id: string;
    sender_participant_id: string;
    sender_type: ChatParticipantType;
    sender_id: string;
    sequence_number: number;
    message_type: "TEXT" | "SYSTEM" | "MODERATION_NOTICE";
    body: string;
    status: "PENDING" | "VISIBLE" | "BLOCKED" | "DELETED";
    client_message_id: string;
    created_at: string;
    moderation_decision: "ALLOW" | "WARN" | "BLOCK" | "ESCALATE";
};

type ChatMessagePage = {
    room_id: string;
    messages: ChatMessage[];
    next_after_sequence?: number | null;
};

function headers(
    role: ChatRole,
    participantId: string,
    includeJson = false,
): HeadersInit {
    return {
        ...(includeJson ? { "Content-Type": "application/json" } : {}),
        [role === "artist" ? "x-test-artist-id" : "x-test-fan-id"]:
            participantId,
    };
}

async function parseResponse<T>(response: Response): Promise<T> {
    if (response.ok) return (await response.json()) as T;

    let detail = `Request failed with status ${response.status}`;
    try {
        const payload = (await response.json()) as {
            detail?: string | Array<{ msg?: string }>;
        };
        if (typeof payload.detail === "string") detail = payload.detail;
        if (Array.isArray(payload.detail)) {
            detail = payload.detail
                .map((item) => item.msg)
                .filter(Boolean)
                .join("; ");
        }
    } catch {
        // Keep the HTTP fallback.
    }

    throw new Error(detail);
}

export async function getOrCreateArtistRoom(
    eventId: string,
    artistId: string,
): Promise<ChatRoom> {
    const response = await fetch(`/api/chat/live-events/${eventId}/room`, {
        headers: headers("artist", artistId),
    });
    return parseResponse<ChatRoom>(response);
}

export async function getFanRoom(
    eventId: string,
    fanId: string,
): Promise<ChatRoom> {
    const response = await fetch(`/api/chat/live-events/${eventId}/fan/room`, {
        headers: headers("fan", fanId),
    });
    return parseResponse<ChatRoom>(response);
}

export async function joinChat(
    roomId: string,
    role: ChatRole,
    participantId: string,
): Promise<void> {
    const response = await fetch(`/api/chat/rooms/${roomId}/${role}/join`, {
        method: "POST",
        headers: headers(role, participantId),
    });
    await parseResponse<unknown>(response);
}

export async function listMessages(
    roomId: string,
    role: ChatRole,
    participantId: string,
    afterSequence?: number,
): Promise<ChatMessagePage> {
    const query =
        afterSequence === undefined
            ? ""
            : `?after_sequence=${encodeURIComponent(afterSequence)}`;
    const response = await fetch(
        `/api/chat/rooms/${roomId}/${role}/messages${query}`,
        { headers: headers(role, participantId) },
    );
    return parseResponse<ChatMessagePage>(response);
}

export async function sendMessage(
    roomId: string,
    role: ChatRole,
    participantId: string,
    body: string,
): Promise<ChatMessage> {
    const response = await fetch(`/api/chat/rooms/${roomId}/${role}/messages`, {
        method: "POST",
        headers: headers(role, participantId, true),
        body: JSON.stringify({
            client_message_id: crypto.randomUUID(),
            body,
        }),
    });
    return parseResponse<ChatMessage>(response);
}

export function websocketUrl(
    roomId: string,
    participantType: ChatParticipantType,
    participantId: string,
): string {
    const scheme = window.location.protocol === "https:" ? "wss" : "ws";
    const host = import.meta.env.DEV ? "localhost:8000" : window.location.host;
    const params = new URLSearchParams({
        participant_type: participantType,
        participant_id: participantId,
    });

    return `${scheme}://${host}/ws/chat/${roomId}?${params.toString()}`;
}
