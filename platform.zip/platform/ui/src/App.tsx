import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { AppShell } from "./components/AppShell";
import HomePage from "./pages/HomePage";
import FanEventPage from "./pages/FanEventPage";
import ReplaysPage from "./pages/ReplaysPage";
import OrdersPage from "./pages/OrdersPage";
import TicketsPage from "./pages/TicketsPage";
import TransfersPage from "./pages/TransfersPage";
import CreateEventPage from "./pages/CreateEventPage";
import ArtistControlPage from "./pages/ArtistControlPage";
import CompensationPage from "./pages/CompensationPage";
import JobsPage from "./pages/JobsPage";
import DrmSessionsPage from "./pages/DrmSessionsPage";
import DrmConfigPage from "./pages/DrmConfigPage";
import VideoAssetCatalogPage from "./pages/VideoAssetCatalogPage";
import VideoAssetDetailPage from "./pages/VideoAssetDetailPage";
import ArtistVideoUploadPage from "./pages/ArtistVideoUploadPage";

const router = createBrowserRouter([
    {
        element: <AppShell />,
        children: [
            { path: "/", element: <HomePage /> },
            { path: "/fan/event", element: <FanEventPage /> },
            { path: "/fan/replays", element: <ReplaysPage /> },
            { path: "/fan/orders", element: <OrdersPage /> },
            { path: "/fan/tickets", element: <TicketsPage /> },
            { path: "/fan/transfers", element: <TransfersPage /> },
            { path: "/artist/create", element: <CreateEventPage /> },
            { path: "/artist/control", element: <ArtistControlPage /> },
            { path: "/admin/compensation", element: <CompensationPage /> },
			{ path:'/admin/drm', element:<DrmSessionsPage/> },
			{ path: "/admin/drm-config", element: <DrmConfigPage /> },
            { path: "/admin/jobs", element: <JobsPage /> },
            {path: "/fan/videos", element: <VideoAssetCatalogPage />,},
            {path: "/fan/videos/:assetId", element: <VideoAssetDetailPage />,},
            {path: "/artist/videos/upload",element: <ArtistVideoUploadPage />,},
        ],
    },
]);
export default function App() {
    return <RouterProvider router={router} />;
}
