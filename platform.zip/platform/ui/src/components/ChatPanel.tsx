import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { FormEvent } from "react";

import {
    getOrCreateArtistRoom,
    getFanRoom,
    joinChat,
    listMessages,
    sendMessage,
    websocketUrl,
} from "../lib/chatApi";
import type {
    ChatMessage,
    ChatParticipantType,
    ChatRoom,
    ConnectionState,
} from "../lib/chatApi";

type ChatPanelProps = {
    eventId: string;
    participantType: ChatParticipantType;
    participantId: string;
    enabled?: boolean;
    title?: string;
};

const MAX_BODY_LENGTH = 2000;

function mergeMessages(
    current: ChatMessage[],
    incoming: ChatMessage[],
): ChatMessage[] {
    const byId = new Map<string, ChatMessage>();

    for (const message of current) byId.set(message.id, message);
    for (const message of incoming) byId.set(message.id, message);

    return Array.from(byId.values()).sort(
        (left, right) => left.sequence_number - right.sequence_number,
    );
}

function connectionLabel(state: ConnectionState): string {
    switch (state) {
        case "connecting":
            return "Connecting";
        case "connected":
            return "Live";
        case "reconnecting":
            return "Reconnecting";
        case "closed":
            return "Offline";
        case "error":
            return "Connection error";
        default:
            return "Not connected";
    }
}

export default function ChatPanel({
    eventId,
    participantType,
    participantId,
    enabled = true,
    title = "Live chat",
}: ChatPanelProps) {
    const [room, setRoom] = useState<ChatRoom | null>(null);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [body, setBody] = useState("");
    const [error, setError] = useState("");
    const [busy, setBusy] = useState(false);
    const [connectionState, setConnectionState] =
        useState<ConnectionState>("idle");
    const [activeConnections, setActiveConnections] = useState<number | null>(null);

    const socketRef = useRef<WebSocket | null>(null);
    const reconnectTimerRef = useRef<number | undefined>(undefined);
    const reconnectAttemptRef = useRef(0);
    const disposedRef = useRef(false);
    const historyEndRef = useRef<HTMLDivElement | null>(null);

    const role = participantType === "ARTIST" ? "artist" : "fan";

    const canSend = useMemo(
        () =>
            enabled &&
            Boolean(room) &&
            connectionState === "connected" &&
            body.trim().length > 0 &&
            body.trim().length <= MAX_BODY_LENGTH &&
            !busy,
        [body, busy, connectionState, enabled, room],
    );

    const clearReconnectTimer = useCallback(() => {
        if (reconnectTimerRef.current !== undefined) {
            window.clearTimeout(reconnectTimerRef.current);
            reconnectTimerRef.current = undefined;
        }
    }, []);

    const loadHistory = useCallback(
        async (chatRoom: ChatRoom) => {
            const page = await listMessages(
                chatRoom.id,
                role,
                participantId,
            );
            setMessages((current) => mergeMessages(current, page.messages));
        },
        [participantId, role],
    );

    useEffect(() => {
        historyEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    useEffect(() => {
        disposedRef.current = false;
        clearReconnectTimer();
        socketRef.current?.close();
        socketRef.current = null;
        setRoom(null);
        setMessages([]);
        setError("");
        setConnectionState("idle");
        setActiveConnections(null);
        reconnectAttemptRef.current = 0;

        if (!enabled || !eventId || !participantId) {
            return () => {
                disposedRef.current = true;
            };
        }

        let activeRoom: ChatRoom | null = null;

        const openSocket = () => {
            if (disposedRef.current || !activeRoom) return;

            setConnectionState(
                reconnectAttemptRef.current > 0 ? "reconnecting" : "connecting",
            );

            const socket = new WebSocket(
                websocketUrl(
                    activeRoom.id,
                    participantType,
                    participantId,
                ),
            );
            socketRef.current = socket;

            socket.onopen = () => {
                reconnectAttemptRef.current = 0;
                setConnectionState("connected");
                setError("");
            };

            socket.onmessage = (event) => {
                const payload = JSON.parse(event.data) as {
                    type: string;
                    active_connections?: number;
                    message?: ChatMessage | string;
                    message_text?: string;
                };

                if (payload.type === "connection.ready") {
                    setActiveConnections(payload.active_connections ?? null);
                    void loadHistory(activeRoom as ChatRoom);
                    return;
                }

                if (
                    payload.type === "message.created" &&
                    payload.message &&
                    typeof payload.message !== "string"
                ) {
                    setMessages((current) => mergeMessages(current, [payload.message as ChatMessage]));
                    return;
                }

                if (payload.type === "error") {
                    setError(
                        payload.message_text ??
                            (typeof payload.message === "string" ? payload.message : undefined) ??
                            "Chat connection returned an error.",
                    );
                }
            };

            socket.onerror = () => {
                setConnectionState("error");
            };

            socket.onclose = (event) => {
                socketRef.current = null;
                setActiveConnections(null);

                if (disposedRef.current) {
                    setConnectionState("closed");
                    return;
                }

                if ([4400, 4403, 4404, 4409].includes(event.code)) {
                    setConnectionState("closed");
                    setError(event.reason || "Chat connection was rejected.");
                    return;
                }

                reconnectAttemptRef.current += 1;
                const delay = Math.min(
                    15000,
                    1000 * 2 ** Math.min(reconnectAttemptRef.current - 1, 4),
                );
                setConnectionState("reconnecting");
                reconnectTimerRef.current = window.setTimeout(openSocket, delay);
            };
        };

        const initialize = async () => {
            setBusy(true);
            try {
                activeRoom =
                    participantType === "ARTIST"
                        ? await getOrCreateArtistRoom(eventId, participantId)
                        : await getFanRoom(eventId, participantId);

                setRoom(activeRoom);
                await joinChat(
                    activeRoom.id,
                    role,
                    participantId,
                );
                await loadHistory(activeRoom);
                openSocket();
            } catch (initializationError) {
                setConnectionState("error");
                setError((initializationError as Error).message);
            } finally {
                setBusy(false);
            }
        };

        void initialize();

        return () => {
            disposedRef.current = true;
            clearReconnectTimer();
            socketRef.current?.close(1000, "Chat panel unmounted");
            socketRef.current = null;
        };
    }, [
        clearReconnectTimer,
        enabled,
        eventId,
        loadHistory,
        participantId,
        participantType,
        role,
    ]);

    const submit = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        if (!room || !canSend) return;

        const text = body.trim();
        setBusy(true);
        setError("");

        try {
            const result = await sendMessage(
                room.id,
                role,
                participantId,
                text,
            );

            if (result.status === "BLOCKED") {
                setError("The moderation policy blocked this message.");
            } else {
                setBody("");
                setMessages((current) => mergeMessages(current, [result]));
            }
        } catch (sendError) {
            setError((sendError as Error).message);
        } finally {
            setBusy(false);
        }
    };

    return (
        <section className="chat-panel" aria-label={title}>
            <header className="chat-panel__header">
                <div>
                    <h2>{title}</h2>
                    <p className="chat-panel__subtitle">
                        Moderated, entitlement-protected conversation
                    </p>
                </div>
                <div className={`chat-status chat-status--${connectionState}`}>
                    <span aria-hidden="true" />
                    {connectionLabel(connectionState)}
                </div>
            </header>

            {activeConnections !== null && (
                <div className="chat-panel__presence">
                    {activeConnections} active connection
                    {activeConnections === 1 ? "" : "s"}
                </div>
            )}

            <div className="chat-messages" aria-live="polite">
                {messages.length === 0 && !busy && (
                    <div className="chat-empty">No messages yet. Start the conversation.</div>
                )}

                {messages.map((message) => {
                    const ownMessage =
                        message.sender_id === participantId &&
                        message.sender_type === participantType;

                    return (
                        <article
                            className={`chat-message ${ownMessage ? "chat-message--own" : ""}`}
                            key={message.id}
                        >
                            <div className="chat-message__meta">
                                <strong>
                                    {message.sender_type === "ARTIST"
                                        ? "Artist"
                                        : message.sender_id}
                                </strong>
                                <span>
                                    {new Date(message.created_at).toLocaleTimeString([], {
                                        hour: "2-digit",
                                        minute: "2-digit",
                                    })}
                                </span>
                            </div>
                            <p>{message.body}</p>
                        </article>
                    );
                })}
                <div ref={historyEndRef} />
            </div>

            {error && <div className="chat-error" role="alert">{error}</div>}

            <form className="chat-composer" onSubmit={submit}>
                <textarea
                    value={body}
                    disabled={!enabled || !room || busy}
                    maxLength={MAX_BODY_LENGTH}
                    placeholder="Write a message"
                    rows={3}
                    onChange={(event) => setBody(event.target.value)}
                    onKeyDown={(event) => {
                        if (event.key === "Enter" && !event.shiftKey) {
                            event.preventDefault();
                            if (canSend) event.currentTarget.form?.requestSubmit();
                        }
                    }}
                />
                <div className="chat-composer__actions">
                    <span>{body.length}/{MAX_BODY_LENGTH}</span>
                    <button type="submit" disabled={!canSend}>
                        {busy ? "Sending..." : "Send"}
                    </button>
                </div>
            </form>
        </section>
    );
}
