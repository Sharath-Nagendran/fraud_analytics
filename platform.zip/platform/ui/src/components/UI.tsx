import type {ReactNode} from 'react'
export function Card({children,className=''}:{children:ReactNode;className?:string}){return <section className={`card ${className}`}>{children}</section>}
export function Badge({children,tone='default'}:{children:ReactNode;tone?:'default'|'ok'|'warn'|'danger'}){return <span className={`badge ${tone}`}>{children}</span>}
export function Notice({text,tone='default'}:{text?:string;tone?:'default'|'ok'|'danger'}){return text?<div className={`notice ${tone}`}>{text}</div>:null}
export function Empty({children}:{children:ReactNode}){return <div className="empty">{children}</div>}
export function PageTitle({eyebrow,title,children}:{eyebrow:string;title:string;children?:ReactNode}){return <header className="page-title"><span>{eyebrow}</span><h1>{title}</h1>{children&&<p>{children}</p>}</header>}
export function Spinner(){return <span className="spinner" aria-label="Loading"/>}
