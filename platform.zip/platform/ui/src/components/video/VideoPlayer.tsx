import MuxPlayer from "@mux/mux-player-react";
import "@fastpix/fp-player";
import Hls from "hls.js";
import { useEffect, useRef } from "react";

import type {
    PlaybackGrant,
    VideoAssetPlaybackGrant,
} from "../../types";


interface Props {
    grant:
        | PlaybackGrant
        | VideoAssetPlaybackGrant;
}

function SelfHostedPlayer(props: {
    url: string;
}) {
    const videoRef =
        useRef<HTMLVideoElement | null>(null);

    useEffect(() => {
        const video = videoRef.current;

        if (!video || !props.url) {
            return;
        }

        let hls: Hls | null = null;

        const cleanUrl = props.url
            .split("?")[0]
            .toLowerCase();

        const isHls =
            cleanUrl.endsWith(".m3u8");

        if (isHls && Hls.isSupported()) {
            hls = new Hls({
                lowLatencyMode: true,
                liveSyncDurationCount: 1,
                liveMaxLatencyDurationCount: 2,
                maxBufferLength: 3,
                backBufferLength: 20,
                enableWorker: true,
            });

            hls.loadSource(props.url);
            hls.attachMedia(video);

            hls.on(
                Hls.Events.MANIFEST_PARSED,
                () => {
                    video
                        .play()
                        .catch(() => {});
                },
            );

            hls.on(
                Hls.Events.ERROR,
                (_, data) => {
                    if (!data.fatal || !hls) {
                        return;
                    }

                    switch (data.type) {
                        case Hls.ErrorTypes.NETWORK_ERROR:
                            hls.startLoad();
                            break;

                        case Hls.ErrorTypes.MEDIA_ERROR:
                            hls.recoverMediaError();
                            break;

                        default:
                            hls.destroy();
                            break;
                    }
                },
            );
        } else {
            video.src = props.url;

            video
                .play()
                .catch(() => {});
        }

        return () => {
            if (hls) {
                hls.destroy();
            }

            video.removeAttribute("src");
            video.load();
        };
    }, [props.url]);

    return (
        <video
            ref={videoRef}
            controls
            auto-play
            playsInline
            style={{
                width: "100%",
                height: "100%",
                backgroundColor: "black",
            }}
        />
    );
}

export default function VideoPlayer({
    grant,
}: Props) {
    if (grant.provider === "mock") {
        return (
            <div className="mock-live">
                <strong>AUTHORIZED</strong>
                <span>Mock video playback</span>
            </div>
        );
    }

    if (grant.provider === "fastpix") {
        return (
            <fastpix-player
                playback-id={
                    grant.playback_id
                    ?? undefined
                }
                auto-play
                muted
                token={
                    grant.token
                    ?? undefined
                }
            />
        );
    }

    if (grant.provider === "mux") {
        return (
            <MuxPlayer
                playbackId={
                    grant.playback_id
                    ?? ""
                }
                tokens={
                    grant.token
                        ? {
                            playback:
                                grant.token,
                        }
                        : undefined
                }
                auto-play
            />
        );
    }

    if (
        grant.provider === "selfhosted"
    ) {
        return (
            <SelfHostedPlayer
                url={
                    grant.playback_url
                    ?? ""
                }
            />
        );
    }

    return (
        <div className="player-error">
            Unsupported video provider:
            {" "}
            {grant.provider}
        </div>
    );
}