import { NavLink, Outlet } from "react-router-dom";
import {
    Activity,
    CalendarDays,
    Clapperboard,
    Film,
    Radio,
    Receipt,
    ShieldCheck,
    Ticket,
    UserRoundCog,
    UsersRound,
    Upload
} from "lucide-react";
import { useIdentity } from "../context/IdentityContext";
const link = (to: string, label: string, Icon: typeof Activity) => (
    <NavLink to={to} className={({ isActive }) => (isActive ? "active" : "")}>
        <Icon size={18} />
        <span>{label}</span>
    </NavLink>
);
export function AppShell() {
    const id = useIdentity();
    return (
        <div className="shell">
            <aside>
                <div className="brand">
                    <span className="brandmark">AL</span>
                    <div>
                        <strong>Artist Live</strong>
                        <small>Experience console</small>
                    </div>
                </div>
                <nav>
                    <p>Fan</p>
                    {link("/fan/event", "Event & live", Radio)}
                    {link("/fan/videos", "Video catalog", Film)}
                    {link("/fan/replays", "Replays", Film)}
                    {link("/fan/orders", "My orders", Receipt)}
                    {link("/fan/tickets", "My tickets", Ticket)}
                    {link("/fan/transfers", "Transfers", UsersRound)}
                    <p>Artist</p>
                    {link("/artist/create", "Create event", CalendarDays)}
                    {link("/artist/control", "Stream control", Clapperboard)}
                    {link("/artist/videos/upload", "Upload video", Upload)}
                    <p>Operations</p>
                    {link("/admin/compensation", "Compensation", ShieldCheck)}
					{link("/admin/drm", "DRM Sessions", ShieldCheck)}
					{link("/admin/drm-config", "DRM Config", ShieldCheck)}
                    {link("/admin/jobs", "Jobs & diagnostics", Activity)}
                </nav>
                <div className="identity">
                    <UserRoundCog size={18} />
                    <div>
                        <label>
                            Fan ID
                            <input
                                value={id.fanId}
                                onChange={(e) => id.setFanId(e.target.value)}
                            />
                        </label>
                        <label>
                            Artist ID
                            <input
                                value={id.artistId}
                                onChange={(e) => id.setArtistId(e.target.value)}
                            />
                        </label>
                        <label>
                            Operator ID
                            <input
                                value={id.adminId}
                                onChange={(e) => id.setAdminId(e.target.value)}
                            />
                        </label>
                    </div>
                </div>
            </aside>
            <main>
                <Outlet />
            </main>
        </div>
    );
}
