import {createContext,useContext,useMemo,useState,type ReactNode} from 'react'
type Identity={fanId:string;artistId:string;adminId:string;setFanId:(v:string)=>void;setArtistId:(v:string)=>void;setAdminId:(v:string)=>void}
const C=createContext<Identity|null>(null)
const saved=(k:string,d:string)=>localStorage.getItem(k)||d
export function IdentityProvider({children}:{children:ReactNode}){
 const [fanId,setFan]=useState(()=>saved('fanId','fan-a'));const [artistId,setArtist]=useState(()=>saved('artistId','test-artist-1'));const [adminId,setAdmin]=useState(()=>saved('adminId','operator-1'))
 const value=useMemo(()=>({fanId,artistId,adminId,setFanId:(v:string)=>{setFan(v);localStorage.setItem('fanId',v)},setArtistId:(v:string)=>{setArtist(v);localStorage.setItem('artistId',v)},setAdminId:(v:string)=>{setAdmin(v);localStorage.setItem('adminId',v)}}),[fanId,artistId,adminId])
 return <C.Provider value={value}>{children}</C.Provider>
}
export function useIdentity(){const c=useContext(C);if(!c)throw new Error('Identity provider missing');return c}
