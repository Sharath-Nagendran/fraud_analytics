import React from 'react';import ReactDOM from 'react-dom/client';import App from './App';import {IdentityProvider} from './context/IdentityContext';import './styles.css'
ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><IdentityProvider><App/></IdentityProvider></React.StrictMode>)
