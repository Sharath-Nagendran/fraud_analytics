import { useRef, useState } from "react";
import MuxPlayer from "@mux/mux-player-react";
import { Card, Badge, Notice, PageTitle } from "../components/UI";
import { api, money, newKey, post } from "../lib/api";
import { useIdentity } from "../context/IdentityContext";
import type {
    LiveEvent,
    PlaybackGrant,
    ReplayDetails,
    TicketOrder,
	DrmLicense
} from "../types";

export default function ReplaysPage() {
    const { fanId } = useIdentity();
    const [eventId, setEventId] = useState(
        localStorage.getItem("lastEventId") || "",
    );
    const [event, setEvent] = useState<LiveEvent | null>(null);
    const [details, setDetails] = useState<ReplayDetails | null>(null);
    const [grant, setGrant] = useState<PlaybackGrant | null>(null);
	const [drm,setDrm]=useState<DrmLicense|null>(null);
    const [order, setOrder] = useState<TicketOrder | null>(null);
    const [message, setMessage] = useState("");
    const timer = useRef<number>();
    const load = async () => {
        try {
            setEvent(await api(`/live-events/${eventId}`));
            setDetails(await api(`/live-events/${eventId}/replay`));
            localStorage.setItem("lastEventId", eventId);
            setMessage("");
        } catch (e) {
            setMessage((e as Error).message);
        }
    };
    const buy = async () => {
        try {
            const v = await post<TicketOrder>("/ticket-orders", {
                event_id: eventId,
                buyer_fan_id: fanId,
                quantity: 1,
                idempotency_key: newKey("replay-order"),
                purchase_type: "REPLAY",
            });
            setOrder(v);
            setMessage("Replay access purchased.");
        } catch (e) {
            setMessage((e as Error).message);
        }
    };
    const watch = async () => {
		try {

			const prior = sessionStorage.getItem(`replaySession:${eventId}`);
			const v = await post<PlaybackGrant>(`/live-events/${eventId}/replay-token`,prior? {session_id: prior}: {},{fanId});
			setGrant(v);
			const drmInfo = await post<DrmLicense>(`/live-events/${eventId}/drm-license`,{session_id:v.session_id},{fanId});
			setDrm(drmInfo);
			sessionStorage.setItem(`replaySession:${eventId}`,v.session_id);
			clearTimeout(timer.current);
			timer.current = window.setTimeout(watch,Math.max(15,v.refresh_after_seconds) * 1000);
		} catch (e) {
			setMessage(
				(e as Error).message
			);
		}
	};
    return (
        <>
            <PageTitle eyebrow="Fan experience" title="Replays">
                Purchase or watch an archived performance. Access follows the
                active entitlement owner.
            </PageTitle>
            <Card>
                <div className="toolbar">
                    <input
                        className="grow"
                        placeholder="Archived event UUID"
                        value={eventId}
                        onChange={(e) => setEventId(e.target.value)}
                    />
                    <button onClick={load}>Load replay</button>
                </div>
                {event && (
                    <div className="event-hero">
                        <Badge tone={details?.available ? "ok" : "warn"}>
                            {event.status}
                        </Badge>
                        <h2>{event.title}</h2>
                        <p>
                            {event.description || "Archived artist performance"}
                        </p>
                        <p className="price">
                            {money(event.ticket_price_cents, event.currency)}
                        </p>
                    </div>
                )}
            </Card>
            {event && (
                <div className="grid two">
                    <Card>
                        <h2>Replay access</h2>
                        <p>
                            Buy replay-only access after the archived asset is
                            ready.
                        </p>
                        <button disabled={!details?.available} onClick={buy}>
                            Buy replay access
                        </button>
                        {order && (
                            <p className="success">
                                Order {order.order_id.slice(0, 8)} paid.
                            </p>
                        )}
                    </Card>
                    <Card>
                        <h2>Watch</h2>
                        <p>Refunded or transferred-away tickets are denied.</p>
                        <button disabled={!details?.available} onClick={watch}>
                            Watch replay
                        </button>
                    </Card>
                </div>
            )}
            {grant && (
                <Card className="player-card">
                    {grant.mode === "mock" ? (
                        <div className="mock-live">
                            <strong>REPLAY</strong>
                            <span>Authorized mock VOD</span>
                        </div>
                    ) : (
                        <MuxPlayer
                            playbackId={grant.playback_id}
                            tokens={
                                grant.token
                                    ? { playback: grant.token }
                                    : undefined
                            }
                            streamType="on-demand"
                            autoPlay
                        />
                    )}
                </Card>
            )}
			{drm && (
				<Card>
					<h2> DRM Protection </h2>
					<p> Mode: {drm.drm_mode} </p>

					<p> Watermark: {drm.watermark_id} </p>
				</Card>
			)}
            <Notice
                text={message}
                tone={message.includes("purchased") ? "ok" : "danger"}
            />
        </>
    );
}
