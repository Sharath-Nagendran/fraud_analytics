import { useEffect, useState } from "react";

import {
    Card,
    PageTitle,
    Notice,
} from "../components/UI";

import {
    api,
    put
} from "../lib/api";

interface DrmConfig {

    enabled: boolean;

    provider: string;

    watermark_enabled: boolean;

    widevine_url: string | null;

    fairplay_url: string | null;

    playready_url: string | null;
}

export default function DrmConfigPage() {

    const [config, setConfig] =
        useState<DrmConfig | null>(null);

    const [message, setMessage] =
        useState("");

    const [error, setError] =
        useState("");

    const load = async () => {

        try {

            const data =
                await api<DrmConfig>(
                    "/admin/drm/config"
                );

            setConfig(data);

        } catch (e) {

            setError(
                (e as Error).message
            );
        }
    };

    useEffect(() => {

        load();

    }, []);

    const save = async () => {

        if (!config) {
            return;
        }

        setMessage("");
        setError("");

        try {

            await put(
                "/admin/drm/config",
                config
            );

            setMessage(
                "Configuration saved successfully."
            );

        } catch (e) {

            setError(
                (e as Error).message
            );
        }
    };

    if (!config) {

        return (
            <PageTitle
                eyebrow="Operations"
                title="DRM Configuration"
            >
                Loading...
            </PageTitle>
        );
    }

    return (
        <>
            <PageTitle
                eyebrow="Operations"
                title="DRM Configuration"
            >
                Configure DRM provider settings.
            </PageTitle>

            <Card>

                <label>

                    DRM Enabled

                    <select
                        value={
                            config.enabled
                                ? "true"
                                : "false"
                        }
                        onChange={(e) =>
                            setConfig({
                                ...config,
                                enabled:
                                    e.target.value === "true"
                            })
                        }
                    >
                        <option value="false">
                            Disabled
                        </option>

                        <option value="true">
                            Enabled
                        </option>

                    </select>

                </label>

                <label>

                    Provider

                    <select
                        value={config.provider}
                        onChange={(e) =>
                            setConfig({
                                ...config,
                                provider:
                                    e.target.value
                            })
                        }
                    >
                        <option value="mock">
                            Mock
                        </option>

                        <option value="real">
                            Real
                        </option>

                    </select>

                </label>

                <label>

                    Watermark Enabled

                    <select
                        value={
                            config.watermark_enabled
                                ? "true"
                                : "false"
                        }
                        onChange={(e) =>
                            setConfig({
                                ...config,
                                watermark_enabled:
                                    e.target.value === "true"
                            })
                        }
                    >
                        <option value="true">
                            True
                        </option>

                        <option value="false">
                            False
                        </option>

                    </select>

                </label>

                <label>

                    Widevine URL

                    <input
                        value={
                            config.widevine_url
                            ?? ""
                        }
                        onChange={(e) =>
                            setConfig({
                                ...config,
                                widevine_url:
                                    e.target.value
                            })
                        }
                    />

                </label>

                <label>

                    FairPlay URL

                    <input
                        value={
                            config.fairplay_url
                            ?? ""
                        }
                        onChange={(e) =>
                            setConfig({
                                ...config,
                                fairplay_url:
                                    e.target.value
                            })
                        }
                    />

                </label>

                <label>

                    PlayReady URL

                    <input
                        value={
                            config.playready_url
                            ?? ""
                        }
                        onChange={(e) =>
                            setConfig({
                                ...config,
                                playready_url:
                                    e.target.value
                            })
                        }
                    />

                </label>

                <button
                    onClick={save}
                >
                    Save Configuration
                </button>

            </Card>

            <Notice
                text={message}
                tone="ok"
            />

            <Notice
                text={error}
                tone="danger"
            />

        </>
    );
}