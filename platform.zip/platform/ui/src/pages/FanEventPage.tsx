import { useEffect, useRef, useState } from "react";
import VideoPlayer from "../components/video/VideoPlayer";
import ChatPanel from "../components/ChatPanel";
import { Card, Badge, Notice, PageTitle, Spinner } from "../components/UI";
import { api, money, newKey, post } from "../lib/api";
import { useIdentity } from "../context/IdentityContext";
import type { LiveEvent, PlaybackGrant, TicketOrder } from "../types";
import type { DrmLicense } from "../types";
export default function FanEventPage() {
    const { fanId } = useIdentity();
    const [eventId, setEventId] = useState(
        localStorage.getItem("lastEventId") || "",
    );
    const [event, setEvent] = useState<LiveEvent | null>(null);
    const [qty, setQty] = useState(1);
    const [order, setOrder] = useState<TicketOrder | null>(null);
    const [grant, setGrant] = useState<PlaybackGrant | null>(null);
	const [autoReconnect, setAutoReconnect] = useState(false);
    const [message, setMessage] = useState("");
    const [loading, setLoading] = useState(false);
    const [drm, setDrm] = useState<DrmLicense | null>(null);
    const timer = useRef<number>();
	const lastStatusRef = useRef<string | null>(null);
	const reconnectPendingRef = useRef(false);
    const load = async () => {
    if (!eventId) return;

    setLoading(true);

    try {
        const v = await api<LiveEvent>(
            `/live-events/${eventId}`
        );
		const previousStatus =
			lastStatusRef.current;

		lastStatusRef.current =
			v.status;
        setEvent(v);

        if (
			autoReconnect &&
			grant &&
			previousStatus === "ENDED" &&
			v.status === "LIVE" &&
			!reconnectPendingRef.current
		) {
			reconnectPendingRef.current = true;

			setTimeout(() => {
				reconnectPendingRef.current = false;
				setGrant(null);

				setTimeout(() => {
					getGrant();
				}, 1000);
			}, 15000);
		}

        localStorage.setItem(
            "lastEventId",
            eventId
        );
            localStorage.setItem("lastEventId", eventId);
        } catch (e) {
            setMessage((e as Error).message);
        } finally {
            setLoading(false);
        }
    };
    useEffect(() => {
        if (!eventId) return;
        load();
        const i = setInterval(load, 5000);
        return () => clearInterval(i);
    }, [eventId]);
    const buy = async () => {
        setMessage("");
        try {
            const v = await post<TicketOrder>("/ticket-orders", {
                event_id: eventId,
                buyer_fan_id: fanId,
                quantity: qty,
                idempotency_key: newKey("order"),
            });
            setOrder(v);
            setMessage("Order paid and tickets issued.");
        } catch (e) {
            setMessage((e as Error).message);
        }
    };
    const getGrant = async () => {
        try {
            const prior = sessionStorage.getItem(`liveSession:${eventId}`);
            const v = await post<PlaybackGrant>(
                `/live-events/${eventId}/playback-token`,
                prior ? { session_id: prior } : {},
                { fanId },
            );
            setGrant(v);
			setAutoReconnect(true);
			const drmInfo =
				  await post<DrmLicense>(
					`/live-events/${eventId}/drm-license`,
					{
					  session_id:
						v.session_id
					},
					{
					  fanId
					}
				  )

			setDrm(drmInfo)
            sessionStorage.setItem(`liveSession:${eventId}`, v.session_id);
            clearTimeout(timer.current);
            timer.current = window.setTimeout(
                getGrant,
                Math.max(15, v.refresh_after_seconds) * 1000,
            );
        } catch (e) {
            setMessage((e as Error).message);
        }
    };
    return (
        <>
            <PageTitle
                eyebrow="Fan experience"
                title="Event and live performance"
            >
                Enter an event ID, purchase one or more tickets, then enter the
                live stream.
            </PageTitle>
            <Card>
                <div className="toolbar">
                    <input
                        className="grow"
                        placeholder="Event UUID"
                        value={eventId}
                        onChange={(e) => setEventId(e.target.value)}
                    />
                    <button onClick={load}>Load event</button>
                </div>
                {loading && <Spinner />}
                {event && (
                    <div className="event-hero">
                        <div>
                            <Badge
                                tone={
                                    event.status === "LIVE"
                                        ? "ok"
                                        : event.status === "CANCELLED"
                                          ? "danger"
                                          : "default"
                                }
                            >
                                {event.status}
                            </Badge>
                            <h2>{event.title}</h2>
                            <p>
                                {event.description || "Live artist experience"}
                            </p>
                            <dl>
                                <div>
                                    <dt>Starts</dt>
                                    <dd>
                                        {new Date(
                                            event.scheduled_start,
                                        ).toLocaleString()}
                                    </dd>
                                </div>
                                <div>
                                    <dt>Price</dt>
                                    <dd>
                                        {money(
                                            event.ticket_price_cents,
                                            event.currency,
                                        )}
                                    </dd>
                                </div>
                                <div>
                                    <dt>Capacity</dt>
                                    <dd>{event.capacity ?? "Unlimited"}</dd>
                                </div>
                            </dl>
                        </div>
                    </div>
                )}
            </Card>
            {event && (
                <div className="grid two">
                    <Card>
                        <h2>Purchase tickets</h2>
                        <label>
                            Quantity
                            <input
                                type="number"
                                min="1"
                                max="20"
                                value={qty}
                                onChange={(e) => setQty(Number(e.target.value))}
                            />
                        </label>
                        <p className="price">
                            {money(
                                event.ticket_price_cents * qty,
                                event.currency,
                            )}
                        </p>
                        <button onClick={buy}>
                            Pay and issue {qty} ticket{qty === 1 ? "" : "s"}
                        </button>
                        {order && (
                            <p className="success">
                                Order {order.order_id.slice(0, 8)} issued{" "}
                                {order.tickets.length} tickets.
                            </p>
                        )}
                    </Card>
                    <Card>
                        <h2>Playback</h2>
                        <p>
                            Access follows the current ticket owner. Refunded
                            tickets are denied.
                        </p>
                        <button
                            disabled={event.status !== "LIVE"}
                            onClick={getGrant}
                        >
                            Enter performance
                        </button>
                        {event.status !== "LIVE" && (
                            <p className="muted">The event must be LIVE.</p>
                        )}
                    </Card>
                </div>
            )}
            {grant && (
                <div className="player-chat-layout">
                    <Card className="player-card">
                        <VideoPlayer
                            key={`${grant.session_id}-${grant.expires_at}`}
                            grant={grant}
                        />
                    </Card>
                    <ChatPanel
                        eventId={eventId}
                        participantType="FAN"
                        participantId={fanId}
                        enabled={Boolean(grant)}
                        title="Live chat"
                    />
                </div>
            )}
			{drm && (
				<Card>
					<h2>
						DRM Protection
					</h2>

					<p>
						Mode: {drm.drm_mode}
					</p>

					<p>
						Watermark: {drm.watermark_id}
					</p>
				</Card>
			)}
            <Notice
                text={message}
                tone={message.includes("issued") ? "ok" : "danger"}
            />
        </>
    );
}
