import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";

import VideoPlayer from "../components/video/VideoPlayer";
import { Badge, Card, Notice, PageTitle, Spinner } from "../components/UI";
import { useIdentity } from "../context/IdentityContext";
import { api, money, newKey, post } from "../lib/api";

import type {
    VideoAsset,
    VideoAssetEntitlement,
    VideoAssetPlaybackGrant,
    VideoAssetPurchase,
} from "../types";

export default function VideoAssetDetailPage() {
    const { assetId = "" } = useParams();
    const { fanId } = useIdentity();

    const [asset, setAsset] = useState<VideoAsset | null>(null);
    const [entitlement, setEntitlement] = useState<VideoAssetEntitlement | null>(null);
    const [grant, setGrant] = useState<VideoAssetPlaybackGrant | null>(null);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [message, setMessage] = useState("");

    const refreshTimer = useRef<number>();

    const loadEntitlement = useCallback(async () => {
        if (!assetId) return;

        try {
            const result = await api<VideoAssetEntitlement>(
                `/video-assets/${assetId}/entitlement`,
                { fanId }
            );

            setEntitlement(result);
        } catch {
            setEntitlement(null);
        }
    }, [assetId, fanId]);

    const load = useCallback(async () => {
        if (!assetId) return;

        setLoading(true);

        try {
            const result = await api<VideoAsset>(`/video-assets/${assetId}`);
            setAsset(result);
            await loadEntitlement();
        } catch (error) {
            setMessage((error as Error).message);
        } finally {
            setLoading(false);
        }
    }, [assetId, loadEntitlement]);

    useEffect(() => {
        void load();

        return () => {
            if (refreshTimer.current) {
                window.clearTimeout(refreshTimer.current);
            }
        };
    }, [load]);

    const purchase = async () => {
        if (!asset) return;

        setBusy(true);

        try {
            await post<VideoAssetPurchase>(
                `/video-assets/${asset.id}/purchase`,
                {
                    fan_id: fanId,
                    idempotency_key: newKey("video-asset")
                }
            );

            await loadEntitlement();
            setMessage("Purchase completed.");
        } catch (error) {
            setMessage((error as Error).message);
        } finally {
            setBusy(false);
        }
    };

    const watch = async () => {
        if (!assetId) return;

        setBusy(true);

        try {
            const grantResult = await post<VideoAssetPlaybackGrant>(
                `/video-assets/${assetId}/playback-token`,
                {},
                { fanId }
            );

            setGrant(grantResult);
            setMessage("Playback authorized.");
        } catch (error) {
            setMessage((error as Error).message);
        } finally {
            setBusy(false);
        }
    };

    if (loading) {
        return (
            <Card>
                <Spinner />
                <p>Loading video...</p>
            </Card>
        );
    }

    if (!asset) {
        return <Notice text="Video asset not found" tone="danger" />;
    }

    return (
        <>
            <PageTitle eyebrow="Fan video library" title={asset.title}>
                {asset.description ?? "Premium video"}
            </PageTitle>

            <div className="toolbar">
                <Link className="button" to="/fan/videos">
                    Back to catalog
                </Link>
            </div>

            <Card>
                <div className="split">
                    <Badge>{asset.visibility}</Badge>
                    <Badge>{asset.asset_type}</Badge>
                </div>

                <p>
                    {asset.price_cents != null
                        ? money(asset.price_cents, asset.currency)
                        : "No price"}
                </p>

                {entitlement ? (
                    <button disabled={busy} onClick={() => void watch()}>
                        Watch video
                    </button>
                ) : (
                    <button disabled={busy} onClick={() => void purchase()}>
                        Purchase access
                    </button>
                )}
            </Card>

            {grant && (
                <Card className="player-card">
                    <VideoPlayer grant={grant as any} />
                </Card>
            )}

            <Notice text={message} />
        </>
    );
}
