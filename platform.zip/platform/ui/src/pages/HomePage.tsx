import {Link} from 'react-router-dom';import {Card,PageTitle} from '../components/UI'
export default function HomePage(){return <><PageTitle eyebrow="Platform workspace" title="Live events, ticketing and operations">A typed React console for every workflow validated against the FastAPI backend.</PageTitle><div className="grid three">
<Card><h2>Fan journey</h2><p>Buy several tickets in one order, transfer each independently, accept incoming transfers and join live playback.</p><Link className="button" to="/fan/event">Open fan console</Link></Card>
<Card><h2>Artist journey</h2><p>Create scheduled events, retrieve ingest credentials and drive the mock Mux lifecycle.</p><Link className="button" to="/artist/create">Open artist console</Link></Card>
<Card><h2>Operations</h2><p>Review an outage, approve compensation, dispatch refunds and reconcile financial status.</p><Link className="button" to="/admin/compensation">Open operations</Link></Card></div></>}
