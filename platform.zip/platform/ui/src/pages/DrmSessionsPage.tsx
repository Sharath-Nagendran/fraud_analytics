import { useEffect, useState } from "react";

import {
    Card,
    PageTitle,
    Notice,
} from "../components/UI";

import { api } from "../lib/api";

interface DrmSession {

    id: string;

    event_id: string;

    fan_id: string;

    entitlement_id: string;

    playback_session_id: string;

    drm_mode: string;

    watermark_id: string;

    created_at: string;
}

export default function DrmSessionsPage() {

    const [rows, setRows] =
        useState<DrmSession[]>([]);

    const [error, setError] =
        useState("");

    const load = async () => {

        try {

            const data =
                await api<DrmSession[]>(
                    "/admin/drm/sessions"
                );

            setRows(data);

        } catch (e) {

            setError(
                (e as Error).message
            );
        }
    };

    useEffect(() => {

        load();

    }, []);

    return (
        <>
            <PageTitle
                eyebrow="Operations"
                title="DRM Sessions"
            >
                Watermark and DRM
                license activity.
            </PageTitle>

            <button onClick={load}>
                Refresh
            </button>

            <div className="stack">

                {rows.map(row => (

                    <Card key={row.id}>

                        <h2>
                            {row.fan_id}
                        </h2>

                        <p>
                            Event:
                            <br />
                            <code>
                                {row.event_id}
                            </code>
                        </p>

                        <p>
                            Session:
                            <br />
                            <code>
                                {row.playback_session_id}
                            </code>
                        </p>

                        <p>
                            Watermark:
                            <br />
                            <strong>
                                {row.watermark_id}
                            </strong>
                        </p>

                        <p>
                            Mode:
                            {row.drm_mode}
                        </p>

                        <p>
                            Created:
                            <br />
                            {new Date(
                                row.created_at
                            ).toLocaleString()}
                        </p>

                    </Card>

                ))}

            </div>

            <Notice
                text={error}
                tone="danger"
            />

        </>
    );
}