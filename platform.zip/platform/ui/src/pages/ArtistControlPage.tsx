import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import ChatPanel from "../components/ChatPanel";

import { Badge, Card, Notice, PageTitle, Spinner } from "../components/UI";
import { useIdentity } from "../context/IdentityContext";
import { api, del, patch, post } from "../lib/api";
import type { LiveEvent } from "../types";

type ArtistLiveEvent = LiveEvent & {
    finalized_at?: string | null;
};

type FinalizeLiveEventResponse = {
    event_id: string;
    status: string;
    finalized_at: string;
    recording_id: string;
    recording_status: string;
    stream_path: string;
    replay_job_id: string;
    replay_job_status: ReplayJobStatus;
};

type ReplayJobStatus =
    | "PENDING"
    | "PROCESSING"
    | "RETRY"
    | "COMPLETED"
    | "FAILED";

type ReplayJob = {
    id: string;
    live_event_id: string;
    live_recording_id: string;
    status: ReplayJobStatus;
    attempts: number;
    max_attempts: number;
    next_attempt_at: string;
    locked_at?: string | null;
    locked_by?: string | null;
    last_error?: string | null;
    video_asset_id?: string | null;
    created_at: string;
    updated_at: string;
    completed_at?: string | null;
};

const TERMINAL_REPLAY_STATUSES = new Set<ReplayJobStatus>([
    "COMPLETED",
    "FAILED",
]);

const replayTone = (
    status: ReplayJobStatus,
): "default" | "ok" | "warn" | "danger" => {
    if (status === "COMPLETED") return "ok";
    if (status === "FAILED") return "danger";
    if (status === "RETRY") return "warn";
    return "default";
};

const replayLabel = (status: ReplayJobStatus): string => {
    switch (status) {
        case "PENDING":
            return "Replay queued";
        case "PROCESSING":
            return "Generating replay";
        case "RETRY":
            return "Retry scheduled";
        case "COMPLETED":
            return "Replay ready";
        case "FAILED":
            return "Replay generation failed";
    }
};

export default function ArtistControlPage() {
    const { artistId } = useIdentity();
    const [eventId, setEventId] = useState(
        localStorage.getItem("lastEventId") || "",
    );
    const [event, setEvent] = useState<ArtistLiveEvent | null>(null);
    const [replayJob, setReplayJob] = useState<ReplayJob | null>(null);
    const [message, setMessage] = useState("");
    const [messageTone, setMessageTone] = useState<"ok" | "danger">("ok");
    const [busyAction, setBusyAction] = useState<string | null>(null);
    const [showFinalizeConfirmation, setShowFinalizeConfirmation] = useState(false);
    const [newStart, setNewStart] = useState("");
    const pollingTimer = useRef<number | undefined>(undefined);

    const stopPolling = useCallback(() => {
        if (pollingTimer.current !== undefined) {
            window.clearTimeout(pollingTimer.current);
            pollingTimer.current = undefined;
        }
    }, []);

    const loadReplayStatus = useCallback(
        async (quiet = false): Promise<ReplayJob | null> => {
            if (!eventId) return null;

            try {
                const job = await api<ReplayJob>(
                    `/live-events/${eventId}/replay-status`,
                    { artistId },
                );
                setReplayJob(job);
                return job;
            } catch (error) {
                const status = (error as { status?: number }).status;
                if (status === 404) {
                    setReplayJob(null);
                    return null;
                }
                if (!quiet) {
                    setMessageTone("danger");
                    setMessage((error as Error).message);
                }
                return null;
            }
        },
        [artistId, eventId],
    );

    const loadEvent = useCallback(async () => {
        if (!eventId.trim()) {
            setMessageTone("danger");
            setMessage("Enter an event ID.");
            return;
        }

        setBusyAction("load");
        stopPolling();

        try {
            const loaded = await api<ArtistLiveEvent>(
                `/live-events/${eventId}`,
            );
            setEvent(loaded);
            localStorage.setItem("lastEventId", eventId);
            setMessage("");

            if (loaded.finalized_at) {
                await loadReplayStatus(true);
            } else {
                setReplayJob(null);
            }
        } catch (error) {
            setEvent(null);
            setReplayJob(null);
            setMessageTone("danger");
            setMessage((error as Error).message);
        } finally {
            setBusyAction(null);
        }
    }, [eventId, loadReplayStatus, stopPolling]);

    useEffect(() => {
        if (!event?.finalized_at || !replayJob) {
            stopPolling();
            return;
        }

        if (TERMINAL_REPLAY_STATUSES.has(replayJob.status)) {
            stopPolling();
            return;
        }

        const poll = async () => {
            const job = await loadReplayStatus(true);
            if (job && !TERMINAL_REPLAY_STATUSES.has(job.status)) {
                pollingTimer.current = window.setTimeout(poll, 5000);
            }
        };

        pollingTimer.current = window.setTimeout(poll, 5000);
        return stopPolling;
    }, [event?.finalized_at, loadReplayStatus, replayJob, stopPolling]);

    useEffect(() => stopPolling, [stopPolling]);

    const runEventAction = async (
        actionName: string,
        action: () => Promise<unknown>,
        successMessage: string,
    ) => {
        setBusyAction(actionName);
        try {
            await action();
            setMessageTone("ok");
            setMessage(successMessage);
            await loadEvent();
        } catch (error) {
            setMessageTone("danger");
            setMessage((error as Error).message);
        } finally {
            setBusyAction(null);
        }
    };

    const finalize = async () => {
        setShowFinalizeConfirmation(false);
        setBusyAction("finalize");

        try {
            const result = await post<FinalizeLiveEventResponse>(
                `/live-events/${eventId}/finalize`,
                {},
                { artistId },
            );
            setMessageTone("ok");
            setMessage("Performance finalized. Replay generation was queued.");
            await loadEvent();

            const job = await loadReplayStatus(true);
            if (!job) {
                setReplayJob({
                    id: result.replay_job_id,
                    live_event_id: result.event_id,
                    live_recording_id: result.recording_id,
                    status: result.replay_job_status,
                    attempts: 0,
                    max_attempts: 5,
                    next_attempt_at: new Date().toISOString(),
                    created_at: new Date().toISOString(),
                    updated_at: new Date().toISOString(),
                });
            }
        } catch (error) {
            setMessageTone("danger");
            setMessage((error as Error).message);
        } finally {
            setBusyAction(null);
        }
    };

    const isBusy = busyAction !== null;
    const canFinalize = event?.status === "ENDED" && !event.finalized_at && !event.stream_active;
    const isFinalized = Boolean(event?.finalized_at);

    return (
        <>
            <PageTitle eyebrow="Artist workspace" title="Performance control">
                Manage the live lifecycle, permanently finalize a completed performance,
                and monitor durable replay generation.
            </PageTitle>

            <Card>
                <div className="toolbar">
                    <input
                        className="grow"
                        value={eventId}
                        onChange={(value) => setEventId(value.target.value)}
                        placeholder="Event UUID"
                    />
                    <button disabled={isBusy} onClick={() => void loadEvent()}>
                        {busyAction === "load" ? "Loading..." : "Load event"}
                    </button>
                </div>
            </Card>

            {event && (
                <>
                    <Card>
                        <div className="split">
                            <div>
                                <h2>{event.title}</h2>
                                <p className="mono">{event.id}</p>
                            </div>
                            <Badge tone={event.status === "LIVE" ? "ok" : "default"}>
                                {event.status}
                            </Badge>
                        </div>

                        <div className="toolbar">
                            <button
                                disabled={isBusy || isFinalized}
                                onClick={() =>
                                    void runEventAction(
                                        "go-live",
                                        () => post(`/dev/mux/${eventId}/go-live`, {}),
                                        "Event is live.",
                                    )
                                }
                            >
                                Go live
                            </button>

                            <button
                                className="secondary"
                                disabled={isBusy || isFinalized}
                                onClick={() =>
                                    void runEventAction(
                                        "disconnect",
                                        () => post(`/dev/mux/${eventId}/disconnect`, {}),
                                        "Disconnect simulated.",
                                    )
                                }
                            >
                                Disconnect
                            </button>

                            <button
                                className="secondary"
                                disabled={isBusy || event.status !== "LIVE" || isFinalized}
                                onClick={() =>
                                    void runEventAction(
                                        "end",
                                        () => post(`/live-events/${eventId}/end`, {}, { artistId }),
                                        "Performance ended. It can still be restarted until finalized.",
                                    )
                                }
                            >
                                End performance
                            </button>

                            {canFinalize && (
                                <button
                                    className="danger"
                                    disabled={isBusy}
                                    onClick={() => setShowFinalizeConfirmation(true)}
                                >
                                    Finalize performance
                                </button>
                            )}
                        </div>

                        {event.status === "ENDED" && !isFinalized && (
                            <Notice
                                tone="default"
                                text="This performance is ended but restartable. Finalize only when no further restart is required."
                            />
                        )}

                        {event.status === "ENDED" && !isFinalized && event.stream_active === true && (
                            <Notice
                                tone="default"
                                text="OBS is still streaming. Stop streaming before finalization."
                            />
                        )}

                        {isFinalized && (
                            <Notice
                                tone="ok"
                                text={`Finalized ${new Date(event.finalized_at as string).toLocaleString()}. Restart is permanently disabled.`}
                            />
                        )}
                    </Card>

                    <ChatPanel
                        eventId={eventId}
                        participantType="ARTIST"
                        participantId={artistId}
                        enabled={event.status !== "CANCELLED"}
                        title="Audience chat"
                    />
                    {event.status === "SCHEDULED" && (
                        <Card>
                            <h2>Schedule</h2>
                            <div className="toolbar">
                                <input
                                    type="datetime-local"
                                    value={newStart}
                                    onChange={(value) => setNewStart(value.target.value)}
                                />
                                <button
                                    className="secondary"
                                    disabled={isBusy || !newStart}
                                    onClick={() =>
                                        void runEventAction(
                                            "reschedule",
                                            () =>
                                                patch(
                                                    `/live-events/${eventId}/reschedule`,
                                                    {
                                                        scheduled_start: new Date(newStart).toISOString(),
                                                    },
                                                    { artistId },
                                                ),
                                            "Event rescheduled.",
                                        )
                                    }
                                >
                                    Reschedule
                                </button>
                                <button
                                    className="danger"
                                    disabled={isBusy}
                                    onClick={() =>
                                        void runEventAction(
                                            "cancel",
                                            () => del(`/live-events/${eventId}`, { artistId }),
                                            "Event cancelled.",
                                        )
                                    }
                                >
                                    Cancel event
                                </button>
                            </div>
                        </Card>
                    )}

                    {isFinalized && (
                        <Card>
                            <div className="split">
                                <div>
                                    <h2>Replay lifecycle</h2>
                                    <p>
                                        Durable replay processing continues independently of the
                                        browser session.
                                    </p>
                                </div>
                                {replayJob && (
                                    <Badge tone={replayTone(replayJob.status)}>
                                        {replayLabel(replayJob.status)}
                                    </Badge>
                                )}
                            </div>

                            {!replayJob && (
                                <div className="toolbar">
                                    <Spinner />
                                    <span>Loading replay status...</span>
                                </div>
                            )}

                            {replayJob && (
                                <dl className="video-asset-metadata">
                                    <div>
                                        <dt>Attempts</dt>
                                        <dd>
                                            {replayJob.attempts} of {replayJob.max_attempts}
                                        </dd>
                                    </div>
                                    <div>
                                        <dt>Updated</dt>
                                        <dd>{new Date(replayJob.updated_at).toLocaleString()}</dd>
                                    </div>
                                    {replayJob.completed_at && (
                                        <div>
                                            <dt>Completed</dt>
                                            <dd>
                                                {new Date(replayJob.completed_at).toLocaleString()}
                                            </dd>
                                        </div>
                                    )}
                                </dl>
                            )}

                            {replayJob?.status === "RETRY" && (
                                <Notice
                                    tone="default"
                                    text={`Retry scheduled for ${new Date(replayJob.next_attempt_at).toLocaleString()}.`}
                                />
                            )}

                            {replayJob?.status === "FAILED" && (
                                <Notice
                                    tone="danger"
                                    text={
                                        replayJob.last_error
                                            ? `Replay failed: ${replayJob.last_error}`
                                            : "Replay generation failed. Contact an operator."
                                    }
                                />
                            )}

                            {replayJob?.status === "COMPLETED" && replayJob.video_asset_id && (
                                <div className="toolbar">
                                    <Link
                                        className="button"
                                        to={`/fan/videos/${replayJob.video_asset_id}`}
                                    >
                                        Open replay asset
                                    </Link>
                                </div>
                            )}

                            <div className="toolbar">
                                <button
                                    className="secondary"
                                    disabled={isBusy}
                                    onClick={() => void loadReplayStatus()}
                                >
                                    Refresh replay status
                                </button>
                            </div>
                        </Card>
                    )}
                </>
            )}

            <Notice text={message} tone={messageTone} />

            {showFinalizeConfirmation && (
                <div className="modal-backdrop" role="presentation">
                    <section
                        className="modal-card"
                        role="dialog"
                        aria-modal="true"
                        aria-labelledby="finalize-title"
                    >
                        <h2 id="finalize-title">Finalize performance?</h2>
                        <p>
                            Finalization is permanent. This event cannot return to LIVE after
                            finalization. Replay generation will be queued automatically and will
                            continue even if this page is closed.
                        </p>
                        <div className="toolbar">
                            <button
                                className="secondary"
                                onClick={() => setShowFinalizeConfirmation(false)}
                            >
                                Keep restart available
                            </button>
                            <button className="danger" onClick={() => void finalize()}>
                                Finalize and generate replay
                            </button>
                        </div>
                    </section>
                </div>
            )}
        </>
    );
}
