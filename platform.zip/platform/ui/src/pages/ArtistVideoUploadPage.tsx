import { useEffect, useRef, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { Link } from "react-router-dom";

import { Badge, Card, Notice, PageTitle } from "../components/UI";
import { useIdentity } from "../context/IdentityContext";
import type { VideoAsset } from "../types";

type Visibility = "PRIVATE" | "PPV" | "PUBLIC";
type UploadState = "idle" | "uploading" | "success" | "error";

const MAX_UPLOAD_BYTES = 5 * 1024 * 1024 * 1024;

function formatBytes(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    const units = ["KB", "MB", "GB", "TB"];
    let value = bytes / 1024;
    let index = 0;

    while (value >= 1024 && index < units.length - 1) {
        value /= 1024;
        index += 1;
    }

    return `${value.toFixed(value >= 10 ? 1 : 2)} ${units[index]}`;
}

function getApiError(xhr: XMLHttpRequest): string {
    try {
        const parsed = JSON.parse(xhr.responseText) as {
            detail?: string | Array<{ msg?: string }>;
        };

        if (typeof parsed.detail === "string") {
            return parsed.detail;
        }

        if (Array.isArray(parsed.detail)) {
            return parsed.detail
                .map((item) => item.msg)
                .filter(Boolean)
                .join("; ");
        }
    } catch {
        // Fall through to HTTP status text.
    }

    return xhr.statusText || `Upload failed with status ${xhr.status}`;
}

export default function ArtistVideoUploadPage() {
    const { artistId } = useIdentity();
    const [file, setFile] = useState<File | null>(null);
    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [visibility, setVisibility] = useState<Visibility>("PRIVATE");
    const [priceCents, setPriceCents] = useState("");
    const [currency, setCurrency] = useState("GBP");
    const [state, setState] = useState<UploadState>("idle");
    const [progress, setProgress] = useState(0);
    const [message, setMessage] = useState("");
    const [asset, setAsset] = useState<VideoAsset | null>(null);
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const xhrRef = useRef<XMLHttpRequest | null>(null);

    useEffect(() => {
        return () => {
            xhrRef.current?.abort();
        };
    }, []);

    const reset = () => {
        xhrRef.current?.abort();
        xhrRef.current = null;
        setFile(null);
        setTitle("");
        setDescription("");
        setVisibility("PRIVATE");
        setPriceCents("");
        setCurrency("GBP");
        setState("idle");
        setProgress(0);
        setMessage("");
        setAsset(null);

        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const selectFile = (event: ChangeEvent<HTMLInputElement>) => {
        const selected = event.target.files?.[0] ?? null;
        setAsset(null);
        setMessage("");
        setProgress(0);

        if (!selected) {
            setFile(null);
            return;
        }

        if (!selected.name.toLowerCase().endsWith(".mp4")) {
            setFile(null);
            setState("error");
            setMessage("Only MP4 files are supported.");
            event.target.value = "";
            return;
        }

        if (selected.size <= 0) {
            setFile(null);
            setState("error");
            setMessage("The selected file is empty.");
            event.target.value = "";
            return;
        }

        if (selected.size > MAX_UPLOAD_BYTES) {
            setFile(null);
            setState("error");
            setMessage("The selected file exceeds the 5 GB upload limit.");
            event.target.value = "";
            return;
        }

        setFile(selected);
        setState("idle");

        if (!title.trim()) {
            setTitle(selected.name.replace(/\.mp4$/i, ""));
        }
    };

    const validate = (): string | null => {
        if (!artistId.trim()) return "Artist identity is required.";
        if (!file) return "Select an MP4 file.";
        if (!title.trim()) return "Enter a title.";
        if (title.trim().length > 300) return "Title cannot exceed 300 characters.";
        if (currency.trim().length !== 3) return "Currency must contain three characters.";

        if (visibility === "PPV") {
            const parsedPrice = Number(priceCents);
            if (!Number.isInteger(parsedPrice) || parsedPrice <= 0) {
                return "Enter a positive whole-number price in cents for PPV access.";
            }
        }

        return null;
    };

    const upload = (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        const validationError = validate();
        if (validationError) {
            setState("error");
            setMessage(validationError);
            return;
        }

        const form = new FormData();
        form.append("file", file as File, (file as File).name);
        form.append("title", title.trim());
        form.append("description", description.trim());
        form.append("visibility", visibility);
        form.append("currency", currency.trim().toUpperCase());

        if (visibility === "PPV") {
            form.append("price_cents", priceCents.trim());
        }

        const xhr = new XMLHttpRequest();
        xhrRef.current = xhr;
        setState("uploading");
        setProgress(0);
        setMessage("");
        setAsset(null);

        xhr.open("POST", "/api/video-assets/artist/upload");
        xhr.setRequestHeader("x-test-artist-id", artistId);

        xhr.upload.addEventListener("progress", (progressEvent) => {
            if (progressEvent.lengthComputable) {
                setProgress(
                    Math.min(
                        99,
                        Math.round((progressEvent.loaded / progressEvent.total) * 100),
                    ),
                );
            }
        });

        xhr.addEventListener("load", () => {
            xhrRef.current = null;

            if (xhr.status >= 200 && xhr.status < 300) {
                const created = JSON.parse(xhr.responseText) as VideoAsset;
                setAsset(created);
                setProgress(100);
                setState("success");
                setMessage("Video uploaded and published successfully.");
                return;
            }

            setState("error");
            setMessage(getApiError(xhr));
        });

        xhr.addEventListener("error", () => {
            xhrRef.current = null;
            setState("error");
            setMessage("A network error interrupted the upload.");
        });

        xhr.addEventListener("abort", () => {
            xhrRef.current = null;
            setState("idle");
            setProgress(0);
            setMessage("Upload cancelled.");
        });

        xhr.send(form);
    };

    const cancel = () => {
        xhrRef.current?.abort();
    };

    const isUploading = state === "uploading";

    return (
        <>
            <PageTitle eyebrow="Artist video library" title="Upload video">
                Upload an MP4, configure access, and publish it to the video platform.
            </PageTitle>

            <div className="grid two">
                <Card>
                    <form className="upload-form" onSubmit={upload}>
                        <label className="field-stack">
                            <span>Video file</span>
                            <input
                                ref={fileInputRef}
                                type="file"
                                accept="video/mp4,.mp4"
                                disabled={isUploading}
                                onChange={selectFile}
                            />
                        </label>

                        {file && (
                            <div className="upload-file-summary">
                                <strong>{file.name}</strong>
                                <span>{formatBytes(file.size)}</span>
                            </div>
                        )}

                        <label className="field-stack">
                            <span>Title</span>
                            <input
                                value={title}
                                maxLength={300}
                                disabled={isUploading}
                                onChange={(event) => setTitle(event.target.value)}
                                placeholder="Video title"
                            />
                        </label>

                        <label className="field-stack">
                            <span>Description</span>
                            <textarea
                                value={description}
                                disabled={isUploading}
                                onChange={(event) => setDescription(event.target.value)}
                                placeholder="Describe the video"
                                rows={5}
                            />
                        </label>

                        <label className="field-stack">
                            <span>Visibility</span>
                            <select
                                value={visibility}
                                disabled={isUploading}
                                onChange={(event) => {
                                    const next = event.target.value as Visibility;
                                    setVisibility(next);
                                    if (next !== "PPV") setPriceCents("");
                                }}
                            >
                                <option value="PRIVATE">Private</option>
                                <option value="PPV">Pay per view</option>
                                <option value="PUBLIC">Public</option>
                            </select>
                        </label>

                        {visibility === "PPV" && (
                            <div className="grid two">
                                <label className="field-stack">
                                    <span>Price in cents</span>
                                    <input
                                        type="number"
                                        min="1"
                                        step="1"
                                        value={priceCents}
                                        disabled={isUploading}
                                        onChange={(event) => setPriceCents(event.target.value)}
                                        placeholder="750"
                                    />
                                </label>

                                <label className="field-stack">
                                    <span>Currency</span>
                                    <input
                                        value={currency}
                                        maxLength={3}
                                        disabled={isUploading}
                                        onChange={(event) => setCurrency(event.target.value)}
                                    />
                                </label>
                            </div>
                        )}

                        {isUploading && (
                            <div className="upload-progress" aria-live="polite">
                                <div className="split">
                                    <strong>Uploading</strong>
                                    <span>{progress}%</span>
                                </div>
                                <progress max="100" value={progress} />
                                <p className="muted">
                                    Keep this page open until the server confirms completion.
                                </p>
                            </div>
                        )}

                        <div className="toolbar">
                            <button type="submit" disabled={isUploading || !file}>
                                {isUploading ? "Uploading..." : "Upload video"}
                            </button>

                            {isUploading ? (
                                <button type="button" className="danger" onClick={cancel}>
                                    Cancel upload
                                </button>
                            ) : (
                                <button type="button" className="secondary" onClick={reset}>
                                    Reset
                                </button>
                            )}
                        </div>
                    </form>
                </Card>

                <Card>
                    <h2>Publishing summary</h2>
                    <dl className="video-asset-metadata">
                        <div>
                            <dt>Artist</dt>
                            <dd>{artistId}</dd>
                        </div>
                        <div>
                            <dt>Access</dt>
                            <dd>{visibility}</dd>
                        </div>
                        <div>
                            <dt>Storage</dt>
                            <dd>Configured provider</dd>
                        </div>
                        <div>
                            <dt>Accepted format</dt>
                            <dd>MP4</dd>
                        </div>
                        <div>
                            <dt>Maximum size</dt>
                            <dd>5 GB</dd>
                        </div>
                    </dl>

                    <p className="muted">
                        The backend validates the file again, stores it through the configured
                        storage provider, and creates a READY VideoAsset.
                    </p>
                </Card>
            </div>

            {asset && (
                <Card>
                    <div className="split">
                        <div>
                            <h2>{asset.title}</h2>
                            <p>Upload completed and the video asset is ready.</p>
                        </div>
                        <Badge tone="ok">{asset.status}</Badge>
                    </div>

                    <div className="toolbar">
                        <Link className="button" to={`/fan/videos/${asset.id}`}>
                            Open video asset
                        </Link>
                        <Link className="button secondary" to="/fan/videos">
                            Open video catalog
                        </Link>
                    </div>
                </Card>
            )}

            <Notice
                text={message}
                tone={state === "error" ? "danger" : "ok"}
            />
        </>
    );
}
