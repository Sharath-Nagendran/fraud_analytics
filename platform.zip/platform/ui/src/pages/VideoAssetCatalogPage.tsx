import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import { Badge, Card, Empty, Notice, PageTitle, Spinner } from "../components/UI";
import { api, money } from "../lib/api";
import type { VideoAsset } from "../types";

export default function VideoAssetCatalogPage() {
    const [assets, setAssets] = useState<VideoAsset[]>([]);
    const [loading, setLoading] = useState(true);
    const [message, setMessage] = useState("");

    const load = async () => {
        setLoading(true);
        setMessage("");

        try {
            const result = await api<VideoAsset[]>("/video-assets/catalog");
            setAssets(result);
        } catch (error) {
            setMessage((error as Error).message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        void load();
    }, []);

    return (
        <>
            <PageTitle
                eyebrow="Fan video library"
                title="Video catalog"
            >
                Browse published artist videos available on the platform.
            </PageTitle>

            <div className="toolbar">
                <button
                    className="secondary"
                    onClick={() => void load()}
                    disabled={loading}
                >
                    Refresh catalog
                </button>
            </div>

            {loading && (
                <Card>
                    <Spinner />
                    <p>Loading videos...</p>
                </Card>
            )}

            {!loading && assets.length === 0 && (
                <Empty>
                    No published videos are currently available.
                </Empty>
            )}

            <div className="grid three">
                {assets.map((asset) => (
                    <Card key={asset.id}>
                        <div className="split">
                            <Badge>{asset.asset_type}</Badge>
                            <Badge>{asset.visibility}</Badge>
                        </div>

                        <h2>{asset.title}</h2>

                        <p>
                            {asset.description ?? "No description provided."}
                        </p>

                        <div className="split">
                            <strong>
                                {asset.price_cents != null
                                    ? money(asset.price_cents, asset.currency)
                                    : asset.visibility}
                            </strong>

                            <Link
                                className="button"
                                to={`/fan/videos/${asset.id}`}
                            >
                                View
                            </Link>
                        </div>
                    </Card>
                ))}
            </div>

            <Notice
                text={message}
                tone="danger"
            />
        </>
    );
}
