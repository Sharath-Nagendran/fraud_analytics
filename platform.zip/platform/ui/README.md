# Artist Live Web

React + TypeScript + Vite frontend for the FastAPI artist live-video platform.

## Included workflows

- Fan event lookup, multi-ticket order, signed/mock live playback and token refresh
- Buyer order history with current ticket-owner resolution
- Current-owned ticket list and independent transfer initiation
- Incoming/outgoing transfer acceptance, decline and cancellation
- Artist event creation, ingest credentials, reschedule, go-live, disconnect, end, archive and cancel
- Outage simulation, compensation approval, dispatch, notifications and reconciliation
- Local development identity controls for `x-test-fan-id` and `x-test-artist-id`

## Requirements

Vite's current getting-started guide requires Node.js 20.19+ or 22.12+ for its current major. Check with:

```powershell
node --version
npm --version
```

## Run in development

From this frontend directory:

```powershell
Copy-Item .env.example .env
npm install
npm run dev
```

Open `http://localhost:5173`. Vite proxies `/api/*` to the FastAPI server at `http://localhost:8000`.

Start FastAPI separately from the backend project:

```powershell
.\.venv\Scripts\uvicorn.exe app.main:app --reload
```

## Build

```powershell
npm run typecheck
npm run build
npm run preview
```

The production files are written to `dist/`.

## Backend limitations reflected in the UI

- There is no general event-list endpoint in the validated API, so event and stream-control pages accept an event UUID.
- Development identity headers are not authentication. Replace the identity context when the real identity provider is implemented.
- Monetary partial refunds for multi-ticket orders remain backend work. The UI exposes the validated compensation workflow but does not claim an amount-aware provider partial refund.
- Admin pages use the existing development/admin endpoints and should not be exposed publicly.

## Optional FastAPI production mounting

For a single deployment, copy `dist/` into `app/static/web/` and mount it from FastAPI. During active development, keep Vite and FastAPI separate so HMR and proxying work cleanly.
